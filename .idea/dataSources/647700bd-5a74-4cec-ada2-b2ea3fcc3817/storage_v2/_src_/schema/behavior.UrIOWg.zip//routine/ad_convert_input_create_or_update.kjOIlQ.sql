create
    definer = devuser@`%` procedure ad_convert_input_create_or_update(IN in_platform_type int, IN in_os int,
                                                                      IN in_muid varchar(128),
                                                                      IN in_click_time datetime,
                                                                      IN in_expire_time datetime, IN in_callback text,
                                                                      IN in_app_id varchar(128),
                                                                      IN in_advertiser_id varchar(128),
                                                                      IN in_a_id varchar(128), IN in_c_id varchar(128),
                                                                      IN in_idfa varchar(128), IN in_imei varchar(128),
                                                                      IN in_mac varchar(128),
                                                                      IN in_android_id varchar(128),
                                                                      IN in_ip varchar(128), IN in_ua varchar(128))
BEGIN

	DECLARE id_num INT;
	SET id_num = 0;

	SELECT a.id INTO id_num FROM ad_convert_input a 
	WHERE (in_platform_type IS NULL OR a.platform_type = in_platform_type)
	AND (in_os IS NULL OR a.os = in_os)
	AND (in_muid IS NULL OR a.muid = in_muid)
	AND (in_mac IS NULL OR a.mac = in_mac)
	AND (in_android_id IS NULL OR a.android_id = in_android_id);

	IF id_num = 0
	THEN

		INSERT INTO ad_convert_input (platform_type, os, muid, click_time, expire_time, callback, app_id, advertiser_id, a_id, c_id, idfa, imei, mac, android_id, ip, ua)
		VALUES (in_platform_type, in_os, in_muid, in_click_time, in_expire_time, in_callback, in_app_id, in_advertiser_id, in_a_id, in_c_id, in_idfa, in_imei, in_mac, in_android_id, in_ip, in_ua);

	ELSE
		UPDATE ad_convert_input SET
		platform_type = in_platform_type,
      	os = in_os,
     	muid = in_muid,
      	click_time = in_click_time,
      	expire_time =in_expire_time,
      	app_id = in_app_id,
      	advertiser_id = in_advertiser_id,
      	a_id = in_a_id,
      	c_id = in_c_id,
      	idfa = in_idfa,
      	imei = in_imei,
      	mac = in_mac,
      	android_id = in_android_id,
      	ip = in_ip,
      	ua = in_ua
      	WHERE id = id_num;
	END IF;

END;

