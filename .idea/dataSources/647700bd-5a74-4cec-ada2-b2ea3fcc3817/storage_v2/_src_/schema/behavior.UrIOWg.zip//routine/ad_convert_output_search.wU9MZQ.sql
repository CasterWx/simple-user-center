create
    definer = devuser@`%` procedure ad_convert_output_search(IN in_in_id int, IN in_conv_type int)
BEGIN
	
	SELECT * FROM ad_convert_output
	WHERE in_id = in_in_id and conv_type = in_conv_type;
	
END;

