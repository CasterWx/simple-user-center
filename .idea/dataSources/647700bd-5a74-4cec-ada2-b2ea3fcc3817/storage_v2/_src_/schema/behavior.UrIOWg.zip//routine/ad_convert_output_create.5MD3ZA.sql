create
    definer = devuser@`%` procedure ad_convert_output_create(IN in_in_id int, IN in_conv_type int, IN in_conv_time datetime)
BEGIN
	
	INSERT INTO ad_convert_output (in_id, conv_type, conv_time)
	VALUES (in_in_id, in_conv_type, in_conv_time);

END;

