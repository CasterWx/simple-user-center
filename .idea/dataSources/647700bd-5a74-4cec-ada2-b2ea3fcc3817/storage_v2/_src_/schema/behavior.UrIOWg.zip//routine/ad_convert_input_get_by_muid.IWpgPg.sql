create
    definer = devuser@`%` procedure ad_convert_input_get_by_muid(IN in_muid varchar(128))
BEGIN
	
	SELECT * FROM ad_convert_input
	WHERE muid = in_muid and expire_time > now();
	
END;

