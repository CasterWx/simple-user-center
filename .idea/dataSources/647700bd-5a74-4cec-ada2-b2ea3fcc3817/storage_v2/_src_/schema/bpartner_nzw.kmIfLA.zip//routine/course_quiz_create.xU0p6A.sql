create
    definer = devuser@`%` procedure course_quiz_create(IN in_quiz_id int, IN in_course_id int, OUT out_id int)
BEGIN
    INSERT INTO course_quiz (`quiz_id`, `course_id`)
    VALUES (in_quiz_id,in_course_id);
    SET out_id = LAST_INSERT_ID();
END;

