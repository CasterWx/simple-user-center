create
    definer = devuser@`%` procedure student_answer_update(IN in_id int, IN in_student_id int, IN in_course_id int,
                                                          IN in_user_quiz_id int, IN in_question_id int,
                                                          IN in_answer mediumtext, IN in_score double,
                                                          IN in_upload_time bigint)
BEGIN
	UPDATE `student_answer`
    SET
		student_id = in_student_id,
		course_id = in_course_id,
		user_quiz_id = in_user_quiz_id,
		question_id = in_question_id,
		answer = in_answer,
		score = in_score,
		upload_time = in_upload_time
	WHERE id = in_id;
END;

