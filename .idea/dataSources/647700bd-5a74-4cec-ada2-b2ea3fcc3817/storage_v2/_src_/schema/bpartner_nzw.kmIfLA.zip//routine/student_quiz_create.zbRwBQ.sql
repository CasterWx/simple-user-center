create
    definer = devuser@`%` procedure student_quiz_create(IN in_student_id int, IN in_coursebag_id int, IN in_quiz_id int,
                                                        IN in_course_id int, IN in_knowledge_id int,
                                                        IN in_answer_type int, IN in_score double,
                                                        IN in_answered_count int, IN in_correct_count int,
                                                        IN in_correct_rate double, IN in_upload_time bigint,
                                                        IN in_time_spent bigint, OUT out_id int)
BEGIN

 	INSERT INTO `student_quiz`
    (
		student_id,
		coursebag_id,
		quiz_id,
		course_id,
		knowledge_id,
		answer_type,
		score,
		answered_count,
		correct_count,
		correct_rate,
		upload_time,
		time_spent
    )
    VALUES
    (
		in_student_id,
		in_coursebag_id,
		in_quiz_id,
		in_course_id,
		in_knowledge_id,
		in_answer_type,
		in_score,
		in_answered_count,
		in_correct_count,
		in_correct_rate,
		in_upload_time,
		in_time_spent
    );
	SET out_id = LAST_INSERT_ID();

 END;

