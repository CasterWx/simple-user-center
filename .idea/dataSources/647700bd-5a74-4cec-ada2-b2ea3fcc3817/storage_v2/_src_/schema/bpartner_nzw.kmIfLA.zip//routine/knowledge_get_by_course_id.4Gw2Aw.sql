create
    definer = devuser@`%` procedure knowledge_get_by_course_id(IN in_course_id int)
BEGIN
    SELECT * FROM knowledge WHERE course_id = in_course_id;
END;

