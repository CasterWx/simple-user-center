create
    definer = devuser@`%` procedure coursebag_course_get_by_id(IN in_id int)
BEGIN

    SELECT id, course_id, coursebag_id, created_time, updated_time
    FROM coursebag_course WHERE id = in_id;

END;

