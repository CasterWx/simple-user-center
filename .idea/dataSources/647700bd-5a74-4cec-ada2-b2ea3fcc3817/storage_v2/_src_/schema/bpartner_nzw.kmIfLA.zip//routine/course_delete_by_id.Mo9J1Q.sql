create
    definer = devuser@`%` procedure course_delete_by_id(IN in_id int)
BEGIN

    DELETE FROM course WHERE id = in_id;

END;

