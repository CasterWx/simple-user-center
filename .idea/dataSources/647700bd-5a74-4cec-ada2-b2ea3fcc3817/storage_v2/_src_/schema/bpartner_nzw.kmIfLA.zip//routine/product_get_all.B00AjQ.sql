create
    definer = devuser@`%` procedure product_get_all()
BEGIN
	SELECT * FROM product;
END;

