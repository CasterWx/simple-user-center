create
    definer = devuser@`%` procedure order_search(IN in_id int, IN in_student_id int, IN in_order_num varchar(64))
BEGIN
	SELECT * FROM `order`
	WHERE (in_id IS NULL OR id = in_id)
	AND (in_student_id IS NULL OR student_id = in_student_id)
	AND (in_order_num IS NULL OR order_num = in_order_num);
END;

