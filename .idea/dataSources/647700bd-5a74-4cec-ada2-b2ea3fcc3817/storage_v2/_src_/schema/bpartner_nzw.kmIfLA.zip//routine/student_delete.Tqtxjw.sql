create
    definer = devuser@`%` procedure student_delete(IN in_id int)
BEGIN
	SET SQL_SAFE_UPDATES = 0;

    DELETE FROM student_answer WHERE student_id = in_id;
    DELETE FROM student_coursebag WHERE student_id = in_id;
    DELETE FROM student_quiz WHERE student_id = in_id;
    DELETE FROM student WHERE id = in_id;

END;

