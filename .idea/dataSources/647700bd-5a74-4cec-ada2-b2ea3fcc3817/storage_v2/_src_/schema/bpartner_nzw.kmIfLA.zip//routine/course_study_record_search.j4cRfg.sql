create
    definer = devuser@`%` procedure course_study_record_search(IN in_student_id int, IN in_coursebag_id int,
                                                               IN in_course_id int, IN in_knowledge_id int,
                                                               IN in_data_id int, IN in_data_type int)
BEGIN
	SELECT * FROM course_study_record
	WHERE (in_student_id IS NULL OR student_id = in_student_id)
	AND (in_coursebag_id IS NULL OR coursebag_id = in_coursebag_id)
	AND (in_course_id IS NULL OR course_id = in_course_id)
	AND (in_knowledge_id IS NULL OR knowledge_id = in_knowledge_id)
	AND (in_data_id IS NULL OR data_id = in_data_id)
	AND (in_data_type IS NULL OR data_type = in_data_type);
END;

