create
    definer = devuser@`%` procedure student_quiz_delete(IN in_id int)
BEGIN
    DELETE FROM student_quiz WHERE id = in_id;

END;

