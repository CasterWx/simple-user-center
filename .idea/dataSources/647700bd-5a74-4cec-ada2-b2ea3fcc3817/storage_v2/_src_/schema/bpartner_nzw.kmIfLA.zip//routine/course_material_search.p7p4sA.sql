create
    definer = devuser@`%` procedure course_material_search(IN in_course_id int, IN in_knowledge_id int,
                                                           IN in_content_id int, IN in_type int)
BEGIN
	SELECT * FROM course_material
	where (in_course_id IS NULL OR course_id = in_course_id)
	AND (in_knowledge_id IS NULL OR knowledge_id = in_knowledge_id)
	AND (in_type IS NULL OR type = in_type)
	AND (in_content_id IS NULL OR content_id = in_content_id);
END;

