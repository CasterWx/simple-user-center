create
    definer = devuser@`%` procedure knowledge_get_by_id(IN in_id int)
BEGIN
    SELECT * FROM knowledge WHERE id = in_id;
END;

