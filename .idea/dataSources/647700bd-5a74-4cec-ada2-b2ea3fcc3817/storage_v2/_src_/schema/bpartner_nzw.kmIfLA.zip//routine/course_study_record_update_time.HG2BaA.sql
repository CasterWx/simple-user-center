create
    definer = devuser@`%` procedure course_study_record_update_time(IN in_id int, IN in_end_time timestamp, IN in_time_point int)
BEGIN
	UPDATE course_study_record set end_time = in_end_time, time_point = in_time_point
	where id = in_id;

END;

