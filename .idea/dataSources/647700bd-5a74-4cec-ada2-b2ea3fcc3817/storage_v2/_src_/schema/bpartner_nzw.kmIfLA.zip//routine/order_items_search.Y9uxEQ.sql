create
    definer = devuser@`%` procedure order_items_search(IN in_order_id int, IN in_product_id int, IN in_offer_id int,
                                                       IN in_pay_status int)
BEGIN
	SELECT * FROM `order_items`
	WHERE (in_order_id is NULL OR order_id = in_order_id)
	AND (in_product_id is NULL OR product_id = in_product_id)
	AND (in_offer_id is NULL OR offer_id = in_offer_id)
	AND (in_pay_status is NULL OR pay_status = in_pay_status);
END;

