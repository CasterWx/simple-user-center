create
    definer = devuser@`%` procedure knowledge_update(IN in_id int, IN in_course_id int, IN in_parent_id int,
                                                     IN in_sequence_num int, IN in_name varchar(255),
                                                     IN in_sub_name varchar(255), IN in_cover_img_url varchar(1024),
                                                     IN in_important_index int, IN in_description varchar(1024),
                                                     IN in_published bit, IN in_publish_time datetime, IN in_free bit,
                                                     IN in_status int)
BEGIN
    UPDATE knowledge SET `course_id` = in_course_id,
                         parent_id = in_parent_id,
                         sequence_num = in_sequence_num,
                         `name` = in_name,
                         sub_name = in_sub_name,
                         cover_img_url = in_cover_img_url,
                         important_index = in_important_index,
                         `description` = in_description,
                         published = in_published,
                         publish_time = in_publish_time,
                         free = in_free,
                         `status` = in_status
    WHERE id = in_id;
END;

