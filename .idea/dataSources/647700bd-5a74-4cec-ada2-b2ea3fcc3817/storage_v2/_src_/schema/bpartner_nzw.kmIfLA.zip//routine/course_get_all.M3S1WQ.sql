create
    definer = devuser@`%` procedure course_get_all()
BEGIN
    SELECT * FROM course;
END;

