create
    definer = devuser@`%` procedure course_study_record_get_by_id(IN in_id int)
BEGIN

	SELECT * FROM course_study_record WHERE id = in_id;
END;

