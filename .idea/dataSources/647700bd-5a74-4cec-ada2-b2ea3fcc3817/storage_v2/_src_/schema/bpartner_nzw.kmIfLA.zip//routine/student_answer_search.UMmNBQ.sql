create
    definer = devuser@`%` procedure student_answer_search(IN in_student_id int, IN in_course_id int,
                                                          IN in_user_quiz_id int, IN in_question_id int)
BEGIN
    SELECT * FROM student_answer
    WHERE (in_student_id IS NULL OR student_id = in_student_id)
	AND (in_course_id IS NULL OR course_id = in_course_id)
	AND (in_user_quiz_id IS NULL OR user_quiz_id = in_user_quiz_id)
	AND (in_question_id IS NULL OR question_id = in_question_id);
END;

