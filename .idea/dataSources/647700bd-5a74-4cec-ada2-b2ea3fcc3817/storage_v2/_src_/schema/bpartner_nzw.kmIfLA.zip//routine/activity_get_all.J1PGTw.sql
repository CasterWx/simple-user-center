create
    definer = devuser@`%` procedure activity_get_all()
BEGIN

	SELECT * FROM activity;
END;

