create
    definer = devuser@`%` procedure knowledge_quiz_get_by_id(IN in_id int)
BEGIN
    SELECT *
    FROM knowledge_quiz
    WHERE id = in_id;
END;

