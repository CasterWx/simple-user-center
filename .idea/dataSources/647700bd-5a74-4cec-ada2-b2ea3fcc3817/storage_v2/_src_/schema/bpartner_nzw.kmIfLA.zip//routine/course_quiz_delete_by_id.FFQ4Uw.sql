create
    definer = devuser@`%` procedure course_quiz_delete_by_id(IN in_id int)
BEGIN

    DELETE FROM course_quiz WHERE id = in_id;

END;

