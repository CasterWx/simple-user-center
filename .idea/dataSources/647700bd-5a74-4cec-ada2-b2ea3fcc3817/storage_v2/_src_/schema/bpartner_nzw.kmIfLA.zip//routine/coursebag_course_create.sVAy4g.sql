create
    definer = devuser@`%` procedure coursebag_course_create(IN in_coursebag_id int, IN in_course_id int, OUT out_id int)
BEGIN
    INSERT INTO coursebag_course (`coursebag_id`, `course_id`)
    VALUES (in_coursebag_id,in_course_id);
    SET out_id = LAST_INSERT_ID();
END;

