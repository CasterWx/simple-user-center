create
    definer = devuser@`%` procedure student_coursebag_create(IN in_student_id int, IN in_coursebag_id int,
                                                             IN in_trial bit, IN in_token varchar(1024),
                                                             IN in_expired_time datetime, OUT out_id int)
BEGIN

	INSERT INTO `student_coursebag`
    (
		student_id,
		coursebag_id,
		trial,
		token,
		expired_time
    )
    VALUES
    (
		in_student_id,
		in_coursebag_id,
		in_trial,
		in_token,
		in_expired_time
    );
	SET out_id = LAST_INSERT_ID();
    
END;

