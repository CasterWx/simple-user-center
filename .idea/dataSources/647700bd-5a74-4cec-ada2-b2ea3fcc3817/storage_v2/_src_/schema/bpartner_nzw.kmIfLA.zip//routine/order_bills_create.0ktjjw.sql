create
    definer = devuser@`%` procedure order_bills_create(IN in_order_num varchar(255), IN in_coursebag_id int,
                                                       IN in_product_id int, IN in_offer_id int, IN in_student_id int,
                                                       IN in_student_name varchar(255), IN in_order_amount int,
                                                       IN in_divide_amount int, IN in_order_time datetime,
                                                       IN in_pay_type int, IN in_pay_status int,
                                                       IN in_pay_result_msg varchar(255))
BEGIN
	INSERT INTO order_bills
    (
		order_num,
		coursebag_id,
		product_id,
		offer_id,
		student_id,
		student_name,
		order_amount,
		divide_amount,
		order_time,
		pay_type,
		pay_status,
		pay_result_msg
    )
    VALUES
    (
		in_order_num,
		in_coursebag_id,
		in_product_id,
		in_offer_id,
		in_student_id,
		in_student_name,
		in_order_amount,
		in_divide_amount,
		in_order_time,
		in_pay_type,
		in_pay_status,
		in_pay_result_msg
    );
    
END;

