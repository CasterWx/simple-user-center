create
    definer = devuser@`%` procedure course_quiz_update(IN in_id int, IN in_quiz_id int, IN in_course_id int)
BEGIN
    UPDATE course_quiz SET quiz_id = in_quiz_id, course_id = in_course_id
    WHERE id = in_id;
END;

