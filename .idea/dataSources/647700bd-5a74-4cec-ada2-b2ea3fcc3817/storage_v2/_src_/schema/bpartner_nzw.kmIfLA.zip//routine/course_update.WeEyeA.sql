create
    definer = devuser@`%` procedure course_update(IN in_id int, IN in_name varchar(64), IN in_res_id varchar(64),
                                                  IN in_external_id varchar(64), IN in_cover_img_url varchar(1000),
                                                  IN in_type int, IN in_tags varchar(512),
                                                  IN in_course_intro_url varchar(1000),
                                                  IN in_course_detail_url varchar(1000))
BEGIN
    UPDATE course SET `name` = in_name,
                      res_id = in_res_id,
                      external_id = in_external_id,
                      cover_img_url = in_cover_img_url,
                      type = in_type,
                      tags = in_tags,
                      course_intro_url = in_course_intro_url,
                      course_detail_url = in_course_detail_url
    WHERE id = in_id;
END;

