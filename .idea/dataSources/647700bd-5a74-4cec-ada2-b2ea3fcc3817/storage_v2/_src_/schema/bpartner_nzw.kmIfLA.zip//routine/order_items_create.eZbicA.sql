create
    definer = devuser@`%` procedure order_items_create(IN in_order_id int, IN in_product_id int, IN in_offer_id int,
                                                       IN in_amount int, IN in_discount_amount int,
                                                       IN in_pay_amount int, IN in_pay_type int, IN in_pay_status int,
                                                       IN in_pay_result_msg varchar(255), IN in_review_status int,
                                                       IN in_delivery_status int, IN in_invoice_status int,
                                                       OUT out_id int)
BEGIN
	INSERT INTO `order_items`
    (
		order_id,
		product_id,
		offer_id,
		amount,
		discount_amount,
		pay_amount,
		pay_type,
		pay_status,
		pay_result_msg,
		review_status,
		delivery_status,
		invoice_status
    )
    VALUES
    (
		in_order_id,
		in_product_id,
		in_offer_id,
		in_amount,
		in_discount_amount,
		in_pay_amount,
		in_pay_type,
		in_pay_status,
		in_pay_result_msg,
		in_review_status,
		in_delivery_status,
		in_invoice_status
    );
    
    SET out_id = LAST_INSERT_ID();
END;

