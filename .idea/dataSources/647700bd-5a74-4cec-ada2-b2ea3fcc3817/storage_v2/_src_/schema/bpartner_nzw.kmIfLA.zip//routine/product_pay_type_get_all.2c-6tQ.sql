create
    definer = devuser@`%` procedure product_pay_type_get_all()
BEGIN
    SELECT * FROM product_pay_type;
END;

