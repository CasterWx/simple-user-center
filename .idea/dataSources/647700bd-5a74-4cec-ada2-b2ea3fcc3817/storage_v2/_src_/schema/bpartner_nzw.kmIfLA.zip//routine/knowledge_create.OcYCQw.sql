create
    definer = devuser@`%` procedure knowledge_create(IN in_course_id int, IN in_parent_id int, IN in_sequence_num int,
                                                     IN in_name varchar(255), IN in_sub_name varchar(255),
                                                     IN in_cover_img_url varchar(1024), IN in_important_index int,
                                                     IN in_description varchar(1024), IN in_published bit,
                                                     IN in_publish_time datetime, IN in_free bit, IN in_status int,
                                                     OUT out_id int)
BEGIN
    INSERT INTO `knowledge`(`course_id`, `parent_id`, `sequence_num`, `name`, `sub_name`,
                                            `cover_img_url`, `important_index`, `description`,`published`,
                                            `publish_time`, `free`, `status`)
    values (in_course_id, in_parent_id, in_sequence_num, in_name, in_sub_name,
            in_cover_img_url, in_important_index, in_description, in_published, in_publish_time, in_free, in_status);

    SET out_id = last_insert_id();
END;

