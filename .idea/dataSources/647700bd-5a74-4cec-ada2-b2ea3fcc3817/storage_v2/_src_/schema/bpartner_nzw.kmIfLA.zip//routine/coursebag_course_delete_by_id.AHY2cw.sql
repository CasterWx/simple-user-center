create
    definer = devuser@`%` procedure coursebag_course_delete_by_id(IN in_id int)
BEGIN

    DELETE FROM coursebag_course WHERE id = in_id;

END;

