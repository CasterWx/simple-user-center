create
    definer = devuser@`%` procedure course_quiz_get_by_course_id(IN in_course_id int)
BEGIN
	SELECT * FROM course_quiz where course_id = in_course_id;
END;

