create
    definer = devuser@`%` procedure coursebag_delete_by_id(IN in_id int)
BEGIN
    DELETE FROM coursebag WHERE id = in_id;
END;

