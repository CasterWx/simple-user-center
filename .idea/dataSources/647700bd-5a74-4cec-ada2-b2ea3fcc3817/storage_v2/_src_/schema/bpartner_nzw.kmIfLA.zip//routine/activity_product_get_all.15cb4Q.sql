create
    definer = devuser@`%` procedure activity_product_get_all()
BEGIN

	SELECT * FROM activity_product;
END;

