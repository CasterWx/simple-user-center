create
    definer = devuser@`%` procedure knowledge_quiz_create(IN in_knowledge_id int, IN in_quiz_id int, IN in_free bit,
                                                          IN in_status int, OUT out_id int)
BEGIN
    INSERT INTO `knowledge_quiz` (`knowledge_id`, `quiz_id`, `free`, `status`) VALUES (in_knowledge_id, in_quiz_id, in_free, in_status);
    SET out_id = LAST_INSERT_ID();
END;

