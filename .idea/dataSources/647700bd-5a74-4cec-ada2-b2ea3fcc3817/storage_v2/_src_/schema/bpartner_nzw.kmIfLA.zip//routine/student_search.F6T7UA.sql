create
    definer = devuser@`%` procedure student_search(IN in_id int, IN in_global_user_id int,
                                                   IN in_external_user_id varchar(64), IN in_fake_phone_num varchar(20))
BEGIN
    SELECT * FROM student
	WHERE (in_id IS NULL OR id = in_id)
    AND (in_global_user_id IS NULL OR global_user_id = in_global_user_id)
	AND (in_external_user_id IS NULL OR external_user_id = in_external_user_id)
    AND (in_fake_phone_num IS NULL OR fake_phone_num = in_fake_phone_num);
END;

