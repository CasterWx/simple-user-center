create
    definer = devuser@`%` procedure student_answer_create(IN in_student_id int, IN in_course_id int,
                                                          IN in_user_quiz_id int, IN in_question_id int,
                                                          IN in_answer mediumtext, IN in_score double,
                                                          IN in_upload_time bigint, OUT out_id int)
BEGIN

	INSERT INTO `student_answer`
    (
		student_id,
		course_id,
		user_quiz_id,
		question_id,
		answer,
		score,
		upload_time
    )
    VALUES
    (
		in_student_id,
		in_course_id,
		in_user_quiz_id,
		in_question_id,
		in_answer,
		in_score,
		in_upload_time
    );
	SET out_id = LAST_INSERT_ID();

END;

