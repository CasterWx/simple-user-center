create
    definer = devuser@`%` procedure coursebag_course_get_all()
BEGIN
    SELECT id, course_id, coursebag_id, created_time, updated_time
    FROM coursebag_course;
END;

