create
    definer = devuser@`%` procedure order_items_delete_by_order_id(IN in_order_id int)
BEGIN
	DELETE FROM `order_items` WHERE order_id = in_order_id;
END;

