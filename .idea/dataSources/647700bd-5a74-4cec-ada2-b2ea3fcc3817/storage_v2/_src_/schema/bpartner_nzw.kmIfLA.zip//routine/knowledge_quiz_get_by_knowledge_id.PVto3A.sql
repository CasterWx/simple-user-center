create
    definer = devuser@`%` procedure knowledge_quiz_get_by_knowledge_id(IN in_knowledge_id int, IN in_quiz_id int,
                                                                       IN in_free int, IN in_status int)
BEGIN
    SELECT *
    FROM knowledge_quiz
    WHERE (in_knowledge_id IS NULL OR knowledge_id = in_knowledge_id)
    AND  (in_quiz_id IS NULL OR quiz_id = in_quiz_id)
    AND  (in_free IS NULL OR free = in_free)
    AND  (in_status IS NULL OR `status` = in_status);
END;

