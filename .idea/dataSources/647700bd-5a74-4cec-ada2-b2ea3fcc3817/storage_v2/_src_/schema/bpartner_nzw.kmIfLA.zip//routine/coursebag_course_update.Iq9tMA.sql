create
    definer = devuser@`%` procedure coursebag_course_update(IN in_id int, IN in_coursebag_id int, IN in_course_id int)
BEGIN
    UPDATE coursebag_course SET coursebag_id = in_coursebag_id,
                                course_id = in_course_id
    WHERE id = in_id;
END;

