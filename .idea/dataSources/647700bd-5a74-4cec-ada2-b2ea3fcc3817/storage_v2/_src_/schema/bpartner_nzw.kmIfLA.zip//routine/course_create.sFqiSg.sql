create
    definer = devuser@`%` procedure course_create(IN in_name varchar(64), IN in_res_id varchar(64),
                                                  IN in_external_id varchar(64), IN in_cover_img_url varchar(1000),
                                                  IN in_type int, IN in_tags varchar(512),
                                                  IN in_course_intro_url varchar(1000),
                                                  IN in_course_detail_url varchar(1000), OUT out_id int)
BEGIN
    INSERT INTO course (`name`, res_id, external_id, cover_img_url, type, tags,
                        course_intro_url, course_detail_url)
    values (in_name, in_res_id, in_external_id, in_cover_img_url, in_type,
            in_tags, in_course_intro_url, in_course_detail_url);
    SET out_id = last_insert_id();
END;

