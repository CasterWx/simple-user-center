create
    definer = devuser@`%` procedure student_get_by_global_user_id(IN in_global_user_id int)
BEGIN
    SELECT * FROM student
    WHERE (global_user_id = in_global_user_id);
END;

