create
    definer = devuser@`%` procedure coursebag_get_all()
BEGIN
    SELECT * FROM coursebag;
END;

