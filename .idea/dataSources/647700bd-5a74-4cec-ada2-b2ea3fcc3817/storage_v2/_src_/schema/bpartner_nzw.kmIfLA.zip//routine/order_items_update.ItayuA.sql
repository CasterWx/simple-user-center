create
    definer = devuser@`%` procedure order_items_update(IN in_id int, IN in_order_id int, IN in_product_id int,
                                                       IN in_offer_id int, IN in_amount int, IN in_discount_amount int,
                                                       IN in_pay_amount int, IN in_pay_type int, IN in_pay_status int,
                                                       IN in_pay_result_msg varchar(255), IN in_review_status int,
                                                       IN in_delivery_status int, IN in_invoice_status int,
                                                       OUT out_id int)
BEGIN
	UPDATE `order_items`
    SET
		order_id = in_order_id,
		product_id = in_product_id,
		offer_id = in_offer_id,
		discount_amount = in_discount_amount,
		amount = in_amount,
		pay_amount = in_pay_amount,
		pay_type = in_pay_type,
		pay_status = in_pay_status,
		pay_result_msg = in_pay_result_msg,
		review_status = in_review_status,
		delivery_status = in_delivery_status,
		invoice_status = in_invoice_status
	WHERE id = in_id;
END;

