create
    definer = devuser@`%` procedure student_create(IN in_global_user_id int, IN in_external_user_id varchar(64),
                                                   IN in_external_token varchar(1024), IN in_extra_data varchar(1024),
                                                   IN in_fake_phone_num varchar(20), OUT out_id int)
BEGIN

 	INSERT INTO `student`
    (
		global_user_id,
		external_user_id,
		external_token,
		extra_data,
        fake_phone_num
    )
    VALUES
    (
		in_global_user_id,
		in_external_user_id,
		in_external_token,
		in_extra_data,
        in_fake_phone_num
    );
	SET out_id = LAST_INSERT_ID();

 END;

