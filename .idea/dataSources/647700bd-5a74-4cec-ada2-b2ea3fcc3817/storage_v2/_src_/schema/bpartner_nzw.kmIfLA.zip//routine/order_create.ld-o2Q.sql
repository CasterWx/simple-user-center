create
    definer = devuser@`%` procedure order_create(IN in_order_num varchar(255), IN in_content varchar(1000),
                                                 IN in_student_id int, IN in_total_amount int, IN in_receipt_amount int,
                                                 IN in_discount_amount int, IN in_buyer_pay_amount int,
                                                 IN in_buyer_discount_amount int, IN in_invoice_amount int,
                                                 IN in_order_time datetime, IN in_expired_time datetime,
                                                 IN in_creator_id int, IN in_client_type int, IN in_pay_type int,
                                                 IN in_pay_status int, IN in_pay_result_msg varchar(255),
                                                 IN in_review_status int, IN in_delivery_status int,
                                                 IN in_invoice_status int, IN in_payee_account varchar(255),
                                                 IN in_payee_name varchar(255), OUT out_id int)
BEGIN
	INSERT INTO `order`
    (
		order_num,
		content,
		student_id,
		total_amount,
		receipt_amount,
		discount_amount,
		buyer_pay_amount,
		buyer_discount_amount,
		invoice_amount,
		order_time,
		expired_time,
		creator_id,
		client_type,
		pay_type,
		pay_status,
		pay_result_msg,
		review_status,
		delivery_status,
		invoice_status,
		payee_account,
		payee_name
    )
    VALUES
    (
		in_order_num,
		in_content,
		in_student_id,
		in_total_amount,
		in_receipt_amount,
		in_discount_amount,
		in_buyer_pay_amount,
		in_buyer_discount_amount,
		in_invoice_amount,
		in_order_time,
		in_expired_time,
		in_creator_id,
		in_client_type,
		in_pay_type,
		in_pay_status,
		in_pay_result_msg,
		in_review_status,
		in_delivery_status,
		in_invoice_status,
		in_payee_account,
		in_payee_name
    );
    
    SET out_id = LAST_INSERT_ID();
END;

