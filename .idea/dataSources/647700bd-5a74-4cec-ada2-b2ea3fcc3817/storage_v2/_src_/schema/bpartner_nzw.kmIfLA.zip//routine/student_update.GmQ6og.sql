create
    definer = devuser@`%` procedure student_update(IN in_id int, IN in_global_user_id int,
                                                   IN in_external_user_id varchar(64),
                                                   IN in_external_token varchar(1024), IN in_extra_data varchar(1024),
                                                   IN in_fake_phone_num varchar(20))
BEGIN
	UPDATE `student`
    SET
		global_user_id = in_global_user_id,
		external_user_id = in_external_user_id,
		external_token = in_external_token,
		extra_data = in_extra_data,
        fake_phone_num = in_fake_phone_num
	WHERE id = in_id;
END;

