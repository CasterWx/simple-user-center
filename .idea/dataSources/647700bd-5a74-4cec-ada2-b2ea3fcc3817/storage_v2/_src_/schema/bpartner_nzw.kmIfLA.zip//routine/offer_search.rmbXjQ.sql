create
    definer = devuser@`%` procedure offer_search(IN in_id int, IN in_product_id int)
BEGIN
	SELECT * FROM offer 
    WHERE (in_id IS NULL OR id = in_id)
	AND (in_product_id IS NULL OR product_id = in_product_id);
END;

