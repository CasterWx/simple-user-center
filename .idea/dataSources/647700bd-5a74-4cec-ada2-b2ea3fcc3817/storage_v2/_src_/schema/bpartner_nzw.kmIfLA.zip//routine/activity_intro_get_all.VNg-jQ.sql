create
    definer = devuser@`%` procedure activity_intro_get_all()
BEGIN
    SELECT * FROM activity_intro;
END;

