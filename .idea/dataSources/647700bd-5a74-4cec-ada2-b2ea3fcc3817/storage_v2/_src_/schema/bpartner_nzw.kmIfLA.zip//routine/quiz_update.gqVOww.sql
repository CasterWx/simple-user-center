create
    definer = devuser@`%` procedure quiz_update(IN in_id int, IN in_res_id varchar(64), IN in_external_id varchar(64),
                                                IN in_title varchar(128), IN in_cover_img_url varchar(1000),
                                                IN in_tags varchar(512), IN in_status int, IN in_score double,
                                                IN in_total_time bigint, IN in_year int, IN in_free bit)
BEGIN
	UPDATE quiz
    SET
		res_id = in_res_id,
		external_id = in_external_id,
		title = in_title,
		cover_img_url = in_cover_img_url,
		tags = in_tags,
		status = in_status,
		score = in_score,
		total_time = in_total_time,
		year = in_year,
		free = in_free
	WHERE id = in_id;

END;

