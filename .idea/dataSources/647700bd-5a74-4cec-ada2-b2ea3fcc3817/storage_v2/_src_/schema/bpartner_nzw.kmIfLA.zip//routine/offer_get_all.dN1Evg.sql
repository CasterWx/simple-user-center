create
    definer = devuser@`%` procedure offer_get_all()
BEGIN

    SELECT * FROM offer;

END;

