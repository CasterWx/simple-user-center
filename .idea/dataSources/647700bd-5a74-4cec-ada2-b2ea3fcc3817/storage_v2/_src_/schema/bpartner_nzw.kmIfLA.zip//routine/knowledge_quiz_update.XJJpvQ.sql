create
    definer = devuser@`%` procedure knowledge_quiz_update(IN in_id int, IN in_knowledge_id int, IN in_quiz_id int,
                                                          IN in_free bit, IN in_status int)
BEGIN
    UPDATE knowledge_quiz SET `knowledge_id` = in_knowledge_id,
                              `quiz_id` = in_quiz_id,
                              `free` = in_free,
                              `status` = in_status
    WHERE id = in_id;
END;

