create
    definer = devuser@`%` procedure coursebag_course_get_by_coursebag_id(IN in_coursebag_id int)
BEGIN

    SELECT id, course_id, coursebag_id, created_time, updated_time
    FROM coursebag_course WHERE coursebag_id = in_coursebag_id;

END;

