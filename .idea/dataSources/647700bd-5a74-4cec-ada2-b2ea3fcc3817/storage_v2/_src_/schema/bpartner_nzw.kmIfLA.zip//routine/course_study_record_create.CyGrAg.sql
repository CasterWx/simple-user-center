create
    definer = devuser@`%` procedure course_study_record_create(IN in_student_id int, IN in_coursebag_id int,
                                                               IN in_course_id int, IN in_knowledge_id int,
                                                               IN in_data_id int, IN in_data_type int,
                                                               IN in_start_time datetime, IN in_end_time datetime,
                                                               IN in_time_point int, IN in_client_type int,
                                                               OUT out_id int)
BEGIN

	INSERT course_study_record (student_id, coursebag_id, course_id, knowledge_id, data_id, data_type, start_time, end_time, time_point, client_type)

	VALUES (in_student_id, in_coursebag_id, in_course_id, in_knowledge_id, in_data_id, in_data_type, CASE WHEN in_start_time IS NULL THEN NOW() ELSE in_start_time END,
    CASE WHEN in_end_time IS NULL THEN NOW() ELSE in_end_time END, in_time_point, in_client_type);

	SET out_id = LAST_INSERT_ID();

END;

