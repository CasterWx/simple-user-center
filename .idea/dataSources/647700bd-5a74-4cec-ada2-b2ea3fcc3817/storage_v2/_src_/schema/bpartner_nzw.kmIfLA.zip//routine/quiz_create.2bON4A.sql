create
    definer = devuser@`%` procedure quiz_create(IN in_res_id varchar(64), IN in_external_id varchar(64),
                                                IN in_title varchar(128), IN in_cover_img_url varchar(1000),
                                                IN in_tags varchar(512), IN in_status int, IN in_score double,
                                                IN in_total_time bigint, IN in_year int, IN in_free bit, OUT out_id int)
BEGIN
	INSERT INTO quiz
    (
		res_id,
		external_id,
		title,
		cover_img_url,
		tags,
		status,
		score,
		total_time,
		year,
		free
    )
    VALUES
    (
		in_res_id,
		in_external_id,
		in_title,
		in_cover_img_url,
		in_tags,
		in_status,
		in_score,
		in_total_time,
		in_year,
		in_free
    );
    SET out_id = last_insert_id();

END;

