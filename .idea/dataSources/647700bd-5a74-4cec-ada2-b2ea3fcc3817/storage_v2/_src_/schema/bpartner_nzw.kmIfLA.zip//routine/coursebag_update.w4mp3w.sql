create
    definer = devuser@`%` procedure coursebag_update(IN in_id int, IN in_name varchar(200), IN in_description text,
                                                     IN in_cover_img_url varchar(1000), IN in_intro_url varchar(1000),
                                                     IN in_start_time datetime, IN in_end_time datetime,
                                                     IN in_tags varchar(512))
BEGIN
    UPDATE coursebag SET name = in_name,
                         description = in_description,
                         cover_img_url = in_cover_img_url,
                         intro_url = in_intro_url,
                         start_time = in_start_time,
                         end_time = in_end_time,
                         tags = in_tags
    WHERE id = in_id;

END;

