create
    definer = devuser@`%` procedure coursebag_get_by_id(IN in_id int)
BEGIN
    SELECT * FROM coursebag WHERE id = in_id;
END;

