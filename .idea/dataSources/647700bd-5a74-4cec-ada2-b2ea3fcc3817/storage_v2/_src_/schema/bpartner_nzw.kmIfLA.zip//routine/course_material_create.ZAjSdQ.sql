create
    definer = devuser@`%` procedure course_material_create(IN in_course_id int, IN in_knowledge_id int,
                                                           IN in_sequence_num int, IN in_name varchar(255),
                                                           IN in_content_id int, IN in_type int, IN in_free bit,
                                                           IN in_status int, OUT out_id int)
BEGIN

	INSERT course_material (course_id, knowledge_id, sequence_num, name, content_id, type, free, status)
	VALUES (in_course_id, in_knowledge_id, in_sequence_num, in_name, in_content_id, in_type, in_free, in_status);

	SET out_id = LAST_INSERT_ID();

END;

