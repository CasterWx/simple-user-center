create
    definer = devuser@`%` procedure order_delete(IN in_id int)
BEGIN
	DELETE FROM `order` WHERE id = in_id; 
END;

