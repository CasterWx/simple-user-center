create
    definer = devuser@`%` procedure student_coursebag_update(IN in_id int, IN in_student_id int, IN in_coursebag_id int,
                                                             IN in_trial bit, IN in_expired_time datetime,
                                                             IN in_token varchar(1024))
BEGIN
	UPDATE `student_coursebag`
    SET
		student_id = in_student_id,
		coursebag_id = in_coursebag_id,
		trial = in_trial,
		token = in_token,
		expired_time = in_expired_time
	WHERE id = in_id;
END;

