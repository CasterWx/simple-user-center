create
    definer = devuser@`%` procedure question_expand_get_by_ids(IN in_id_list text, IN in_with_children tinyint)
BEGIN
	SET @sql = "SELECT q.*, o.id AS o_id, o.label AS o_label, o.question_id AS o_question_id, o.description AS o_description
    FROM question q 
    LEFT JOIN `option` o ON q.id = o.question_id where 1 = 1";
	IF in_id_list IS NOT NULL
		THEN SET @sql = CONCAT(@sql, " AND q.id in (", in_id_list, ")");
	END IF;
	IF in_with_children = 1
		THEN SET @sql = CONCAT(@sql, " OR q.parent_id in (", in_id_list, ")");
	END IF;
	PREPARE stmt FROM @sql;
    EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END;

