create
    definer = devuser@`%` procedure quiz_question_get_by_quiz_id(IN in_quiz_id int)
BEGIN
	SELECT * FROM quiz_question where quiz_id = in_quiz_id;
END;

