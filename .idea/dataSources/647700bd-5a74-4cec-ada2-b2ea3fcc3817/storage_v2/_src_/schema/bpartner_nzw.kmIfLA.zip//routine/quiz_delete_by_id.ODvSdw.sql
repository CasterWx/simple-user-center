create
    definer = devuser@`%` procedure quiz_delete_by_id(IN in_id int)
BEGIN
    DELETE FROM quiz WHERE id = in_id;
END;

