create
    definer = devuser@`%` procedure coursebag_create(IN in_name varchar(200), IN in_description text,
                                                     IN in_cover_img_url varchar(1000), IN in_intro_url varchar(1000),
                                                     IN in_start_time datetime, IN in_end_time datetime,
                                                     IN in_tags varchar(512), OUT out_id int)
BEGIN
    INSERT INTO coursebag (name, description, cover_img_url, intro_url, start_time, end_time, tags)
    VALUES (in_name, in_description, in_cover_img_url, in_intro_url, in_start_time, in_end_time, in_tags);
    SET out_id = last_insert_id();
END;

