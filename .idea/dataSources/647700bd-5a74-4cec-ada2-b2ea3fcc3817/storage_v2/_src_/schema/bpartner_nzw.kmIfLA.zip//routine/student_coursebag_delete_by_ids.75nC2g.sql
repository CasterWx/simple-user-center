create
    definer = devuser@`%` procedure student_coursebag_delete_by_ids(IN in_id_list mediumtext)
BEGIN

	SET @sql = CONCAT("DELETE FROM student_coursebag WHERE id in (", in_id_list, ")");
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

END;

