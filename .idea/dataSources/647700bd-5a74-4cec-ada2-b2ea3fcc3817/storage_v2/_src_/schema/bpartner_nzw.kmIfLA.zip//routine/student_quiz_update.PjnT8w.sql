create
    definer = devuser@`%` procedure student_quiz_update(IN in_id int, IN in_student_id int, IN in_coursebag_id int,
                                                        IN in_quiz_id int, IN in_course_id int, IN in_knowledge_id int,
                                                        IN in_answer_type int, IN in_score double,
                                                        IN in_answered_count int, IN in_correct_count int,
                                                        IN in_correct_rate double, IN in_upload_time bigint,
                                                        IN in_time_spent bigint)
BEGIN

 	UPDATE `student_quiz`
    SET
		student_id = in_student_id,
		coursebag_id = in_coursebag_id,
		quiz_id = in_quiz_id,
		course_id = in_course_id,
		knowledge_id = in_knowledge_id,
		answer_type = in_answer_type,
		score = in_score,
		answered_count = in_answered_count,
		correct_count = in_correct_count,
		correct_rate = in_correct_rate,
		upload_time = in_upload_time,
		time_spent = in_time_spent
    WHERE id = in_id;
 END;

