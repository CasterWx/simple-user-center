create
    definer = devuser@`%` procedure student_coursebag_search(IN in_student_id int, IN in_coursebag_id int)
BEGIN
    SELECT * FROM student_coursebag
    WHERE (in_student_id IS NULL OR student_id = in_student_id)
	AND (in_coursebag_id IS NULL OR coursebag_id = in_coursebag_id);
END;

