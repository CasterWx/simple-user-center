create
    definer = devuser@`%` procedure knowledge_delete_by_id(IN in_id int)
BEGIN

    DELETE FROM knowledge WHERE id = in_id;

END;

