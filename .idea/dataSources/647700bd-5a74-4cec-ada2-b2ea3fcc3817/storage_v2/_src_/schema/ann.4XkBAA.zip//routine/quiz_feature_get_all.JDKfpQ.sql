create
    definer = devuser@`%` procedure quiz_feature_get_all()
BEGIN
	SELECT * FROM quiz_feature;
END;

