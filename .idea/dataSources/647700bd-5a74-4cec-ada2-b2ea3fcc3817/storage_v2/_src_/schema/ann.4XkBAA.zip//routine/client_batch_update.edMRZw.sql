create
    definer = devuser@`%` procedure client_batch_update(IN in_uuid char(36), IN in_stat int)
BEGIN
    update client_batch 
    SET stat = in_stat
	WHERE  uuid = in_uuid;
END;

