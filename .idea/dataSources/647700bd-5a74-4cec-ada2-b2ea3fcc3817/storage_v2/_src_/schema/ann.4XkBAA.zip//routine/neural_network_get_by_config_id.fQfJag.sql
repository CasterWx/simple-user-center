create
    definer = devuser@`%` procedure neural_network_get_by_config_id(IN in_config_id char(36))
BEGIN
	SELECT * FROM neural_network WHERE config_id = in_config_id;
END;

