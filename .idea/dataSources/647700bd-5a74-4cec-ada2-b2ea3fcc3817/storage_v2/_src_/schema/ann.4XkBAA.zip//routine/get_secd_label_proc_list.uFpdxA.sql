create
    definer = devuser@`%` procedure get_secd_label_proc_list()
BEGIN
	select * from secd_label_process;
END;

