create
    definer = devuser@`%` procedure get_secd_label_state_list()
BEGIN
    SELECT * FROM secd_label_state;
END;

