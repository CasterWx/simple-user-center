create
    definer = devuser@`%` procedure batch_get_by_quiz_id(IN in_quiz_insert_id int)
BEGIN
    SELECT * FROM batch
	WHERE  quiz_insert_id = in_quiz_insert_id	
	ORDER BY created_time DESC
	LIMIT 1;
END;

