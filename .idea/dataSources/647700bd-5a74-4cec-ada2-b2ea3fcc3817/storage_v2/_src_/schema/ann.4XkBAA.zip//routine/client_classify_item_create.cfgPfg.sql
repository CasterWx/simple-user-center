create
    definer = devuser@`%` procedure client_classify_item_create(IN in_batch_id char(36), IN in_sequence int,
                                                                IN in_content longtext, IN in_predict_result int)
BEGIN
   INSERT INTO client_classify_item(batch_id,sequence,content,predict_result)
   VALUE(in_batch_id,in_sequence,in_content,in_predict_result);
END;

