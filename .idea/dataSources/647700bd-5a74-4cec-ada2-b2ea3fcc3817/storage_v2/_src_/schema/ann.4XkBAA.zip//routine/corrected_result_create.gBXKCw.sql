create
    definer = devuser@`%` procedure corrected_result_create(IN in_batch_id char(36), IN in_sequence int,
                                                            IN in_content longtext, IN in_label_code int,
                                                            IN in_start_line_num int, IN in_end_line_num int)
BEGIN
   INSERT INTO corrected_item(batch_id,sequence,content,label_code,start_line,end_line)
   VALUE(in_batch_id,in_sequence,in_content,in_label_code,in_start_line_num,in_end_line_num);
END;

