create
    definer = devuser@`%` procedure get_secd_format_list()
BEGIN
    SELECT * FROM secd_format;
END;

