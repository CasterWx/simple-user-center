create
    definer = devuser@`%` procedure neural_network_create(IN in_config_id char(36), IN in_network_type int,
                                                          IN in_layer_size int, IN in_name varchar(100),
                                                          IN in_description varchar(1000),
                                                          IN in_variable_file varchar(1000), OUT out_id int)
BEGIN
    INSERT INTO neural_network (`config_id`, `network_type`, `layer_size`, `name`, `description`, `variable_file`)
    VALUE (in_config_id, in_network_type, in_layer_size, in_name, in_description, in_variable_file);
    
    SET out_id = LAST_INSERT_ID();
END;

