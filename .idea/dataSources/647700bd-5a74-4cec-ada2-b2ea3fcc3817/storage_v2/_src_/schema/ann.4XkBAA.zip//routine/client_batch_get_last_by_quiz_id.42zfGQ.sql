create
    definer = devuser@`%` procedure client_batch_get_last_by_quiz_id(IN in_quiz_insert_id int)
BEGIN
    SELECT * FROM client_batch
	WHERE  quiz_insert_id = in_quiz_insert_id	
	ORDER BY batch_seq DESC
	LIMIT 1;
END;

