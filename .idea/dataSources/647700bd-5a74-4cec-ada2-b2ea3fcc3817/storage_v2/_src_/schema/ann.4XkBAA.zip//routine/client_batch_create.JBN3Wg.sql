create
    definer = devuser@`%` procedure client_batch_create(IN in_quiz_insert_id int, IN in_uuid char(36),
                                                        IN in_model_id varchar(20), IN in_stat int,
                                                        IN in_predict_quiz_type int, IN in_batch_seq int)
BEGIN
   INSERT INTO client_batch(uuid, quiz_insert_id, model_id, stat, predict_quiz_type, batch_seq)
   VALUE(in_uuid, in_quiz_insert_id, in_model_id, in_stat, in_predict_quiz_type, in_batch_seq);
END;

