create
    definer = devuser@`%` procedure node_get_by_neural_network_id(IN in_neural_network_id int)
BEGIN
	SELECT * FROM node WHERE neural_network_id = in_neural_network_id;
END;

