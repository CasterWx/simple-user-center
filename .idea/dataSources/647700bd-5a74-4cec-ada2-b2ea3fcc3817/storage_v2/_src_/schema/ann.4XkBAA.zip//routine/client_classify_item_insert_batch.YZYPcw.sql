create
    definer = devuser@`%` procedure client_classify_item_insert_batch(IN in_value longtext)
BEGIN
	set @exeSql=concat("INSERT INTO client_classify_item(batch_id,sequence,content,predict_result) VALUES ", in_value);  
	prepare stmt from @exeSql;  
	EXECUTE stmt;  
	deallocate prepare stmt; 
END;

