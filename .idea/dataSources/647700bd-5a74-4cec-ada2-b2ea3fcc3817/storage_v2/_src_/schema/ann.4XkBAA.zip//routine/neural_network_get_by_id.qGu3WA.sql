create
    definer = devuser@`%` procedure neural_network_get_by_id(IN in_id int)
BEGIN
	SELECT * FROM neural_network WHERE `id`=in_id;
END;

