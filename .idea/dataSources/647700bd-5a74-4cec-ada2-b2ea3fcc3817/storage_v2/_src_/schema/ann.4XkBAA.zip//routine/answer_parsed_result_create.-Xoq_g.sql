create
    definer = devuser@`%` procedure answer_parsed_result_create(IN in_batch_id varchar(36),
                                                                IN in_headline_type varchar(80), IN in_sequence int,
                                                                IN in_content text, IN in_analysis text)
BEGIN
    INSERT INTO answer_parse_result (batch_id, headline_type, sequence, content, analysis) VALUE (in_batch_id, in_headline_type, in_sequence, in_content, in_analysis);
END;

