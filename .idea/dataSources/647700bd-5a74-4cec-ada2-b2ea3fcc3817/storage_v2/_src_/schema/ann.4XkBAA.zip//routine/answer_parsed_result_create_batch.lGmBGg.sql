create
    definer = devuser@`%` procedure answer_parsed_result_create_batch(IN in_value longtext)
BEGIN
    set @exesql=concat("INSERT INTO answer_parse_result(batch_id, headline_type, sequence, content, analysis) VALUES ", in_value);
    prepare stmt from @exesql;
    execute stmt;
    deallocate prepare stmt;
END;

