create
    definer = devuser@`%` procedure answer_parse_item_create_batch(IN in_value longtext)
BEGIN
    set @exesql=concat("INSERT INTO answer_parse_item(batch_id, sequence, content) VALUES ", in_value);
    prepare stmt from @exesql;
    execute stmt;
    deallocate prepare stmt;
END;

