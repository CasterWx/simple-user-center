create
    definer = devuser@`%` procedure client_corrected_item_insert_batch(IN in_value longtext)
BEGIN
	set @exeSql=concat("INSERT INTO client_corrected_item(batch_id,sequence,content,line_num,label_code,start_line,end_line,question_type,`status`) VALUES ", in_value);  
	prepare stmt from @exeSql;  
	EXECUTE stmt;  
	deallocate prepare stmt; 
END;

