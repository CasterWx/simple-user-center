create
    definer = devuser@`%` procedure get_user_label_proc_list()
BEGIN
	select sp.id, sp.`type`, sp.type_desc, sp.priority_level, sr.regex as regex_pattern, sr.regex_desc, sp.user_label_classify_code, sp.user_label_classify_desc
    from user_label_process sp inner join secd_regex sr on sp.regex_code = sr.`code`;
END;

