create
    definer = devuser@`%` procedure secd_analyze_result_create_batch(IN in_value longtext)
BEGIN
    set @exesql=concat("INSERT INTO secd_analyze_result(batch_id,content,label_code, line_num, match_ids, match_desc, stage_code, stage_desc, status, status_desc) VALUES ", in_value);
    prepare stmt from @exesql;
    execute stmt;
    deallocate prepare stmt;
END;

