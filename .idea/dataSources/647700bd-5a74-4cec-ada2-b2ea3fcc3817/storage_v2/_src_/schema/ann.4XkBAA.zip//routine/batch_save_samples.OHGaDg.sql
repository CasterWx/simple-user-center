create
    definer = devuser@`%` procedure batch_save_samples(IN in_sample_list text)
BEGIN

	DECLARE i INT DEFAULT 1;
	DECLARE	count INT(11);
    
	DROP TEMPORARY TABLE IF EXISTS sample_temp_tbl;
	CREATE TEMPORARY TABLE sample_temp_tbl(
		`quiz_insert_id` INT(11),
		`origin_content` LONGTEXT,
		`content` LONGTEXT
	);
    

	SET SQL_SAFE_UPDATES=0;
	SET count = ExtractValue(in_sample_list, 'count(//S)');
	WHILE i <= count DO
		INSERT INTO sample_temp_tbl (quiz_insert_id, origin_content, content) 
		VALUES (
			CAST(ExtractValue(in_sample_list,  '/SL/S[$i]/Q') AS SIGNED),
			CAST(ExtractValue(in_sample_list,  '/SL/S[$i]/O') AS CHAR(6000) CHARACTER set utf8),
			CAST(ExtractValue(in_sample_list,  '/SL/S[$i]/C') AS CHAR(6000) CHARACTER set utf8)
            );
		SET i = i+1;
	END WHILE;

	INSERT INTO sample_collected (quiz_insert_id, origin_content, content)
	SELECT quiz_insert_id, origin_content, content FROM sample_temp_tbl;

	DROP TEMPORARY TABLE IF EXISTS sample_temp_tbl;

END;

