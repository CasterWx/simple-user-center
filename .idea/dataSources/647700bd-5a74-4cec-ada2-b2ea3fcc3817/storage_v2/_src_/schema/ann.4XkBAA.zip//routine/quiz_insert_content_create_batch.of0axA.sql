create
    definer = devuser@`%` procedure quiz_insert_content_create_batch(IN in_value longtext)
BEGIN
    set @exesql=concat("INSERT INTO quiz_insert_content(batch_id,sequence,content) VALUES ", in_value);
    prepare stmt from @exesql;
    execute stmt;
    deallocate prepare stmt;
END;

