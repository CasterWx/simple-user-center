create
    definer = devuser@`%` procedure neural_network_delete(IN in_id int)
BEGIN
	DELETE FROM neural_network WHERE `id`=in_id;
END;

