create
    definer = devuser@`%` procedure client_correction_item_create(IN in_batch_id char(36), IN in_sequence int,
                                                                  IN in_source_sequence int,
                                                                  IN in_correction_action_type varchar(40),
                                                                  IN in_content longtext, IN in_source_content longtext)
BEGIN
   INSERT INTO client_correction_item(batch_id,sequence,source_sequence,correction_action_type,content,source_content)
   VALUE(in_batch_id,in_sequence,in_source_sequence,in_correction_action_type,in_content,in_source_content);
END;

