create
    definer = devuser@`%` procedure get_process_reg_list()
BEGIN
    SELECT * FROM answer_process_pattern;
END;

