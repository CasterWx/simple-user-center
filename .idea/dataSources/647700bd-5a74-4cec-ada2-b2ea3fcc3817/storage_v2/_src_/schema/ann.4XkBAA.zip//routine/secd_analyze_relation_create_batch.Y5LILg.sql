create
    definer = devuser@`%` procedure secd_analyze_relation_create_batch(IN in_value longtext)
BEGIN
    set @exesql=concat("INSERT INTO secd_analyze_relation(batch_id,line_num, source_line_num, stage_code, stage_desc) VALUES ", in_value);
    prepare stmt from @exesql;
    execute stmt;
    deallocate prepare stmt;
END;

