create
    definer = devuser@`%` procedure node_batch_add_list(IN in_neural_network_id int, IN in_node_list text)
BEGIN
	
	DECLARE i INT DEFAULT 1;
	DECLARE	count INT(11);
    
	DROP TEMPORARY TABLE IF EXISTS node_temp_tbl;
	CREATE TEMPORARY TABLE node_temp_tbl(
		activation_function INT(11),
		layer INT(11),
		sequence INT(11)
	);
    

	SET SQL_SAFE_UPDATES=0;
	SET count = ExtractValue(in_node_list, 'count(//N)');
	WHILE i <= count DO
		INSERT INTO node_temp_tbl (activation_function, layer, sequence) 
		VALUES (
			CAST(ExtractValue(in_node_list,  '/NL/N[$i]/A') AS SIGNED),
			CAST(ExtractValue(in_node_list,  '/NL/N[$i]/L') AS SIGNED),
			CAST(ExtractValue(in_node_list,  '/NL/N[$i]/S') AS SIGNED)
            );
		SET i = i+1;
	END WHILE;

	INSERT INTO node (neural_network_id, activation_function, layer, sequence)
	SELECT in_neural_network_id, activation_function, layer, sequence FROM node_temp_tbl;

	DROP TEMPORARY TABLE IF EXISTS node_temp_tbl;
END;

