create
    definer = devuser@`%` procedure server_classify_item_create(IN in_batch_id varchar(36), IN in_sequence int, IN in_content text)
BEGIN
    INSERT INTO server_classify_item (batch_id, sequence, content) VALUE (in_batch_id, in_sequence, in_content);
END;

