create
    definer = devuser@`%` procedure get_match_reg_list()
BEGIN
    SELECT * FROM answer_match_pattern;
END;

