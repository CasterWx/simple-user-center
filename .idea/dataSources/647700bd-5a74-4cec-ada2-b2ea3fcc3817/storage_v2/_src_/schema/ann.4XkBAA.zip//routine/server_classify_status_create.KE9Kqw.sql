create
    definer = devuser@`%` procedure server_classify_status_create(IN in_batch_id varchar(36), IN in_status varchar(80),
                                                                  IN in_model_code varchar(80))
BEGIN 
    INSERT INTO server_classify_status (batch_id, status, model_code) VALUE (in_batch_id, in_status, in_model_code);
END;

