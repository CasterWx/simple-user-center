create
    definer = devuser@`%` procedure neural_network_update(IN in_id int, IN in_name varchar(100),
                                                          IN in_description varchar(1000),
                                                          IN in_variable_file varchar(1000))
BEGIN
	UPDATE neural_network SET `name` = in_name, description = in_description, `variable_file` = in_variable_file, updated_time = NOW()
    WHERE `id` = in_id;
END;

