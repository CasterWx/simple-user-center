create
    definer = devuser@`%` procedure neural_network_search(IN in_name varchar(100), IN in_description varchar(1000),
                                                          IN in_offset int, IN in_count int, OUT out_total_records int)
BEGIN
	SELECT SQL_CALC_FOUND_ROWS * FROM neural_network
    WHERE (in_name IS NULL OR `name` LIKE concat('%',in_name,'%') )
    AND (in_description IS NULL OR `description` LIKE concat('%',in_description,'%') )
    LIMIT in_offset, in_count;
    
    SET out_total_records = FOUND_ROWS();
END;

