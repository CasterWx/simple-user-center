create
    definer = devuser@`%` procedure school_module_update(IN in_id int, IN in_school_id int, IN in_role_id int,
                                                         IN in_module_id int, IN in_parent_module_id int,
                                                         IN in_order int, IN in_show_in_homepage int,
                                                         IN in_show_in_nav int)
BEGIN

    UPDATE `npdb`.`school_module`
    SET 
    `school_id` = in_school_id,
    `role_id` = in_role_id,
    `module_id` = in_module_id,
    `parent_module_id` = in_parent_module_id,
    `order` = in_order,
    `show_in_homepage` = in_show_in_homepage,
    `show_in_nav` = in_show_in_nav
    WHERE `id` = in_id;

END;

