create
    definer = devuser@`%` procedure short_url_create(IN in_hash varchar(20), IN in_target_url varchar(500),
                                                     IN in_expried_time datetime, IN in_status int)
BEGIN

	INSERT INTO `short_url`(
		`hash`, 
        `target_url`, 
        `expried_time`, 
        `status`
    )
    VALUES(
		in_hash, 
        in_target_url, 
        in_expried_time, 
        in_status
    );
	
END;

