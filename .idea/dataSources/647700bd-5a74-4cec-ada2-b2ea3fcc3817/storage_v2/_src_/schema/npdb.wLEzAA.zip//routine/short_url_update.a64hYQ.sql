create
    definer = devuser@`%` procedure short_url_update(IN in_hash varchar(20), IN in_target_url varchar(500),
                                                     IN in_expried_time datetime, IN in_status int)
BEGIN

	UPDATE `short_url` SET `target_url` = in_target_url, 
						 `expried_time` = in_expried_time, 
							   `status` = in_status
					   WHERE `hash` = in_hash ;
	
END;

