create
    definer = devuser@`%` procedure module_package_get_all()
BEGIN
    SELECT * FROM module_package;
END;

