create
    definer = devuser@`%` procedure marketing_sms_config_search(IN in_school_id int, IN in_res_type int, IN in_res_id int)
BEGIN
	SELECT * FROM `marketing_sms_config`
	WHERE (in_school_id is NULL OR school_id = in_school_id)
	AND (in_res_type is NULL OR res_type = in_res_type)
	AND (in_res_id is NULL OR res_id = in_res_id);
END;

