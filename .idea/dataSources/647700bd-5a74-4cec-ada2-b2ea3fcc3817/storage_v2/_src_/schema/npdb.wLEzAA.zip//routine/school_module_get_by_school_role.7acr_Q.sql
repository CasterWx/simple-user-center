create
    definer = devuser@`%` procedure school_module_get_by_school_role(IN in_school_id int, IN in_role_id int)
BEGIN
	SELECT
		sm.*, m. NAME AS moduleName,
		m.url AS moduleUrl,
		m.target
	FROM
		school_module sm
	INNER JOIN module m ON sm.module_id = m.id
	WHERE
		sm.school_id = in_school_id
	AND sm.role_id = in_role_id
	ORDER BY
		sm.parent_module_id,
		sm.`order`,
		m.id ; 
END;

