create
    definer = devuser@`%` procedure short_url_delete(IN in_hash varchar(20))
BEGIN

	DELETE FROM `short_url` WHERE `hash` = in_hash ;
	
END;

