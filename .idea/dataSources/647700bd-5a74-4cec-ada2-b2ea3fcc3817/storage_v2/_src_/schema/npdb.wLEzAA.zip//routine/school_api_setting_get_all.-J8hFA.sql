create
    definer = devuser@`%` procedure school_api_setting_get_all()
BEGIN

    SELECT * FROM school_api_setting;

END;

