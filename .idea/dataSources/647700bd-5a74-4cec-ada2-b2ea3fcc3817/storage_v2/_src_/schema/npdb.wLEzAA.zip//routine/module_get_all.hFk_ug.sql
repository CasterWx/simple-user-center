create
    definer = devuser@`%` procedure module_get_all()
BEGIN
    SELECT * FROM module;
END;

