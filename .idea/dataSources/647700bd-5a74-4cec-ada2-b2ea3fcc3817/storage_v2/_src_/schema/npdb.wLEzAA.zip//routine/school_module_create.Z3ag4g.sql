create
    definer = devuser@`%` procedure school_module_create(IN in_school_id int, IN in_school_category_type int)
BEGIN

    INSERT INTO `school_module`(`school_id`, `role_id`, `module_id`, `parent_module_id`, `order`, `show_in_homepage`, `show_in_nav`)
    SELECT 
        in_school_id,
        mp.role_id,
        mp.module_id,
        mp.parent_module_id,
        CASE WHEN  mp.role_id = 0 THEN mp.module_id ELSE 0 END,
        CASE WHEN  mp.role_id = 0 AND mp.module_id != 3  THEN 1 ELSE 0 END,
        CASE WHEN  mp.role_id = 0 AND mp.module_id != 3  THEN 1 ELSE 0 END 
        
    FROM `npdb`.module_package AS mp
    WHERE mp.school_category_type = in_school_category_type
    ORDER BY mp.role_id, mp.module_id;

END;

