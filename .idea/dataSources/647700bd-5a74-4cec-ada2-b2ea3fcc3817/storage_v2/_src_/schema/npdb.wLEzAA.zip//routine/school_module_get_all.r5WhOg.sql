create
    definer = devuser@`%` procedure school_module_get_all()
BEGIN
    SELECT * FROM school_module;
END;

