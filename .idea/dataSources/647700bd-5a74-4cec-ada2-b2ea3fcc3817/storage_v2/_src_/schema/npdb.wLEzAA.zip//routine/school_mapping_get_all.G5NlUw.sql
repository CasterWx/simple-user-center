create
    definer = devuser@`%` procedure school_mapping_get_all()
BEGIN
    SELECT * FROM school_mapping;
END;

