create
    definer = devuser@`%` procedure search_hierarchy_param_get_by_catalog_type(IN in_catalog_type int)
BEGIN
	SELECT *
	FROM search_hierarchy_param
	WHERE catalog_type = in_catalog_type
	ORDER BY threshold DESC;
END;

