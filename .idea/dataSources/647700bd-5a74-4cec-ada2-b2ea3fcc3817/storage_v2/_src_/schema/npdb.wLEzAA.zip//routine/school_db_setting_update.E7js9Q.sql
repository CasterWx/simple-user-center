create
    definer = devuser@`%` procedure school_db_setting_update(IN in_id int, IN in_school_id int, IN in_url varchar(500),
                                                             IN in_schema_name varchar(100),
                                                             IN in_driver_class_name varchar(50),
                                                             IN in_user_name varchar(50), IN in_password varchar(50),
                                                             IN in_initial_size int, IN in_max_active int,
                                                             IN in_max_idle int, IN in_validation_query varchar(500),
                                                             IN in_status int)
BEGIN
    UPDATE school_db_setting 
    SET school_id = in_school_id,
        url = in_url,
        schema_name = in_schema_name,
        driver_class_name = in_driver_class_name, 
        user_name = in_user_name, 
        password = in_password,
        initial_size = in_initial_size,
        max_active = in_max_active,
        max_idle = in_max_idle,
        validation_query = in_validation_query,
        status = in_status
    WHERE id = in_id;
END;

