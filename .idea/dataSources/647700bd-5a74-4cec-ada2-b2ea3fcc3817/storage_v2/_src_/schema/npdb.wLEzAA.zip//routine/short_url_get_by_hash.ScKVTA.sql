create
    definer = devuser@`%` procedure short_url_get_by_hash(IN in_hash varchar(20))
BEGIN

	SELECT * from short_url WHERE `hash` = in_hash;
	
END;

