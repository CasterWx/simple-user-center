create
    definer = devuser@`%` procedure search_query_param_get_all()
BEGIN
	SELECT * FROM search_query_param;
END;

