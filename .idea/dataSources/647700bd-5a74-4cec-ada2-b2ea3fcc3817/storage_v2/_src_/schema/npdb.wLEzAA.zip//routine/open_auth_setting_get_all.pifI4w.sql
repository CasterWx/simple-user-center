create
    definer = devuser@`%` procedure open_auth_setting_get_all()
BEGIN
	SELECT * FROM open_auth_setting;
END;

