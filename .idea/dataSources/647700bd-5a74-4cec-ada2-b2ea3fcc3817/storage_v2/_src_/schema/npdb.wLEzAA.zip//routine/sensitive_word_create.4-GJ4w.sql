create
    definer = devuser@`%` procedure sensitive_word_create(IN in_word varchar(255), IN in_type varchar(255))
BEGIN
    INSERT INTO sensitive_word (word, `type`) VALUES (in_word, in_type);
END;

