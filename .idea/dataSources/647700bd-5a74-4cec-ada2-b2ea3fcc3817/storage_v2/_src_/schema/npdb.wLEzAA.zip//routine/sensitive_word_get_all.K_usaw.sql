create
    definer = devuser@`%` procedure sensitive_word_get_all()
BEGIN

    SELECT * FROM sensitive_word;

END;

