create
    definer = devuser@`%` procedure bpartner_setting_get_all()
BEGIN

    SELECT * FROM bpartner_setting;

END;

