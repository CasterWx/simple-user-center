create
    definer = devuser@`%` procedure global_user_search(IN in_school_id int, IN in_id_list mediumtext,
                                                       IN in_display_name varchar(64), IN in_gender varchar(20),
                                                       IN in_identity_card varchar(50), IN in_phone_num varchar(20),
                                                       IN in_role_id_list varchar(64), IN in_offset int,
                                                       IN in_count int, OUT out_total_count int)
BEGIN

    DECLARE user_id_token INT(11);
	IF in_id_list IS NULL THEN 
		SELECT SQL_CALC_FOUND_ROWS DISTINCT gu.*, gi.url AS photo_image_url
        FROM global_user AS gu 
        INNER JOIN user_school AS us ON gu.id = us.user_id
		LEFT JOIN global_image gi ON gu.photo_image_id = gi.id
		WHERE (in_school_id IS NULL OR us.school_id =in_school_id)
		AND (in_display_name IS NULL OR gu.display_name LIKE CONCAT('%',in_display_name,'%'))
        AND (IF(in_gender = '0',gu.gender IS NULL OR gu.gender = '' ,in_gender IS NULL OR gu.gender = in_gender))
		AND (in_identity_card IS NULL OR gu.identity_card LIKE CONCAT('%',in_identity_card,'%'))
		AND (in_phone_num IS NULL OR gu.phone_num LIKE CONCAT('%',in_phone_num,'%'))    
		AND (in_role_id_list IS NULL OR FIND_IN_SET(us.user_role, in_role_id_list))
		LIMIT in_offset, in_count;
	ELSE 
		DROP TEMPORARY TABLE IF EXISTS `gloabl_user_id_temporary`;
        CREATE TEMPORARY TABLE `gloabl_user_id_temporary`( 
			user_id INT(11) 
        );

        WHILE LENGTH(in_id_list) > 0 DO
			SET user_id_token = SUBSTRING_INDEX(in_id_list, '|', 1);
			SET in_id_list = SUBSTRING(in_id_list, LENGTH(user_id_token) + 2);
			INSERT INTO `gloabl_user_id_temporary` (user_id) VALUES (user_id_token); 
		END WHILE;
        
        SELECT SQL_CALC_FOUND_ROWS DISTINCT gu.*, gi.url AS photo_image_url
        FROM global_user AS gu 
        INNER JOIN user_school AS us ON gu.id = us.user_id 
        INNER JOIN gloabl_user_id_temporary t ON gu.id = t.user_id
        LEFT JOIN global_image gi ON gu.photo_image_id = gi.id
		WHERE (in_school_id IS NULL OR us.school_id = in_school_id)
		AND (in_display_name IS NULL OR gu.display_name LIKE CONCAT('%', in_display_name, '%'))
        AND (IF(in_gender = '0', gu.gender IS NULL OR gu.gender = '' , in_gender IS NULL OR gu.gender = in_gender))
		AND (in_identity_card IS NULL OR gu.identity_card LIKE CONCAT('%', in_identity_card, '%'))
		AND (in_phone_num IS NULL OR gu.phone_num LIKE CONCAT('%', in_phone_num, '%'))    
		AND (in_role_id_list IS NULL OR FIND_IN_SET(us.user_role, in_role_id_list))
		LIMIT in_offset, in_count;
		
		DROP TEMPORARY TABLE IF EXISTS `gloabl_user_id_temporary`;
        
    END IF;
		
    SET out_total_count = FOUND_ROWS();

END;

