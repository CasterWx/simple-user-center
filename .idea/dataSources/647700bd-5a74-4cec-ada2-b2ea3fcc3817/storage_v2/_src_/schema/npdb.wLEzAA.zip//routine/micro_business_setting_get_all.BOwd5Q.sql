create
    definer = devuser@`%` procedure micro_business_setting_get_all()
BEGIN

    SELECT * FROM micro_business_setting;

END;

