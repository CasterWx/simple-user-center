create
    definer = devuser@`%` procedure short_url_delete_by_target_url(IN in_target_url varchar(300), OUT out_hash varchar(20))
BEGIN
	SET sql_safe_updates = 0;
	SELECT `hash` INTO out_hash FROM `short_url` WHERE `target_url` LIKE CONCAT(in_target_url,'%');
	DELETE FROM `short_url` WHERE `target_url` LIKE CONCAT(in_target_url,'%');
	
END;

