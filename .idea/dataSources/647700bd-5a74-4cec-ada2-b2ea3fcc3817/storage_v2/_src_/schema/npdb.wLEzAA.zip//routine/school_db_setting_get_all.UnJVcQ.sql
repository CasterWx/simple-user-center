create
    definer = devuser@`%` procedure school_db_setting_get_all()
BEGIN
    SELECT * FROM school_db_setting;
END;

