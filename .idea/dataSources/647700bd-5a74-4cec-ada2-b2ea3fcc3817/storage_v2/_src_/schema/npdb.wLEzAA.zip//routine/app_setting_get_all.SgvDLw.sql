create
    definer = devuser@`%` procedure app_setting_get_all()
BEGIN
    SELECT * FROM app_setting;
END;

