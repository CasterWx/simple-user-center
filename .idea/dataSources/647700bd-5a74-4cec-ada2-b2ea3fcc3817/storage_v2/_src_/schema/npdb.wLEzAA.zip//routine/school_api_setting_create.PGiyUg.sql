create
    definer = devuser@`%` procedure school_api_setting_create(IN in_school_id int, IN in_rsa_private_key varchar(1024),
                                                              IN in_rsa_public_key varchar(1024), OUT out_id int)
BEGIN

	INSERT INTO school_api_setting(school_id, rsa_private_key, rsa_public_key)
    VALUES(in_school_id, in_rsa_private_key, in_rsa_public_key);
    
    SET out_id = LAST_INSERT_ID();
END;

