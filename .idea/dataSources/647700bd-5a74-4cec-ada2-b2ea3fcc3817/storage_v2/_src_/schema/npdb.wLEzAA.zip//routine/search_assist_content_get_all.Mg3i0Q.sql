create
    definer = devuser@`%` procedure search_assist_content_get_all()
BEGIN
	SELECT * 
  FROM search_assist_content;
END;

