create
    definer = devuser@`%` procedure school_db_setting_create(IN in_school_id int, IN in_url varchar(500),
                                                             IN in_schema_name varchar(100),
                                                             IN in_driver_class_name varchar(50),
                                                             IN in_user_name varchar(50), IN in_password varchar(50),
                                                             IN in_initial_size int, IN in_max_active int,
                                                             IN in_max_idle int, IN in_validation_query varchar(500),
                                                             OUT out_id int)
BEGIN
    INSERT INTO school_db_setting (school_id, url, schema_name, driver_class_name, user_name, password, initial_size, max_active, max_idle, validation_query)
    VALUES (in_school_id, in_url, in_schema_name, in_driver_class_name, in_user_name, in_password, in_initial_size, in_max_active, in_max_idle, in_validation_query);

    SET out_id = LAST_INSERT_ID();
END;

