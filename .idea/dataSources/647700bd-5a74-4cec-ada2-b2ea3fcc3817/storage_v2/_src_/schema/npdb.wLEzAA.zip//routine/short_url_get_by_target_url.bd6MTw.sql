create
    definer = devuser@`%` procedure short_url_get_by_target_url(IN in_target_url varchar(300))
BEGIN

	SELECT * from short_url WHERE `target_url` = in_target_url;
	
END;

