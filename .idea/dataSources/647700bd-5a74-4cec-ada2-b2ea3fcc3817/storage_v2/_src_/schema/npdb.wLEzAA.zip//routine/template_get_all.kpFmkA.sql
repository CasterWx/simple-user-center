create
    definer = devuser@`%` procedure template_get_all()
BEGIN
	SELECT *
  FROM template;
END;

