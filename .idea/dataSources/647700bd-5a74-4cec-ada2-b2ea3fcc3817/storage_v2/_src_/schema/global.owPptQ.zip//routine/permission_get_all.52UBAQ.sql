create
    definer = devuser@`%` procedure permission_get_all()
BEGIN
	SELECT * FROM permission p;
END;

