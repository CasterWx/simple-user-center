create
    definer = devuser@`%` procedure global_image_tag_get_all()
BEGIN

	SELECT * FROM global_image_tag;
END;

