create
    definer = devuser@`%` procedure user_author_update(IN in_id int, IN in_user_id int, IN in_utype int,
                                                       IN in_uid varchar(45), IN in_uname varchar(45),
                                                       IN in_udisplay_name varchar(45),
                                                       IN in_uphoto_image_url varchar(500))
BEGIN

    UPDATE user_author 
    SET
        uid = in_uid,
        uname = in_uname,
        user_id = in_user_id,
        utype = in_utype,
        udisplay_name = in_udisplay_name,
        uphoto_image_url = in_uphoto_image_url
    WHERE id = in_id;

END;

