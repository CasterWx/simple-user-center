create
    definer = devuser@`%` procedure async_task_get_not_handled_tasks(IN in_user_id int)
BEGIN
	SELECT * from async_task where user_id=in_user_id and `status` in (0,1);

END;

