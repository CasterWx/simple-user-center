create
    definer = devuser@`%` procedure sync_qingshu_course_res_task_search(IN in_school_id int, IN in_status_list text,
                                                                        IN in_school_course_ids text)
BEGIN

	SELECT * FROM sync_qingshu_course_res_task 
    WHERE (in_school_id IS NULL OR school_id = in_school_id)
    AND (in_status_list IS NULL OR FIND_IN_SET(`status`, in_status_list))
    AND (in_school_course_ids IS NULL OR FIND_IN_SET(school_course_id, in_school_course_ids));

END;

