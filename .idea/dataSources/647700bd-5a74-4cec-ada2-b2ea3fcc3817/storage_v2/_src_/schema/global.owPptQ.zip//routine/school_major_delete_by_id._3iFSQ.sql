create
    definer = devuser@`%` procedure school_major_delete_by_id(IN in_id int)
BEGIN

    DELETE FROM  school_major WHERE id = in_id;

END;

