create
    definer = devuser@`%` procedure global_user_get_by_ids(IN ids text)
BEGIN
	SELECT * FROM global_user WHERE id IN (ids);
END;

