create
    definer = devuser@`%` procedure school_search(IN in_status int, IN in_type int, IN in_keyword varchar(500),
                                                  IN in_offset int, IN in_count int, OUT out_total_count int)
BEGIN
	SELECT
		s.*, sc.type as schoolCategoryType 
	FROM
		school s INNER JOIN school_category sc ON sc.id = s.category_id
	WHERE
		(
			in_status IS NULL
			OR s.`status` = in_status
		)
	AND (
		in_type IS NULL
		OR s.category_id IN (
			SELECT
				id
			FROM
				school_category a
			WHERE
				type = in_type
		)
	)
	AND (
		in_keyword IS NULL
		OR s.`name` LIKE CONCAT('%', in_keyword, '%')
	)
 LIMIT in_offset, in_count;
 SET out_total_count = FOUND_ROWS();
END;

