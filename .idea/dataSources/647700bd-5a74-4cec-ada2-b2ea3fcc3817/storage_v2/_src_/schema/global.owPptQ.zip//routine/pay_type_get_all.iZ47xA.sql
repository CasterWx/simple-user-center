create
    definer = devuser@`%` procedure pay_type_get_all()
BEGIN
	SELECT * FROM pay_type;
END;

