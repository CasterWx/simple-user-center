create
    definer = devuser@`%` procedure batch_update_student_operate_item_info(IN in_operate_group_id int, IN in_column int,
                                                                           IN in_content varchar(255),
                                                                           IN in_item_ids mediumtext)
BEGIN
	
    DECLARE id_token VARCHAR(10);
    
	DROP TEMPORARY TABLE IF EXISTS `item_ids`;
    CREATE TEMPORARY TABLE `item_ids`(
		id INT(11) PRIMARY KEY
    );
	
	WHILE LENGTH(in_item_ids) >0 DO
        SET id_token = SUBSTRING_INDEX(in_item_ids, '|', 1);
        SET in_item_ids = SUBSTRING(in_item_ids,LENGTH(id_token) +2);
        INSERT item_ids(id) VALUES (CAST(id_token AS SIGNED));

    END WHILE;
    
    
	SET SQL_SAFE_UPDATES = 0;

	CASE
    
     WHEN in_column = 16 THEN
		UPDATE operate_item SET c16 = in_content WHERE group_id = in_operate_group_id AND id in (select id from item_ids);
	WHEN in_column = 19 THEN
		UPDATE operate_item SET c19 = in_content WHERE group_id = in_operate_group_id AND id in (select id from item_ids);
	WHEN in_column = 5 THEN
		UPDATE operate_item SET c5 = in_content WHERE group_id = in_operate_group_id AND id in (select id from item_ids);
	WHEN in_column = 13 THEN
		UPDATE operate_item SET c13 = in_content WHERE group_id = in_operate_group_id AND id in (select id from item_ids);
	WHEN in_column = 20 THEN
		UPDATE operate_item SET c20 = in_content WHERE group_id = in_operate_group_id AND id in (select id from item_ids);
    
    END CASE;
    
    DROP TEMPORARY TABLE IF EXISTS `item_ids`;
END;

