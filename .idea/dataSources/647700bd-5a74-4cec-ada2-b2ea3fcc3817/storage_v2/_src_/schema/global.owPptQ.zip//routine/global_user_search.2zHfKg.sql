create
    definer = devuser@`%` procedure global_user_search(IN in_id_list mediumtext, IN in_school_ids mediumtext,
                                                       IN in_role_id_list mediumtext, IN in_user_name_list mediumtext,
                                                       IN in_user_name varchar(60), IN in_display_name varchar(64),
                                                       IN in_gender varchar(20), IN in_identity_card varchar(50),
                                                       IN in_phone_num varchar(20), IN in_email varchar(64),
                                                       IN in_fuzzy bit, IN in_offset int, IN in_count int,
                                                       OUT out_total_count int)
BEGIN

	DECLARE common_sql_str TEXT;
	DECLARE count_sql_str TEXT;
	DECLARE search_sql_str TEXT;
	
	SET common_sql_str = " FROM global_user AS gu ";

	IF in_school_ids IS NOT NULL OR in_role_id_list IS NOT NULL
		THEN SET common_sql_str = CONCAT(common_sql_str," INNER JOIN user_school AS us ON gu.id = us.user_id ");
	END IF;
    
	SET common_sql_str = CONCAT(common_sql_str," WHERE 1=1 ");

	IF in_id_list IS NOT NULL 
		THEN SET common_sql_str = CONCAT(common_sql_str," AND gu.id in ( ",in_id_list," ) ");
	END IF;

	IF in_school_ids IS NOT NULL 
		THEN SET common_sql_str = CONCAT(common_sql_str," AND us.school_id in ( ",in_school_ids," ) ");
	END IF;

	IF in_role_id_list IS NOT NULL 
		THEN SET common_sql_str = CONCAT(common_sql_str," AND us.user_role in ( ",in_role_id_list," ) ");
	END IF;
	
	IF in_user_name_list IS NOT NULL 
		THEN SET common_sql_str = CONCAT(common_sql_str," AND gu.user_name in (",in_user_name_list,") ");
	END IF;

	IF in_fuzzy = 0 THEN
		SET @comp1 = " = ? ";
	ELSE
		SET @comp1 = " LIKE ? ";
	END IF;
    
	SET common_sql_str = CONCAT(common_sql_str," AND ( ? IS NULL OR gu.user_name ", @comp1 ," ) ");
    SET common_sql_str = CONCAT(common_sql_str," AND ( ? IS NULL OR gu.display_name ", @comp1 ," ) ");
    SET common_sql_str = CONCAT(common_sql_str," AND ( ? IS NULL OR gu.identity_card ", @comp1 ," ) ");
	SET common_sql_str = CONCAT(common_sql_str," AND ( ? IS NULL OR gu.phone_num ", @comp1 ," ) ");
	SET common_sql_str = CONCAT(common_sql_str," AND ( ? IS NULL OR gu.email ", @comp1 ," ) ");
    SET common_sql_str = CONCAT(common_sql_str," AND ( ? IS NULL OR gu.gender ", @comp1 ," ) ");
    
    SET @user_name = in_user_name;
    SET @user_name_like = CONCAT("%",in_user_name,"%");
	SET @display_name = in_display_name;
    SET @display_name_like = CONCAT("%",in_display_name,"%");
    SET @identity_card = in_identity_card;
    SET @identity_card_like = CONCAT("%",in_identity_card,"%");
    SET @phone_num = in_phone_num;
    SET @phone_num_like = CONCAT("%",in_phone_num,"%");
    SET @email = in_email;
    SET @email_like = CONCAT("%",in_email,"%");
    SET @gender = in_gender;
    SET @gender_like = CONCAT("%",in_gender,"%");
    
    IF in_fuzzy = 0 THEN
		SET @user_name_like = in_user_name;
        SET @display_name_like = in_display_name;
        SET @identity_card_like = in_identity_card;
        SET @phone_num_like = in_phone_num;
        SET @email_like = in_email;
        SET @gender_like = in_gender;
	END IF;   
    	
	SET count_sql_str = CONCAT("SELECT count(*) INTO @count ", common_sql_str, ";");
	SET @sql_count = count_sql_str;
	
	PREPARE s1 FROM @sql_count;
	EXECUTE s1 USING @user_name, @user_name_like, @display_name, @display_name_like, @identity_card, @identity_card_like, @phone_num, @phone_num_like, @email, @email_like, @gender, @gender_like;
	DEALLOCATE PREPARE s1;
	SET out_total_count = @count;

	SET search_sql_str = ' SELECT gu.* ';
	SET search_sql_str = CONCAT(search_sql_str, common_sql_str);
	SET search_sql_str = CONCAT(search_sql_str, " GROUP BY gu.id LIMIT ",in_offset," , ", in_count);

	SET @sql_search = search_sql_str;
	PREPARE s2 FROM @sql_search;
	EXECUTE s2 USING @user_name, @user_name_like, @display_name, @display_name_like, @identity_card, @identity_card_like, @phone_num, @phone_num_like, @email, @email_like, @gender, @gender_like;
	DEALLOCATE PREPARE s2;

END;

