create
    definer = devuser@`%` procedure current_course_student_count_get_by_id(IN in_teachingplan_course_id int, OUT out_count int)
BEGIN 
    SELECT count(*) INTO out_count FROM student_course
    WHERE teachingplan_course_id = in_teachingplan_course_id and flag=2;
    
END;

