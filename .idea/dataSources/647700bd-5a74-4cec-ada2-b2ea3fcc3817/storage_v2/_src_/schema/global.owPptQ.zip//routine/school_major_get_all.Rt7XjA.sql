create
    definer = devuser@`%` procedure school_major_get_all()
BEGIN
    SELECT * FROM school_major;
END;

