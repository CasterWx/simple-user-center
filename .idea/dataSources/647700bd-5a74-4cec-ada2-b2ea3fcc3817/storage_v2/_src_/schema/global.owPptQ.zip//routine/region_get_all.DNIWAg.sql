create
    definer = devuser@`%` procedure region_get_all()
BEGIN

	SELECT * FROM region WHERE level <3;
END;

