create
    definer = devuser@`%` procedure support_kf5_user_search(IN in_type int, IN in_email_id int)
BEGIN
	SELECT * FROM `support_kf5_user`
	WHERE (in_type IS NULL OR `type` = in_type)
	AND (in_email_id IS NULL OR `email_id` = in_email_id);
END;

