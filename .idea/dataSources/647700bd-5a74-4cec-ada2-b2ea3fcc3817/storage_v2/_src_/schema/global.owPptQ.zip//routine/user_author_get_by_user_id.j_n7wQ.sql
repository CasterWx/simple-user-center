create
    definer = devuser@`%` procedure user_author_get_by_user_id(IN in_user_id int)
BEGIN
	select * from user_author
		where user_id = in_user_id;
END;

