create
    definer = devuser@`%` procedure notification_target_search(IN in_semester_ids varchar(2000),
                                                               IN in_major_ids varchar(2000),
                                                               IN in_center_ids varchar(2000))
BEGIN
    DECLARE semester_id_token VARCHAR(10);
    DECLARE major_id_token VARCHAR(10);
    DECLARE center_id_token VARCHAR(10);
    
    DROP TEMPORARY TABLE IF EXISTS semester_id_tbl;
    DROP TEMPORARY TABLE IF EXISTS major_id_tbl;
    DROP TEMPORARY TABLE IF EXISTS center_id_tbl;

    CREATE TEMPORARY TABLE semester_id_tbl(
        semester_id INT(11)
    );
    CREATE TEMPORARY TABLE major_id_tbl(
        major_id INT(11)
    );
    CREATE TEMPORARY TABLE center_id_tbl(
        center_id INT(11)
    );


    WHILE LENGTH(in_semester_ids) >0 DO
        SET semester_id_token = SUBSTRING_INDEX(in_semester_ids, '|', 1);
        SET in_semester_ids = SUBSTRING(in_semester_ids,LENGTH(semester_id_token) +2);
        INSERT semester_id_tbl (semester_id) VALUES ( CAST(semester_id_token AS SIGNED) );
    END WHILE;
    
    WHILE LENGTH(in_major_ids) >0 DO
        SET major_id_token = SUBSTRING_INDEX(in_major_ids, '|', 1);
        SET in_major_ids = SUBSTRING(in_major_ids,LENGTH(major_id_token) +2);
        INSERT major_id_tbl (major_id) VALUES ( CAST(major_id_token AS SIGNED) );
    END WHILE;
    
    WHILE LENGTH(in_center_ids) >0 DO
        SET center_id_token = SUBSTRING_INDEX(in_center_ids, '|', 1);
        SET in_center_ids = SUBSTRING(in_center_ids,LENGTH(center_id_token) +2);
        INSERT center_id_tbl (center_id) VALUES ( CAST(center_id_token AS SIGNED) );
    END WHILE;
    
    SELECT * FROM student
    WHERE (in_semester_ids IS NULL OR (semester_id IN (SELECT semester_id FROM semester_id_tbl)))
    AND (in_major_ids IS NULL OR (major_id IN (SELECT major_id FROM major_id_tbl)))
    AND (in_center_ids IS NULL OR (center_id IN (SELECT center_id FROM center_id_tbl)));
    
END;

