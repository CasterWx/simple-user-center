create
    definer = devuser@`%` procedure school_major_create(IN in_school_id int, IN in_major_id int, OUT out_id int)
BEGIN
    INSERT INTO `global`.`school_major`
    (`school_id`,
    `major_id`)
    VALUES
    (in_school_id,
    in_major_id
    );
    
    SET out_id = LAST_INSERT_ID();

END;

