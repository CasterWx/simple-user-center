create
    definer = devuser@`%` procedure async_task_update(IN in_id int, IN in_status int, IN in_params mediumtext,
                                                      IN in_url mediumtext)
BEGIN
	UPDATE async_task SET status = in_status, 
		params = in_params,
		url = in_url
	WHERE id = in_id;
END;

