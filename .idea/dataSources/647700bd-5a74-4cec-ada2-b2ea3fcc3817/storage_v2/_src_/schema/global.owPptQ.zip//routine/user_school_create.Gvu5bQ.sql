create
    definer = devuser@`%` procedure user_school_create(IN in_user_id int, IN in_school_id int, IN in_user_role int,
                                                       OUT out_id int)
BEGIN

insert into user_school(user_id,school_id, user_role) 
values (in_user_id, in_school_id, in_user_role);

set out_id = LAST_INSERT_ID();

END;

