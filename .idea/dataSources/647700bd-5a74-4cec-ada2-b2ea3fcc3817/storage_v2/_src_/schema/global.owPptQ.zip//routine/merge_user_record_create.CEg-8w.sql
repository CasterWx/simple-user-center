create
    definer = devuser@`%` procedure merge_user_record_create(IN in_user_id int, IN in_school_id varchar(64),
                                                             IN in_merge_user_id int, IN in_merge_school_id varchar(64),
                                                             OUT out_id int)
BEGIN

	INSERT INTO merge_user_record(user_id, school_id, merge_user_id, merge_school_id)

	VALUES(in_user_id, in_school_id, in_merge_user_id, in_merge_school_id);

	SET out_id = LAST_INSERT_ID();

END;

