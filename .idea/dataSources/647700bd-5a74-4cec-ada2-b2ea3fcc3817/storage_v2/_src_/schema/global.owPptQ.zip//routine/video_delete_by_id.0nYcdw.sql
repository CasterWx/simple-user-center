create
    definer = devuser@`%` procedure video_delete_by_id(IN in_id int)
BEGIN

	DELETE FROM `video` WHERE id = in_id;

END;

