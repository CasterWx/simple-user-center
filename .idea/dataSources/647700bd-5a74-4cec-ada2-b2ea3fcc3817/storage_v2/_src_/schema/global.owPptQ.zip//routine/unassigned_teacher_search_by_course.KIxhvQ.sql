create
    definer = devuser@`%` procedure unassigned_teacher_search_by_course(IN in_course_id int, IN in_offset int,
                                                                        IN in_count int, OUT out_total_records int)
BEGIN
	
    SELECT sql_calc_found_rows * FROM teacher t 
    WHERE NOT EXISTS (SELECT 1 FROM teacher_course tc WHERE tc.teacher_id = t.id and tc.course_id = in_course_id)
    LIMIT in_offset, in_count;

	SET out_total_records = found_rows();  

END;

