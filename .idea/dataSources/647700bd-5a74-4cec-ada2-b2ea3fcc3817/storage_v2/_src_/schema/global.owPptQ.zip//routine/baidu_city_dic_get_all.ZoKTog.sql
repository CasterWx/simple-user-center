create
    definer = devuser@`%` procedure baidu_city_dic_get_all()
BEGIN

	SELECT * FROM baidu_city_dic;

END;

