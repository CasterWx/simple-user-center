create
    definer = devuser@`%` procedure user_token_history_get_by_ids(IN in_user_ids text)
BEGIN
	IF in_user_ids IS NOT NULL THEN
		set @sql = CONCAT("SELECT * FROM user_token_history WHERE user_id IN ( ", in_user_ids," ) ORDER BY id DESC ");
	    PREPARE stmt FROM @sql;
	    EXECUTE stmt;
	    DEALLOCATE PREPARE stmt;
    END IF;
END;

