create
    definer = devuser@`%` procedure major_search(IN in_keyword varchar(200))
BEGIN
	SELECT * FROM major WHERE name LIKE CONCAT('%', in_keyword, '%');
END;

