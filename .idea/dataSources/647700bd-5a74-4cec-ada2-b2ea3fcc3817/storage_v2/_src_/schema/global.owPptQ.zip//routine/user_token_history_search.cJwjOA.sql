create
    definer = devuser@`%` procedure user_token_history_search(IN in_user_id int, IN in_type int)
BEGIN
	SELECT * FROM user_token_history WHERE user_id = in_user_id AND type = in_type ORDER BY id desc;
END;

