create
    definer = devuser@`%` procedure user_school_search(IN in_user_id_list mediumtext, IN in_school_id int,
                                                       IN in_user_roles mediumtext)
BEGIN
	SET @sql = "SELECT * FROM user_school WHERE 1=1 ";

	IF in_user_id_list IS NOT NULL
		THEN SET @sql = CONCAT(@sql," AND user_id in (",in_user_id_list,") ");
	END IF;

	IF in_school_id IS NOT NULL
		THEN SET @sql = CONCAT(@sql," AND school_id = ",in_school_id," ");
	END IF;

	IF in_user_roles IS NOT NULL
		THEN SET @sql = CONCAT(@sql," AND user_role in (",in_user_roles,") ");
	END IF;

	SET @sql = CONCAT(@sql," ORDER BY id ASC ");

	PREPARE stmt FROM @sql;
    EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

END;

