create
    definer = devuser@`%` procedure user_resource_update(IN in_id int, IN in_name varchar(255), IN in_user_id int,
                                                         IN in_resource_id int, IN in_status int(2),
                                                         IN in_parent_id int)
BEGIN

	UPDATE user_resource SET 
		name = in_name,
		user_id = in_user_id,
		resource_id = in_resource_id,
		status = in_status,
		parent_id = in_parent_id
	WHERE id = in_id;

END;

