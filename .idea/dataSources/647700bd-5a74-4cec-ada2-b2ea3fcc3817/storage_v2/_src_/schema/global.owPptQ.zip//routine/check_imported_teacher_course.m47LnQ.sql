create
    definer = devuser@`%` procedure check_imported_teacher_course(IN in_group_id int)
BEGIN
	-- status
	DECLARE local_waiting INT DEFAULT 1;
    DECLARE local_valid INT DEFAULT 2;
    DECLARE local_invalid INT DEFAULT 3;
    DECLARE local_complete INT DEFAULT 4;
    DECLARE local_cancel INT DEFAULT 5;
    DECLARE local_checking INT DEFAULT 6;
    
    -- 0 设置进入校验状态
    UPDATE operate_group SET status=local_checking WHERE id = in_group_id;
    
    -- 1 检查课程名是否为空
    UPDATE  operate_item SET status=local_invalid,comment= '课程名不能为空' WHERE status=local_waiting AND group_id = in_group_id AND (c2 is null or c2 ="");
	
    -- 2 检查数据是否重复
    UPDATE  operate_item oi1 , operate_item oi2 SET oi1.status=3,oi1.comment='该行数据在前面的行中已出现'
    WHERE oi1.id>oi2.id AND oi1.group_id=in_group_id AND oi2.group_id=in_group_id AND oi1.status=local_waiting AND oi2.status=local_waiting
    AND oi1.c1=oi2.c1 AND oi1.c2=oi2.c2;
    
    -- 3 检查课程是否存在 c4 存course_id
    UPDATE operate_item oi INNER JOIN course c ON oi.group_id=in_group_id AND oi.status=local_waiting
    AND oi.c2 = c.name
    SET oi.c4 = c.id;
    
    UPDATE operate_item oi SET status=local_invalid,comment= '课程不存在'
    WHERE  oi.group_id=in_group_id AND oi.status=local_waiting AND (oi.c4 = ''  OR oi.c4 IS NULL);
    
    -- 4 检查教师课程关系是否已存在
    UPDATE operate_item oi INNER JOIN teacher t on oi.group_id = in_group_id AND oi.status = local_waiting
    AND oi.c3 = t.global_user_id
    SET oi.c5 = t.id;
    
    UPDATE operate_item oi INNER JOIN teacher_course tc on oi.group_id = in_group_id AND oi.status = local_waiting
    AND oi.c5 = tc.teacher_id AND oi.c4 = tc.course_id
    SET oi.status=local_invalid,oi.comment = '该条教师课程关系已存在';
    
    -- 4 剩余的数据有效
    UPDATE operate_item oi SET status=local_valid,comment= '有效数据'
    WHERE  oi.group_id=in_group_id AND oi.status=local_waiting;
    
    -- 无其他检查项 item的状态更新global
  	UPDATE operate_group SET status=
 	CASE WHEN EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=local_valid)
	 THEN local_valid else local_invalid END
 	WHERE id=in_group_id;

END;

