create
    definer = devuser@`%` procedure school_register_get_by_phone(IN in_phone varchar(45))
BEGIN
    SELECT sr.*
    FROM school_register sr
    WHERE sr.phone = in_phone;
END;

