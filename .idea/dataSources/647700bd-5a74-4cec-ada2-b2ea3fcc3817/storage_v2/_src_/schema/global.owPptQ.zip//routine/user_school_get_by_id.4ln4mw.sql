create
    definer = devuser@`%` procedure user_school_get_by_id(IN in_id int)
BEGIN
	select * FROM user_school
	where id=in_id;
END;

