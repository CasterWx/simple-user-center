create
    definer = devuser@`%` procedure user_author_create(IN in_user_id int, IN in_utype int, IN in_uid varchar(45),
                                                       IN in_uname varchar(45), IN in_udisplay_name varchar(45),
                                                       IN in_uphoto_image_url varchar(500), OUT out_id int)
BEGIN

	INSERT into user_author(user_id,utype,uid,uname,udisplay_name,uphoto_image_url)
	VALUES (in_user_id,in_utype,in_uid,in_uname,in_udisplay_name,in_uphoto_image_url);
	
	SET out_id = LAST_INSERT_ID();

END;

