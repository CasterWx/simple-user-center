create
    definer = devuser@`%` procedure notification_update(IN in_id int, IN in_target varchar(500),
                                                        IN in_content varchar(500), IN in_custom_type int,
                                                        IN in_custom_data varchar(200), IN in_published bit,
                                                        IN in_publisher_id int)
BEGIN

    UPDATE notification 
    SET target = in_target,
    content = in_content,
    custom_type = in_custom_type,
    custom_data = in_custom_data,
    published = in_published,
    publisher_id = in_publisher_id,
    published_time = CASE in_published WHEN 1 THEN NOW() ELSE NULL END
    WHERE id = in_id;

END;

