create
    definer = devuser@`%` procedure batch_delete_student_global_info(IN in_group_id int, IN in_school_id int)
BEGIN
	SET SQL_SAFE_UPDATES = 0;
	
    delete global_user 
    from global_user, 
    (select * from global_user as gu right join (select c18 from `operate_item` as oi where oi.group_id=in_group_id) as oitem on gu.id=oitem.c18) g2
    where global_user.id = g2.id;
	
    delete user_school
    from user_school,
    (select * from user_school as us right join (select c18 from `operate_item` as oi where oi.group_id=in_group_id) as oitem on us.user_id=oitem.c18) u2
    where user_school.id = u2.id and user_school.school_id=in_school_id;
    
    SET SQL_SAFE_UPDATES = 1;
END;

