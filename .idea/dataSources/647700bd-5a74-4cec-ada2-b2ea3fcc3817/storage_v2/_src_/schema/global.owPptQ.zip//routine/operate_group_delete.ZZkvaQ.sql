create
    definer = devuser@`%` procedure operate_group_delete(IN in_id int)
BEGIN
    
	SET SQL_SAFE_UPDATES=0;
    
    DELETE FROM operate_item WHERE group_id = in_id;
    
    DELETE FROM operate_group WHERE id = in_id;
    
END;

