create
    definer = devuser@`%` procedure async_task_create(IN in_name varchar(255), IN in_type int, IN in_status int,
                                                      IN in_priority int, IN in_user_id int, IN in_school_id int,
                                                      IN in_message varchar(255), IN in_params mediumtext,
                                                      IN in_url varchar(255), OUT out_id int)
BEGIN
	 INSERT INTO async_task (`name`, type, 
      `status`, priority, user_id, 
      school_id, message, params, 
      url, created_time, updated_time
      )
   values (in_name,in_type,in_status, in_priority, in_user_id, 
      in_school_id, in_message, in_params, in_url, now(), now());
	SET out_id = last_insert_id();
END;

