create
    definer = devuser@`%` procedure major_free_video_get_all()
BEGIN
    SELECT * FROM major_free_video;
END;

