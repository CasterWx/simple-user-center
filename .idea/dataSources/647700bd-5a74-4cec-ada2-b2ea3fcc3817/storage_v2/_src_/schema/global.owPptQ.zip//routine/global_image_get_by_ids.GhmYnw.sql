create
    definer = devuser@`%` procedure global_image_get_by_ids(IN in_ids mediumtext)
BEGIN
	set @sql = concat("SELECT * FROM global_image WHERE id in (", in_ids,")");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
END;

