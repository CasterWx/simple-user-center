create
    definer = devuser@`%` procedure attribute_get_all()
BEGIN
    SELECT * FROM attribute;
END;

