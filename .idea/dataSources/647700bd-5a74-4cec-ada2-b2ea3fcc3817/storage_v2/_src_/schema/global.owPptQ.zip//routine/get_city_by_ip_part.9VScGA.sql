create
    definer = devuser@`%` procedure get_city_by_ip_part(IN in_part_a int, IN in_part_b int, IN in_part_c int)
BEGIN
	select city from ip_location where in_part_a = part_a and in_part_b = part_b and in_part_c = part_c limit 1;
END;

