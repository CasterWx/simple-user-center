create
    definer = devuser@`%` procedure batch_import_student_school_info(IN in_operate_group_id int, IN in_operator_id int)
BEGIN
	DECLARE VALID INT;
    DECLARE DONE INT;
    DECLARE GROUPTYPE INT;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
BEGIN
	ROLLBACK;
END;
	START TRANSACTION;
    SET VALID = 2;
    SET DONE = 4;
	SET SQL_SAFE_UPDATES = 0;
    
    SELECT `type` FROM operate_group WHERE id = in_operate_group_id INTO GROUPTYPE;
    
    IF GROUPTYPE = 201 THEN
		INSERT INTO student(global_user_id, major_id, center_id, student_number, semester_id, study_status_id, candidate_number, update_user_id)
		SELECT oi.c18, m.id, c.id, oi.c8, s.id, ss.id, oi.c9, in_operator_id  FROM operate_item oi 
		INNER JOIN major m ON oi.c1 = m.name AND oi.c2 = m.level
		INNER JOIN center c ON oi.c3 = c.name
		INNER JOIN semester s ON oi.c11 = s.year AND oi.c12 = s.term
		INNER JOIN study_status ss ON oi.c15 = ss.name
		WHERE oi.status = VALID AND oi.group_id = in_operate_group_id
		AND NOT EXISTS (SELECT * from student st where st.student_number=oi.c8 AND st.major_id=m.id AND center_id=c.id AND semester_id=s.id);
    
    ELSEIF GROUPTYPE = 203 THEN
		INSERT INTO student(global_user_id, major_id, center_id, semester_id, study_status_id, candidate_number, update_user_id)
		SELECT oi.c18, m.id, c.id, s.id, ss.id, oi.c9, in_operator_id  FROM operate_item oi 
		INNER JOIN major m ON oi.c1 = m.name AND oi.c2 = m.level
		INNER JOIN center c ON oi.c3 = c.name
		INNER JOIN semester s ON oi.c11 = s.year AND oi.c12 = s.term
		INNER JOIN study_status ss ON oi.c15 = ss.name
		WHERE oi.status = VALID AND oi.group_id = in_operate_group_id
		AND NOT EXISTS (SELECT * from student st where st.global_user_id=oi.c18 AND st.major_id=m.id AND center_id=c.id AND semester_id=s.id);

		INSERT INTO pre_student_teachingplan(pre_teachingplan_id, student_id)
        SELECT pt.id, s.id FROM operate_item oi
        INNER JOIN pre_teachingplan pt on oi.c8 = pt.name
        INNER JOIN major_level ml ON oi.c2 = ml.level_name AND pt.level_id = ml.id
        INNER JOIN student s ON oi.c18 = s.global_user_id
        WHERE oi.status = VALID AND oi.group_id = in_operate_group_id
        AND NOT EXISTS(SELECT * FROM pre_student_teachingplan pst WHERE pst.pre_teachingplan_id = pt.id AND student_id = s.id);
	END IF;
    
	UPDATE operate_item SET status = DONE WHERE status = VALID AND group_id = in_operate_group_id;
	UPDATE operate_group og SET og.status =
	CASE WHEN EXISTS (SELECT oi.id FROM operate_item oi WHERE oi.group_id = in_operate_group_id AND oi.status=VALID)
	THEN VALID ELSE DONE END 
	WHERE og.id=in_operate_group_id;
	COMMIT;
END;

