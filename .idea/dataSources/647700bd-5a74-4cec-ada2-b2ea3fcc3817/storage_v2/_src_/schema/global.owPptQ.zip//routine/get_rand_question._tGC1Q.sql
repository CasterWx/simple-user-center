create
    definer = devuser@`%` procedure get_rand_question(IN in_course_id int, IN in_question_type int, IN in_limit int)
BEGIN
	
	SELECT * FROM question 
	WHERE question_type = in_question_type AND (parent_id = 0 OR parent_id IS NULL) AND course_id = in_course_id
	ORDER BY RAND() limit in_limit ;
	
END;

