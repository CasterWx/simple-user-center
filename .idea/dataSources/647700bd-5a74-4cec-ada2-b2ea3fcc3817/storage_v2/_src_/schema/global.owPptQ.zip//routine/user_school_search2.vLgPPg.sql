create
    definer = devuser@`%` procedure user_school_search2(IN in_user_id_list mediumtext, IN in_school_id int, IN in_user_role int)
BEGIN

		SELECT * FROM user_school us
        WHERE (in_user_id_list IS NULL OR FIND_IN_SET(us.user_id, in_user_id_list))
			AND (in_user_role IS NULL OR us.user_role = in_user_role)
	        AND (in_school_id IS NULL OR us.school_id = in_school_id)
	        ORDER BY id ASC;  

END;

