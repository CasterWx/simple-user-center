create
    definer = devuser@`%` procedure default_share_img_get_all()
BEGIN
    SELECT * FROM default_share_img;
END;

