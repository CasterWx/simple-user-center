create
    definer = devuser@`%` procedure major_update(IN in_name varchar(64), IN in_level varchar(64),
                                                 IN in_level_sequence int, IN in_introduction mediumtext,
                                                 IN in_introduction_short varchar(500), IN in_cover_image_id int,
                                                 IN in_show_in_home_page bit, IN in_id int)
BEGIN


UPDATE major 

SET name = in_name,

    level = in_level,

    level_sequence = in_level_sequence,

    introduction = in_introduction,

    introduction_short = in_introduction_short,

    cover_image_id = in_cover_image_id,

    show_in_home_page = in_show_in_home_page

    WHERE id = in_id;

END;

