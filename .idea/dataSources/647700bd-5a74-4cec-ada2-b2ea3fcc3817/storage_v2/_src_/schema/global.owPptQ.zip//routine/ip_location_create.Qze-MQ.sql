create
    definer = devuser@`%` procedure ip_location_create(IN in_part_a int, IN in_part_b int, IN in_part_c int,
                                                       IN in_city varchar(255))
BEGIN

    INSERT INTO ip_location(part_a, part_b, part_c, city) VALUES (in_part_a, in_part_b, in_part_c, in_city) ON DUPLICATE KEY UPDATE city = in_city;

END;

