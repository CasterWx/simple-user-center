create
    definer = devuser@`%` procedure region_baidu_city_get_all()
BEGIN

	SELECT * FROM region_baidu_city;
END;

