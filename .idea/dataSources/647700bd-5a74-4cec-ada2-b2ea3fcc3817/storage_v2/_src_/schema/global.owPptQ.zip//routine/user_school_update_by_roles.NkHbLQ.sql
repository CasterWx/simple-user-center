create
    definer = devuser@`%` procedure user_school_update_by_roles(IN in_user_id int, IN in_user_roles varchar(100), IN in_school_id int)
BEGIN

	DECLARE role_id_token VARCHAR(10);
    DECLARE local_user_id INT(11);
    
    DROP TEMPORARY TABLE IF EXISTS role_temp_tbl;
    CREATE TEMPORARY TABLE role_temp_tbl(
        role_id INT(11)
    );

    WHILE LENGTH(in_user_roles) >0 DO
        SET role_id_token = SUBSTRING_INDEX(in_user_roles, '|', 1);
        SET in_user_roles = SUBSTRING(in_user_roles, LENGTH(role_id_token) +2);
        INSERT INTO role_temp_tbl (role_id) VALUES (CAST(role_id_token AS SIGNED));
    END WHILE;

    SET sql_safe_updates = 0;

    DELETE FROM user_school
    WHERE user_id = in_user_id AND school_id = in_school_id;

    INSERT INTO user_school (user_id, school_id, user_role) 
    SELECT in_user_id, in_school_id, stt.role_id FROM role_temp_tbl AS stt;
END;

