create
    definer = devuser@`%` procedure check_imported_student_username(IN in_group_id int)
BEGIN
	UPDATE operate_item oi1 , operate_item oi2 SET oi1.status = 3,oi1.result = '重复学生'
    WHERE oi1.id > oi2.id AND oi1.c2=oi2.c2 AND oi1.group_id=in_group_id AND oi2.group_id=in_group_id AND (oi1.status = 1 OR oi1.status = 2);
	
	UPDATE  operate_item oi INNER JOIN student s ON c2=s.global_user_id AND oi.group_id=in_group_id AND oi.status= 2 SET c1=s.id,c0=s.student_number;
  
  	UPDATE operate_item SET status=3,result = '学生不存在' WHERE group_id=in_group_id AND status= 2 AND c1 IS NULL;
  	
  	UPDATE operate_group SET status=
 	case when EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=2)
	 THEN 2 else 3 END
 	WHERE id=in_group_id;
   
END;

