create
    definer = devuser@`%` procedure major_get_all()
BEGIN
     SELECT * FROM major ORDER BY CONVERT(name USING gbk) COLLATE gbk_chinese_ci ASC;
END;

