create
    definer = devuser@`%` procedure active_student_batch(IN in_group_id int)
BEGIN

	
    
	SET SQL_SAFE_UPDATES = 0;
    
	
    IF NOT EXISTS (SELECT id FROM fee f WHERE f.type=4) THEN
	INSERT INTO fee(title,price,type,student_id) VALUES("书本费",0.01,4,0);
	END IF;
     
	
    UPDATE operate_item oi INNER JOIN fee f ON oi.group_id=in_group_id AND oi.status=2  AND f.type=4
    INNER JOIN payment p ON f.id=p.fee_id AND oi.c1=p.student_id
    SET oi.status=4 , p.paid=1;
    
    
    INSERT INTO payment(student_id,fee_id,paid,pay_type) 
    SELECT oi.c1,f.id,1,2 FROM  operate_item oi ,fee f
    WHERE oi.group_id=in_group_id AND oi.status=2 AND f.type=4;
    
	
    UPDATE operate_group SET status=4 WHERE id= in_group_id;
	UPDATE operate_item SET status=4 WHERE group_id= in_group_id AND status=2;

END;

