create
    definer = devuser@`%` procedure assigned_teacher_search_by_course(IN in_course_id int, IN in_center_id int,
                                                                      IN in_offset int, IN in_count int,
                                                                      OUT out_total_records int)
BEGIN
	
    SELECT sql_calc_found_rows * FROM teacher t 
    WHERE t.id IN (SELECT tc.teacher_id FROM teacher_course tc WHERE tc.course_id = in_course_id)
	AND (in_center_id IS NULL OR t.center_id = in_center_id)
    LIMIT in_offset, in_count;

	SET out_total_records = found_rows();  

END;

