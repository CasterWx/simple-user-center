create
    definer = devuser@`%` procedure user_school_get_by_uids(IN in_user_id_list mediumtext)
BEGIN
	set @sql = concat("SELECT * FROM user_school WHERE user_id in (", in_user_id_list,")");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END;

