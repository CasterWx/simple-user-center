create
    definer = devuser@`%` procedure res_sync_resources(IN in_group_type varchar(100), OUT out_group_id int,
                                                       OUT out_result_code int)
BEGIN
	DECLARE var_batch_group_id INT(11) DEFAULT 0;
	DECLARE v_status_ready VARCHAR (1) DEFAULT '0';
	DECLARE v_status_doing VARCHAR (1) DEFAULT '2';
	DECLARE v_status_done VARCHAR (1) DEFAULT '1';
	DECLARE v_status_error VARCHAR (1) DEFAULT '3';

	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;	
	SET out_result_code=1;

	SELECT id INTO var_batch_group_id FROM batch_group a 
	WHERE a.`status`=v_status_ready
	AND	a.group_type=in_group_type 
	ORDER BY created_time DESC LIMIT 1;
	
	IF var_batch_group_id IS NOT NULL AND var_batch_group_id >0 THEN
		UPDATE batch_group a SET a.`status`=v_status_doing,a.updated_time=NOW() WHERE a.id=var_batch_group_id;

		
		

		UPDATE `res_book_type` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name AND b.item_type='book_type'
		SET a.`name`=b.c0, a.updated_time=NOW()
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_book_type 
		(res_id,`name`, `created_time`, `updated_time`)
		SELECT 
		file_name,c0, NOW(), NOW()
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='book_type' AND NOT EXISTS(SELECT 1 FROM res_book_type a WHERE  a.res_id=b.file_name);
	

		
		UPDATE batch_group_item b 
		INNER JOIN res_book_type a on b.c0=a.res_id
		SET b.c10=a.id
		WHERE b.batch_group_id=var_batch_group_id AND b.item_type='book' AND a.res_id IS NOT NULL;

		UPDATE `res_book` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name AND b.item_type='book'
		SET a.type=CONVERT(b.c10, SIGNED), a.dxid=b.c1, a.book_key=b.c2, a.`name`=b.c3, a.author=b.c4, 
		a.publisher=b.c5, a.isbn=b.c6, a.path=b.c7, a.cover_img_path=b.c8,
		a.catalog=b.c9, a.updated_time=NOW(), a.`status`=CONVERT(b.c12, SIGNED)
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_book (res_id, type, dxid, book_key, name, author, publisher, isbn, path, cover_img_path, catalog, created_time, updated_time, status) 
		SELECT file_name, c0, CONVERT(b.c10, SIGNED), c2, c3, c4, c5, c6, c7, c8, c9, NOW(), NOW(), CONVERT(c12, SIGNED)
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='book' AND NOT EXISTS(SELECT 1 FROM res_book a WHERE a.res_id=b.file_name);

		
		
		UPDATE `res_course` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name AND b.item_type='course'
		SET a.`name`=b.c0, a.description=b.c1,a.`level`=b.c2,a.`school_category_type`=CONVERT(b.c3, SIGNED),a.updated_time=NOW(), a.`status`=CONVERT(b.c6, SIGNED)
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_course 
		(res_id,`name`,description, `level`, `school_category_type`, `created_time`, `updated_time`, `status`)
		 SELECT 
		file_name,c0, c1,c2, CONVERT(b.c3, SIGNED), NOW(), NOW(), CONVERT(c6, SIGNED)
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course' AND NOT EXISTS(SELECT 1 FROM res_course a WHERE  a.res_id=b.file_name);


		
		UPDATE batch_group_item b INNER JOIN res_course a ON b.c0=a.res_id
		SET b.c10=a.id
		WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course_book' AND a.res_id IS NOT NULL;

		UPDATE batch_group_item b INNER JOIN res_book a ON b.c1=a.res_id
		SET b.c11=a.id
		WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course_book' AND a.res_id IS NOT NULL;

		UPDATE `res_course_book` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name  AND b.item_type='course_book'
		SET a.course_id=CONVERT(b.c10, SIGNED), a.book_id=CONVERT(b.c11, SIGNED), a.selected=CONVERT(b.c2, SIGNED), a.updated_time=NOW(), a.`status`=CONVERT(b.c5, SIGNED)
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_course_book 
		(res_id,`course_id`, `book_id`, `selected`, `created_time`, `updated_time`, `status`)
		SELECT 
		file_name,CONVERT(c10, SIGNED), CONVERT(c11, SIGNED), c2, NOW(), NOW(),CONVERT(c5, SIGNED)
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course_book' AND NOT EXISTS(SELECT 1 FROM res_course_book a WHERE  a.res_id=b.file_name);

		

		UPDATE `res_courseware` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name AND b.item_type='courseware'
		SET a.url=b.c0, a.`name`=b.c1, a.`level`=b.c2, a.updated_time=NOW(), a.`status`=CONVERT(b.c5, SIGNED),a.`public`=CONVERT(b.c6, SIGNED),a.provider_info=b.c7
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_courseware 
		(res_id,`url`, `name`, `level`, `created_time`, `updated_time`, `status`, `public`, `provider_info`)
		SELECT 
		file_name,c0, c1, c2, NOW(), NOW(), CONVERT(c5, SIGNED), CONVERT(c6, SIGNED), c7
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='courseware' AND NOT EXISTS(SELECT 1 FROM res_courseware a WHERE a.res_id=b.file_name);


		
		UPDATE batch_group_item b INNER JOIN res_course a on b.c0=a.res_id
		SET b.c10=a.id
		WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course_courseware' AND a.res_id IS NOT NULL;

		UPDATE batch_group_item b INNER JOIN res_courseware a on b.c1=a.res_id
		SET b.c11=a.id
		WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course_courseware' AND a.res_id IS NOT NULL;

		UPDATE `res_course_courseware` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name AND b.item_type='course_courseware'
		SET  a.course_id=CONVERT(b.c10, SIGNED),a.courseware_id=CONVERT(b.c11, SIGNED),a.selected=CONVERT(b.c2, SIGNED),a.updated_time=NOW(), a.`status`=CONVERT(b.c5, SIGNED)
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_course_courseware 
		(res_id,`course_id`, `courseware_id`, `selected`, `created_time`, `updated_time`, `status`)
		SELECT 
		file_name,CONVERT(c10, SIGNED), CONVERT(c11, SIGNED), c2, NOW(), NOW(),CONVERT(c5, SIGNED)
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='course_courseware' AND NOT EXISTS(SELECT 1 FROM res_course_courseware a WHERE  a.res_id=b.file_name);

		

		DELETE a FROM res_level a WHERE a.res_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM batch_group_item b WHERE  b.file_name=a.res_id AND b.batch_group_id=var_batch_group_id AND b.item_type='level');

		UPDATE `res_level` a
		INNER JOIN batch_group_item b ON a.res_id=b.file_name AND b.item_type='level'
		SET a.`name`=b.c0,a.updated_time=NOW()
		WHERE b.batch_group_id=var_batch_group_id AND a.res_id IS NOT NULL;

		INSERT INTO res_level 
		(res_id,`name`, `created_time`, `updated_time`)
		SELECT 
		file_name,c0,NOW(), NOW()
		FROM batch_group_item b WHERE b.batch_group_id=var_batch_group_id AND b.item_type='level' AND NOT EXISTS(SELECT 1 FROM res_level a WHERE  a.res_id=b.file_name);

		SET out_result_code=0;
		IF t_error = 1 THEN
				SET out_result_code = 2;
				SET out_group_id=var_batch_group_id;
				UPDATE batch_group a SET a.`status`=v_status_error,a.status_msg='SQLEXCEPTION',a.updated_time=NOW() WHERE a.id=var_batch_group_id;
		ELSE 
			SET out_result_code=0;
			SET out_group_id=var_batch_group_id;
			UPDATE batch_group a SET a.`status`=v_status_done,a.status_msg='done',a.updated_time=NOW() WHERE a.id=var_batch_group_id;
		END IF;
		SET out_group_id=var_batch_group_id;
	ELSE
		SET out_group_id=-1;
		SET out_result_code = 3;
	END IF;	

	DELETE b,a FROM batch_group a INNER JOIN batch_group_item b ON a.id=b.batch_group_id
	WHERE a.id<=var_batch_group_id AND a.group_type='ressysImport';
END;

