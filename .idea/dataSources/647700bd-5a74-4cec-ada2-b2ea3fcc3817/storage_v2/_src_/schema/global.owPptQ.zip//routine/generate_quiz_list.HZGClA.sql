create
    definer = devuser@`%` procedure generate_quiz_list()
BEGIN
	DECLARE course_id_in_loop INT;
	DECLARE top_material_id INT;

	DECLARE NO_MORE_COURSE BIT DEFAULT FALSE;
	DECLARE cursor_for_course CURSOR FOR SELECT DISTINCT course_id FROM quiz;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET NO_MORE_COURSE = TRUE;

	OPEN cursor_for_course;
	COURSE_LOOP:LOOP 
		FETCH cursor_for_course INTO course_id_in_loop;
		IF NO_MORE_COURSE THEN
			CLOSE cursor_for_course;
			LEAVE COURSE_LOOP;
		END IF;
		
		INSERT INTO material (course_id,material_type_id,title,description) VALUES (course_id_in_loop,1,'章节测试','章节测试');
		SELECT LAST_INSERT_ID() INTO top_material_id;
		BEGIN			
			DECLARE quiz_id_in_loop INT;
			DECLARE quiz_title_in_loop VARCHAR(64);
			DECLARE NO_MORE_QUIZ BIT DEFAULT FALSE;
			DECLARE cursor_for_quiz CURSOR FOR SELECT id,title FROM quiz WHERE course_id=course_id_in_loop;			
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET NO_MORE_QUIZ = TRUE; 
			
			OPEN cursor_for_quiz;
			QUIZ_LOOP:LOOP
				FETCH cursor_for_quiz INTO quiz_id_in_loop,quiz_title_in_loop;	
				IF NO_MORE_QUIZ THEN
					CLOSE cursor_for_quiz;
					LEAVE QUIZ_LOOP;
				END IF;
				INSERT INTO material(course_id,parent_id,material_type_id,title,description,url) VALUES(course_id_in_loop,top_material_id,2,quiz_title_in_loop,quiz_title_in_loop,concat('QuizPaperEntrance?courseId=',course_id_in_loop,'&quizId=',quiz_id_in_loop));
			END LOOP QUIZ_LOOP;
		END;		
	END LOOP COURSE_LOOP;
END;

