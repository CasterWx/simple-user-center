create
    definer = devuser@`%` procedure user_author_get_by_uid(IN in_uid varchar(45))
BEGIN
	select * from user_author
		where uid = in_uid;
END;

