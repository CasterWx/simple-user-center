create
    definer = devuser@`%` procedure school_group_create(IN in_group_id int, IN in_member_id int, OUT out_id int)
BEGIN

	INSERT INTO `school_group_create`(group_id, member_id)
    VALUES(in_group_id, in_member_id);

    SET out_id = LAST_INSERT_ID();

END;

