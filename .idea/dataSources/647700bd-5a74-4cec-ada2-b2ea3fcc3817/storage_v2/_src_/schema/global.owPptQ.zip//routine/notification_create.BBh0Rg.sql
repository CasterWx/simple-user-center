create
    definer = devuser@`%` procedure notification_create(IN in_school_id int, IN in_target varchar(500),
                                                        IN in_content varchar(500), IN in_custom_type int,
                                                        IN in_custom_data varchar(200), IN in_creator_id int,
                                                        IN in_published bit, IN in_publisher_id int, OUT out_id int)
BEGIN

    INSERT INTO notification(school_id, target, content, custom_type, custom_data, creator_id, published, publisher_id, published_time) 
    VALUES(in_school_id, in_target, in_content, in_custom_type, in_custom_data, in_creator_id, in_published, in_publisher_id, CASE in_published WHEN 1 THEN NOW() ELSE NULL END);

    SET out_id = LAST_INSERT_ID();

END;

