create
    definer = devuser@`%` procedure delete_relateddata_formodifymajor(IN in_group_id int, IN in_major_id int)
BEGIN       
     
	
    UPDATE operate_item oi INNER JOIN student s ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s.id AND s.major_id=in_major_id
    SET oi.status=3;
  
	
    DELETE s_course_track
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN student_course_track s_course_track ON oi.c1=s_course_track.student_id AND s_course.teachingplan_course_id=s_course_track.teachingplan_course_id;
      
	
	DELETE s_course_activity_score
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN student_course_activity_score s_course_activity_score ON oi.c1=s_course_activity_score.student_id AND s_course.teachingplan_course_id=s_course_activity_score.teachingplan_course_id;
    
	
	DELETE s_course_otherscore
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN student_course_otherscore s_course_otherscore ON oi.c1=s_course_otherscore.student_id AND s_course.teachingplan_course_id=s_course_otherscore.teachingplan_course_id;
    
	
	DELETE c_study_record
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN course_study_record c_study_record ON oi.c1=c_study_record.student_id AND s_course.teachingplan_course_id=c_study_record.teachingplan_course_id;
    
	
	DELETE s_exam_score
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN student_exam_score s_exam_score ON oi.c1=s_exam_score.student_id AND s_course.teachingplan_course_id=s_exam_score.teachingplan_course_id;
    
    
	DELETE c_student_score
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN count_student_score c_student_score ON oi.c1=c_student_score.student_id AND s_course.teachingplan_course_id=c_student_score.teachingplan_course_id;
    
    
	DELETE s_final_reservation
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN student_final_reservation s_final_reservation ON oi.c1=s_final_reservation.student_id
    LEFT JOIN final_slot_course f_slot_course ON s_final_reservation.final_slot_course_id = f_slot_course.id AND s_course.teachingplan_course_id=f_slot_course.teachingplan_course_id;
    
    
	DELETE s_exam
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN exam em ON s_course.teachingplan_course_id=em.teachingplan_course_id
    LEFT JOIN student_exam s_exam ON s_exam.exam_id= em.id AND s_exam.student_id=oi.c1;
    
    
	DELETE s_answer
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN exam em ON s_course.teachingplan_course_id=em.teachingplan_course_id
    LEFT JOIN student_answer s_answer ON  oi.c1=s_answer.student_id AND s_answer.test_id=em.id AND test_type = 1;
    
    
	DELETE s_answer
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN exercise exer ON s_course.teachingplan_course_id=exer.teachingplan_course_id
    LEFT JOIN student_answer s_answer ON  oi.c1=s_answer.student_id AND s_answer.test_id=exer.id AND test_type = 0;
    
    
	DELETE s_exercise
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN exercise exer ON s_course.teachingplan_course_id=exer.teachingplan_course_id
    LEFT JOIN student_exercise s_exercise ON s_exercise.exercise_id=exer.id AND oi.c1=s_exercise.student_id;
    
    
    DELETE s_makeup_exam
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1
    LEFT JOIN student_makeup_exam s_makeup_exam ON s_course.teachingplan_course_id=s_makeup_exam.teachingplan_course_id AND oi.c1=s_makeup_exam.student_id;
    
	
	DELETE s_course 
    FROM operate_item oi
    INNER JOIN student_course s_course ON oi.group_id=in_group_id AND oi.status=2 AND oi.c1=s_course.student_id AND s_course.flag != 1;
    
END;

