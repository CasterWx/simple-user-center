create
    definer = devuser@`%` procedure get_by_school_operate_item(IN in_operate_group_id int, IN in_c0 int)
BEGIN
	select * from operate_item
    where group_id = in_operate_group_id and c0 = in_c0;
    
END;

