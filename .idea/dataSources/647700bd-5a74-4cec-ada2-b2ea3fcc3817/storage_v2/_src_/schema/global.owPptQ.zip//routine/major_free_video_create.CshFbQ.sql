create
    definer = devuser@`%` procedure major_free_video_create(IN in_major_id int, IN in_video_title varchar(200),
                                                            IN in_video_introduction varchar(500),
                                                            IN in_video_url varchar(500), OUT out_id int)
BEGIN

    INSERT INTO `major_free_video`
    (`major_id`,
    `video_title`,
    `video_introduction`,
    `video_url`)
    VALUES
    (in_major_id,
     in_video_title,
     in_video_introduction,
     in_video_url
     );

    SET out_id = LAST_INSERT_ID();
END;

