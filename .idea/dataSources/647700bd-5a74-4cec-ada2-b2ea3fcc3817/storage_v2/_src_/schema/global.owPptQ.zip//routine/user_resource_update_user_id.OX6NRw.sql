create
    definer = devuser@`%` procedure user_resource_update_user_id(IN in_user_id int, IN in_delete_user_id int)
BEGIN

   SET SQL_SAFE_UPDATES = 0;
   
   UPDATE user_resource SET user_id=in_user_id WHERE user_id=in_delete_user_id;

END;

