create
    definer = devuser@`%` procedure user_school_delete(IN in_global_user_id int, IN in_school_id int)
BEGIN
    set SQL_SAFE_UPDATES = 0;
    delete from user_school 
    where (in_global_user_id is null or user_id = in_global_user_id)
    AND (in_school_id is null or school_id = in_school_id);
END;

