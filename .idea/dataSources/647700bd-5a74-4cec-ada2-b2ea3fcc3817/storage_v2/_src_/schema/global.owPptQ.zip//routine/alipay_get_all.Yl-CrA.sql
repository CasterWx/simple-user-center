create
    definer = devuser@`%` procedure alipay_get_all()
BEGIN
	
	SELECT * FROM alipay;
	
END;

