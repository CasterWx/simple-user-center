create
    definer = devuser@`%` procedure import_teacher(IN in_group_id int, IN in_teacher_permissions varchar(500),
                                                   IN in_staff_permissions varchar(500))
BEGIN
	
	DECLARE local_waiting INT DEFAULT 1;
    DECLARE local_valid INT DEFAULT 2;
    DECLARE local_invalid INT DEFAULT 3;
    DECLARE local_complete INT DEFAULT 4;
    DECLARE local_cancel INT DEFAULT 5;
    DECLARE local_checking INT DEFAULT 6;
    
    
    DECLARE local_teacher_role INT DEFAULT 2;
    DECLARE local_staff_role INT DEFAULT 3;
    DECLARE local_permission_id INT DEFAULT 0;
    
    
	
    INSERT INTO center(name)
    SELECT DISTINCT oi.c4 from operate_item oi WHERE oi.group_id = in_group_id AND oi.status = local_valid
    AND oi.c4 IS NOT NULL AND oi.c4 != ''
    AND NOT EXISTS (SELECT id FROM center WHERE name = oi.c4);
    
    UPDATE operate_item oi INNER JOIN center c ON oi.group_id = in_group_id AND oi.status = local_valid
    AND oi.c4 = c.name
    SET oi.c7 = c.id;
    
    
    INSERT INTO teacher(global_user_id,center_id)
    SELECT oi.c5,oi.c7 FROM operate_item oi WHERE oi.group_id = in_group_id AND oi.status = local_valid;
    
    
    UPDATE operate_item oi INNER JOIN teacher t on oi.group_id = in_group_id AND oi.status = local_valid
    AND oi.c5 = t.global_user_id
    SET oi.c8 = t.id;
    
    
    DROP TEMPORARY TABLE IF EXISTS temp_teacher_role;
    CREATE TEMPORARY TABLE temp_teacher_role(id INT(11));
    WHILE LENGTH(in_teacher_permissions) >0 DO
        SET local_permission_id = SUBSTRING_INDEX(in_teacher_permissions, '|', 1);
        SET in_teacher_permissions = SUBSTRING(in_teacher_permissions,LENGTH(local_permission_id) +2);
        
        INSERT INTO temp_teacher_role(id) values(CAST(local_permission_id AS SIGNED));
    END WHILE;
    
    DROP TEMPORARY TABLE IF EXISTS temp_staff_role;
    CREATE TEMPORARY TABLE temp_staff_role(id INT(11));
    WHILE LENGTH(in_staff_permissions) >0 DO
        SET local_permission_id = SUBSTRING_INDEX(in_staff_permissions, '|', 1);
        SET in_staff_permissions = SUBSTRING(in_staff_permissions,LENGTH(local_permission_id) +2);
        
        INSERT INTO temp_staff_role(id) values(CAST(local_permission_id AS SIGNED));
    END WHILE;
    
    
    INSERT INTO teacher_module(teacher_id,module_id)
    SELECT oi.c8,tt.id from operate_item oi,temp_teacher_role tt
    WHERE oi.group_id = in_group_id AND oi.status = local_valid AND oi.c6=local_teacher_role;
    
    
    INSERT INTO teacher_module(teacher_id,module_id)
    SELECT oi.c8,ts.id from operate_item oi,temp_staff_role ts
    WHERE oi.group_id = in_group_id AND oi.status = local_valid AND oi.c6=local_staff_role;
    
    
    UPDATE operate_group SET status = local_complete WHERE id = in_group_id;
    UPDATE operate_item SET status = local_complete,comment = '导入成功' WHERE group_id = in_group_id AND status = local_valid;
    
    DROP TEMPORARY TABLE IF EXISTS temp_teacher_role;
    DROP TEMPORARY TABLE IF EXISTS temp_staff_role;
END;

