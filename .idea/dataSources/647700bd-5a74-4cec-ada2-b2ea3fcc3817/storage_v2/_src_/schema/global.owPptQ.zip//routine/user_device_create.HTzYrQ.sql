create
    definer = devuser@`%` procedure user_device_create(IN in_user_id int, IN in_os int(1), IN in_mac varchar(45),
                                                       IN in_idfa varchar(45), IN in_imei varchar(45),
                                                       IN in_status int(1), OUT out_id int)
BEGIN

	INSERT INTO user_device(user_id, os, mac, idfa, imei, status)

	VALUES(in_user_id, in_os, in_mac, in_idfa, in_imei, in_status);

	SET out_id = LAST_INSERT_ID();

END;

