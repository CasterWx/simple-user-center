create
    definer = devuser@`%` procedure delete_user_batch_globalpart(IN in_group_id int, IN in_school_id int)
BEGIN       
		DROP TEMPORARY TABLE IF EXISTS delete_user_id_tb;
        
		CREATE TEMPORARY TABLE delete_user_id_tb(
			user_id INT(11)
		);
        
		INSERT INTO delete_user_id_tb SELECT c2 FROM operate_item WHERE group_id = in_group_id AND status = 2 ;

		INSERT INTO user_school_bak_for_delete(user_school_id,user_id,school_id,user_role,group_id)
		SELECT us.*,oi.group_id FROM user_school us INNER JOIN operate_item oi ON us.user_id = oi.c2 AND oi.group_id = in_group_id AND us.school_id = in_school_id;

		INSERT INTO global_user_bak_for_delete(global_user_id,user_name,display_name,created_time,updated_time,password,gender,phone_num,address,identity_card,photo_image_id,email,user_type,phone_valid,group_id)
		SELECT gu.*, in_group_id FROM global_user gu INNER JOIN delete_user_id_tb t ON t.user_id = gu.id
		LEFT JOIN user_school us ON us.user_id = gu.id AND us.school_id != in_school_id WHERE us.id is NULL; 
		
		DELETE u FROM user_school u INNER JOIN operate_item oi ON u.user_id = oi.c2 AND oi.group_id = in_group_id AND u.school_id = in_school_id;
		
		DELETE gi FROM user_author gu INNER JOIN delete_user_id_tb t ON t.user_id = gu.user_id
        INNER JOIN global_image gi ON gu.uphoto_image_id = gi.id AND gi.image_type = 0;
		
		DELETE u FROM user_author u INNER JOIN delete_user_id_tb t ON t.user_id = u.user_id;
		
        DELETE gi FROM global_user gu INNER JOIN delete_user_id_tb t ON t.user_id = gu.id
        INNER JOIN global_image gi ON gu.photo_image_id = gi.id AND gi.image_type = 0
		LEFT JOIN user_school us ON us.user_id = gu.id AND us.school_id != in_school_id WHERE us.id is NULL; 

		DELETE gu FROM global_user gu INNER JOIN delete_user_id_tb t ON t.user_id = gu.id
		LEFT JOIN user_school us ON us.user_id = gu.id AND us.school_id != in_school_id WHERE us.id is NULL; 

		UPDATE operate_item SET status=4 WHERE group_id=in_group_id AND status=2;
		UPDATE operate_group SET status= 4 WHERE id=in_group_id;
		
		DROP TEMPORARY TABLE delete_user_id_tb;
END;

