create
    definer = devuser@`%` procedure support_kf5_user_update(IN in_id int, IN in_type int, IN in_email_id int,
                                                            IN in_kf5_user_id int, IN in_kf5_user_token varchar(1000),
                                                            IN in_kf5_email varchar(255), IN in_kf5_phone varchar(20),
                                                            IN in_initial_email varchar(255))
BEGIN
	
	UPDATE `support_kf5_user` SET
	`type` = in_type,
	`email_id` = in_email_id,
	`kf5_user_id` = in_kf5_user_id,
	`kf5_user_token` = in_kf5_user_token,
	`kf5_email` = in_kf5_email,
	`kf5_phone` = in_kf5_phone,
	`initial_email` = in_initial_email
	WHERE `id` = in_id;
end;

