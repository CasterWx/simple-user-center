create
    definer = devuser@`%` procedure video_create(IN in_resource_id int, IN in_persistent_id varchar(255),
                                                 IN in_source_url varchar(255), IN in_target_url varchar(255),
                                                 OUT out_id int)
BEGIN

	INSERT INTO `video`(resource_id, `persistent_id`, `source_url`, `target_url`)
	VALUES (in_resource_id, in_persistent_id, in_source_url, in_target_url);

	SET out_id = last_insert_id();
END;

