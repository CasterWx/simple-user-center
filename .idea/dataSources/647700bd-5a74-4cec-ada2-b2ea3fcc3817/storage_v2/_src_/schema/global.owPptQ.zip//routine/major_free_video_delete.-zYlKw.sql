create
    definer = devuser@`%` procedure major_free_video_delete(IN in_id int)
BEGIN
    DELETE FROM major_free_video WHERE id = in_id;
END;

