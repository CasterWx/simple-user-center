create
    definer = devuser@`%` procedure operategroup_get(IN in_id int)
BEGIN

	SELECT * FROM operate_group WHERE id=in_id;

END;

