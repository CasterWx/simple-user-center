create
    definer = devuser@`%` procedure identification_type_get_all()
BEGIN

	SELECT * FROM identification_type;

END;

