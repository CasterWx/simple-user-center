create
    definer = devuser@`%` procedure global_operateitem_update(IN in_id int, IN in_status int,
                                                              IN in_comment varchar(255), IN in_c0 varchar(255),
                                                              IN in_c1 varchar(255), IN in_c2 varchar(255),
                                                              IN in_c3 varchar(255), IN in_c4 varchar(255),
                                                              IN in_c5 varchar(255), IN in_c6 varchar(255),
                                                              IN in_c7 varchar(255), IN in_c8 varchar(255),
                                                              IN in_c9 varchar(255), IN in_c10 varchar(255),
                                                              IN in_c11 varchar(255), IN in_c12 varchar(255),
                                                              IN in_c13 varchar(255), IN in_c14 varchar(255),
                                                              IN in_c15 varchar(255), IN in_c16 varchar(255),
                                                              IN in_c17 varchar(255), IN in_c18 varchar(255),
                                                              IN in_c19 varchar(255), IN in_c20 varchar(255),
                                                              IN in_c21 varchar(255), IN in_c22 varchar(255),
                                                              IN in_c23 varchar(255), IN in_c24 varchar(255))
BEGIN
	
	UPDATE operate_item 
	SET c1=in_c1,
		c2=in_c2,
		c3=in_c3,
		c4=in_c4,
		c5=in_c5,
		c6=in_c6,
		c7=in_c7,
		c8=in_c8,
		c9=in_c9,
		c10=in_c10,
		c11=in_c11,
		c12=in_c12,
		c13=in_c13,
		c14=in_c14,
		c15=in_c15,
		c16=in_c16,
		c17=in_c17,
		c18=in_c18,
		c19=in_c19,
		c20=in_c20,
		c21=in_c21,
		c22=in_c22,
		c23=in_c23,
		c24=in_c24,
		`status`=in_status,
		`comment`=in_comment
	WHERE id=in_id;
    
END;

