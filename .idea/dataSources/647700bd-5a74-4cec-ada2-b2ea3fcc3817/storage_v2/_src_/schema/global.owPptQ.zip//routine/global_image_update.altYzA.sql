create
    definer = devuser@`%` procedure global_image_update(IN in_id int, IN in_name varchar(300), IN in_url varchar(500),
                                                        IN in_image_type int)
BEGIN

	UPDATE global_image SET name = in_name,
					  url = in_url,
					  image_type = in_image_type
	WHERE id = in_id;
    
END;

