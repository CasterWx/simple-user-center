create
    definer = devuser@`%` procedure ImportQuiz(IN fromNumber int, IN toNumber int)
BEGIN

	DECLARE course_done,quiz_done,question_done BOOLEAN DEFAULT FALSE;
	declare new_course_id,old_course_id,old_quiz_id,old_question_id,new_quiz_id,new_question_id int;

	declare cur_course cursor for select id,xbgyid from course where xbgyid > 0 and id>fromNumber and id<=toNumber;
	declare continue handler for not found set course_done = true;
 
    open cur_course;
    cur_course_Loop: loop
	fetch from cur_course into new_course_id,old_course_id;
        
		if course_done then
			close cur_course;
			leave cur_course_Loop; 
		end if;
		
		select concat('course_id: ', new_course_id,'xbgyid: ',old_course_id) AS '** DEBUG: ';

		block2: begin		

		DECLARE cur_quiz CURSOR FOR select id from quiz where course_id=old_course_id and created_time < '2015-01-06 18:55:00' ;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET quiz_done = TRUE;
        OPEN cur_quiz; 
        cur_quiz_loop: LOOP
        FETCH FROM cur_quiz INTO old_quiz_id;   
            
			IF quiz_done THEN
				set quiz_done = false;
				CLOSE cur_quiz;
				LEAVE cur_quiz_loop;
            END IF; 

			insert into quiz(course_id,title,total_score,min_score)
			select new_course_id,title,total_score,min_score from quiz where id = old_quiz_id;	
			
			set new_quiz_id= last_insert_id();

			-- select concat('old_quiz_id: ', old_quiz_id,'new_quiz_id: ',new_quiz_id) AS '** DEBUG: ';
         
			BLOCK3: BEGIN
			DECLARE cur_question CURSOR FOR SELECT question_id FROM quiz_question where quiz_id=old_quiz_id;
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET question_done = TRUE;
			OPEN cur_question; 
			cur_question_loop: LOOP
			FETCH FROM cur_question INTO old_question_id;   

				IF question_done THEN
					set question_done = false;
					CLOSE cur_question;
					LEAVE cur_question_loop;
				END IF; 
				
				insert into question(question_type,course_id,parent_id,title,description,analysis,solution,status)
				select question_type, new_course_id, 0, title, description, analysis, solution,status
				from question where id = old_question_id;

				set new_question_id= last_insert_id();

				-- select concat('old_question_id: ', old_question_id,'new_question_id: ',new_question_id) AS '** DEBUG: ';
	
				insert into quiz_question(quiz_id,question_id,score)
				select new_quiz_id,new_question_id,score from  quiz_question where quiz_id=old_quiz_id and question_id=old_question_id;

				insert into `option`(question_id,label,description)
				select new_question_id,label,description from  `option` where question_id =old_question_id;

			END LOOP cur_question_loop;
			END BLOCK3;

        END LOOP cur_quiz_loop;
		end block2;

	end loop cur_course_Loop;
END;

