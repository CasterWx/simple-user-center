create
    definer = devuser@`%` procedure global_image_get_by_id(IN in_id int)
BEGIN
	
    SELECT * FROM global_image WHERE id = in_id;
END;

