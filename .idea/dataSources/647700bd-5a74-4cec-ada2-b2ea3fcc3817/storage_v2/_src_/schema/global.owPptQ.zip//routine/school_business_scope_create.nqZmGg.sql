create
    definer = devuser@`%` procedure school_business_scope_create(IN in_school_id int, IN in_region_id int, OUT out_id int)
BEGIN
    INSERT INTO `school_business_scope`(`school_id`,`region_id`)
    VALUES(in_school_id, in_region_id);
    
    SET out_id = LAST_INSERT_ID();
END;

