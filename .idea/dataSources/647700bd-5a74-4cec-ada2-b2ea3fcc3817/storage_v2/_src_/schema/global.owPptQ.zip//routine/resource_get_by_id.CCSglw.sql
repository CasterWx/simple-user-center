create
    definer = devuser@`%` procedure resource_get_by_id(IN in_id int)
BEGIN

	SELECT * FROM `resource` WHERE id = in_id;

END;

