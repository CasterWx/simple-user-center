create
    definer = devuser@`%` procedure async_degree_student_number_import_check(IN in_group_id int, IN in_school_id int)
BEGIN
	 UPDATE operate_group og SET og.status = 10, og.result = null WHERE og.id = in_group_id;

	 UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','手机号格式不正确'),'手机号格式不正确') 
	 WHERE oi.c10 IS NOT NULL AND oi.c10 != '' AND oi.c10 NOT REGEXP '^[1][3-9][0-9]{9}$' AND oi.group_id = in_group_id;
	
	 UPDATE operate_item oi
	 INNER JOIN global_user gu on oi.group_id = in_group_id and oi.c9 = gu.identity_card
	 SET oi.c22 = gu.id, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','身份证已被使用'),'身份证已被使用'), oi.`status` = 7
	 WHERE NOT EXISTS(SELECT 1 from user_school us where us.school_id = in_school_id AND us.user_id = gu.id);

   UPDATE operate_item oi  
   INNER JOIN global_user gu ON oi.group_id = in_group_id AND  oi.c9 != '' AND oi.c9 = gu.identity_card AND oi.`status` != 7
   SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','身份证已被使用'),'身份证已被使用'); 

	 UPDATE operate_item oi
   INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.c1 = gu.user_name AND oi.`status` != 7
   SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名已被注册'),'用户名已被注册'); 

	 UPDATE operate_item oi  
   INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.c10 != '' AND oi.c10 = gu.phone_num AND oi.`status` != 7
   SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','手机号已被使用'),'手机号已被使用');

	 UPDATE operate_item oi
	 INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.`status` = 7 AND oi.c22 = gu.id
	 SET oi.`status` = 3, oi.`comment` = CONCAT(oi.`comment`,' ','当前数据与数据库的内容不符')
	 WHERE oi.c4 != gu.display_name OR (gu.gender IS NOT NULL AND gu.gender != oi.c5) OR (gu.identity_card IS NOT NULL AND oi.c9 != gu.identity_card) OR (gu.phone_num IS NOT NULL AND oi.c10 != gu.phone_num)
   OR (gu.address IS NOT NULL AND oi.c11 != gu.address);

   UPDATE operate_item SET comment='有效数据' WHERE status = 2 AND group_id = in_group_id;
      
   UPDATE operate_group og SET og.status = 2 WHERE NOT EXISTS (select 1 from operate_item where (status = 3 or `status` = 7 or `status` = 11) and group_id = in_group_id) AND og.id = in_group_id;
     
   UPDATE operate_group og SET og.`status` = 7 WHERE NOT EXISTS(SELECT 1 FROM operate_item WHERE `status` = 3 and group_id = in_group_id) AND og.`status` != 2 AND og.id=in_group_id;

   UPDATE operate_group og INNER JOIN operate_item oi ON oi.group_id = og.id SET og.status = 3 WHERE oi.`status` = 3 AND og.id = in_group_id;

END;

