create
    definer = devuser@`%` procedure ppt_delete_by_id(IN in_id int)
BEGIN

	DELETE FROM ppt WHERE id = in_id;

END;

