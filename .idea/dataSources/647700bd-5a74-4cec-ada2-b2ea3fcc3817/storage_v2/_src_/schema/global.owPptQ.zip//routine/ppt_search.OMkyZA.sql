create
    definer = devuser@`%` procedure ppt_search(IN in_resource_ids mediumtext, IN in_ppt_task_id int)
BEGIN

	DECLARE sql_str VARCHAR(5000);

	SET sql_str = "SELECT * FROM ppt WHERE true";
	IF in_resource_ids IS NOT NULL THEN
		SET sql_str = CONCAT(sql_str, " AND resource_id IN (", in_resource_ids, ") ");
	END IF;
	IF in_ppt_task_id IS NOT NULL THEN 
		SET sql_str = CONCAT(sql_str, " AND ppt_task_id = ", in_ppt_task_id);
	END IF;
	
	SET @sql_search = sql_str;
	PREPARE s2 FROM @sql_search;
	EXECUTE s2;
	DEALLOCATE PREPARE s2;
	
END;

