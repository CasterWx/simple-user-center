create
    definer = devuser@`%` procedure global_generate_imported_teacher(IN in_group_id int, IN in_school_id int)
BEGIN
	
	DECLARE local_waiting INT DEFAULT 1;
    DECLARE local_valid INT DEFAULT 2;
    DECLARE local_invalid INT DEFAULT 3;
    DECLARE local_complete INT DEFAULT 4;
    DECLARE local_cancel INT DEFAULT 5;
    DECLARE local_checking INT DEFAULT 6;
    
    
    DECLARE local_usualAccount INT DEFAULT 0;
    DECLARE local_superManager INT DEFAULT 1;
    
    
    DECLARE local_teacher_role INT DEFAULT 2;
    DECLARE local_staff_role INT DEFAULT 3;
    
    
    UPDATE global_user gu INNER JOIN operate_item oi 
    ON oi.group_id = in_group_id AND oi.status = local_valid AND gu.user_name = oi.c1
    SET gu.password = oi.c2, gu.display_name = oi.c3,oi.c5 = gu.id,oi.status = local_complete;
    
    
    INSERT INTO global_user(user_name,password,display_name,user_type)
    SELECT oi.c1,oi.c2,oi.c3,local_usualAccount FROM operate_item oi 
    WHERE oi.group_id = in_group_id AND oi.status = local_valid;
    
    UPDATE operate_item oi INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.status = local_valid
    AND oi.c1 = gu.user_name
    SET oi.status = local_complete , oi.c5 = gu.id;
    
    
    UPDATE operate_item oi SET oi.c6 =
 	CASE WHEN (oi.c4 = '' OR oi.c4 IS NULL)
	 THEN local_teacher_role else local_staff_role END
	WHERE oi.group_id = in_group_id AND oi.status = local_complete;
    
    INSERT INTO user_school(user_id,school_id,user_role)
    SELECT oi.c5,in_school_id,oi.c6 FROM operate_item oi 
    WHERE oi.group_id = in_group_id AND oi.status = local_complete;
    
    
    UPDATE operate_item oi SET oi.status = local_valid
    WHERE  oi.group_id = in_group_id AND oi.status = local_complete;
    
END;

