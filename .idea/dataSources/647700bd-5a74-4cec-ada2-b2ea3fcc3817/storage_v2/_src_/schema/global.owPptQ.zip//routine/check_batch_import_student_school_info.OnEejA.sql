create
    definer = devuser@`%` procedure check_batch_import_student_school_info(IN in_operate_group_id int, IN in_center_id int)
BEGIN
	
	DECLARE VALID INT;
    DECLARE INVALID INT;
    DECLARE CHECKING INT;
    DECLARE WAITING INT;
    DECLARE GROUPTYPE INT;
    
    SET VALID = 2;
    SET INVALID = 3;
    SET CHECKING = 6;
    SET WAITING = 1;
   
	SELECT `type` FROM operate_group WHERE id = in_operate_group_id INTO GROUPTYPE;
    
	SET SQL_SAFE_UPDATES = 0;

    UPDATE operate_group og SET og.status = CHECKING, og.check_process = 0 WHERE og.id=in_operate_group_id;
    
    
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '专业名称不能为空' WHERE (oi.c1 IS NULL OR oi.c1 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '学习层次不能为空' WHERE (oi.c2 IS NULL OR oi.C2 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '中心名称不能为空' WHERE (oi.c3 IS NULL OR oi.c3 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
	UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '入学年份不能为空' WHERE (oi.c11 IS NULL OR oi.c11 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '入学季不能为空' WHERE (oi.c12 IS NULL OR oi.c12 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '学习状态不能为空' WHERE (oi.c15 IS NULL OR oi.c15 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;

    IF GROUPTYPE = 201 THEN
		UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '学号不能为空' WHERE (oi.c8 IS NULL OR oi.c8 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
	ELSEIF GROUPTYPE = 203 THEN
		UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '报考科目不能为空' WHERE (oi.c8 IS NULL OR oi.c8 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
		UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '没有对应的报考科目和学习层次'
		WHERE NOT EXISTS (SELECT 1 FROM pre_teachingplan p INNER JOIN major_level ml ON p.level_id = ml.id WHERE p.name = oi.c8 AND ml.level_name = oi.c2) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    END IF;
    
    UPDATE operate_group og SET og.check_process = 10 WHERE og.id = in_operate_group_id;


	UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '专业不存在' 
	WHERE oi.c1 NOT IN (SELECT m.name FROM major m) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
		
	UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '学习层次不存在' 
	WHERE oi.c2 NOT IN (SELECT m.level FROM major m) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    UPDATE operate_group og SET og.check_process = 20 WHERE og.id = in_operate_group_id;
    
    UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '没有对应的专业和学习层次'
    WHERE NOT EXISTS (SELECT 1 FROM major m WHERE m.name = oi.c1 AND m.level = oi.c2) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '入学年份格式不正确，合法列子：2016' 
    WHERE oi.c11 NOT REGEXP '^[1-9]{1}[0-9]{3}$' AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '入学季必须是1或者2，其中，1代表第一学期，2代表第二学期' 
    WHERE oi.c12 NOT REGEXP '^[1|2]$' AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    UPDATE operate_group og SET og.check_process = 30 WHERE og.id = in_operate_group_id;
    
	IF in_center_id IS NULL THEN 
		UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '学习中心不存在' 
		WHERE oi.c3 NOT IN (SELECT c.name FROM center c) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    ELSE 
		UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '只能添加本中心学生' 
		WHERE oi.c3 != (SELECT c.name FROM center c WHERE c.id = in_center_id) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    END IF;
	
	IF GROUPTYPE = 201 THEN
		UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '学习状态必须是在读，录取，保留学籍，休学，退学，取消学籍，肄业，毕业中的一种' 
		WHERE oi.c15 NOT IN (SELECT ss.name FROM study_status ss) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    ELSEIF GROUPTYPE = 203 THEN
		UPDATE operate_item oi SET oi.status = INVALID, oi.`comment` = '报考科目不存在' 
		WHERE oi.c8 NOT IN (SELECT p.name FROM pre_teachingplan p) AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
	END IF;
    
    UPDATE operate_group og SET og.check_process = 40 WHERE og.id = in_operate_group_id;
    
    
    IF GROUPTYPE = 201 THEN
		UPDATE operate_item oi 
		SET oi.status = INVALID, oi.`comment` = '学号与前面的数据重复'
		WHERE oi.group_id = in_operate_group_id 
		AND oi.c8 != '' AND oi.status != INVALID
		AND EXISTS (SELECT 1 from (SELECT c0,c8 FROM operate_item WHERE group_id = in_operate_group_id GROUP BY c8 HAVING count(c8)>1) AS oi2
		WHERE oi2.c8 = oi.c8 AND oi2.c0 != oi.c0);
	END IF;
    
    UPDATE operate_group og SET og.check_process = 50 WHERE og.id = in_operate_group_id;
    
	UPDATE operate_item oi 
    SET oi.status = INVALID, oi.`comment` = '考生号与前面的数据重复'
    WHERE oi.group_id = in_operate_group_id 
    AND oi.c9 != '' AND oi.status != INVALID
    AND EXISTS (SELECT 1 from (SELECT c0,c9 FROM operate_item WHERE group_id = in_operate_group_id GROUP BY c9 HAVING count(c9)>1) AS oi2
    WHERE oi2.c9 = oi.c9 AND oi2.c0 != oi.c0);
    
    
    
    UPDATE operate_group og SET og.check_process = 60 WHERE og.id = in_operate_group_id;
    
    IF GROUPTYPE = 201 THEN
		UPDATE operate_item oi 
		INNER JOIN student s 
		SET oi.status = INVALID, oi.`comment` = '学号已存在' 
		WHERE oi.c8 IS NOT NULL AND oi.c8 != '' AND oi.c8 = s.student_number AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
	END IF;
    
    UPDATE operate_group og SET og.check_process = 80 WHERE og.id = in_operate_group_id;
    
	UPDATE operate_item oi 
	INNER JOIN student s 
    SET oi.status = INVALID, oi.`comment` = '考生号已存在' 
    WHERE oi.c9 IS NOT NULL AND oi.c9 != '' AND oi.c9 = s.candidate_number AND oi.status = WAITING AND oi.group_id = in_operate_group_id;

	
	UPDATE operate_item SET status=VALID,comment='有效数据' WHERE status = WAITING AND group_id = in_operate_group_id;
	UPDATE operate_group og SET og.status=
	CASE WHEN EXISTS (SELECT oi.id FROM operate_item oi WHERE oi.group_id=in_operate_group_id AND oi.status = INVALID)
	THEN INVALID ELSE VALID END , og.check_process=100
	WHERE og.id=in_operate_group_id;

END;

