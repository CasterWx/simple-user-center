create
    definer = devuser@`%` procedure feedback_tag_get_all()
BEGIN
	select * from feedback_tag_type;
END;

