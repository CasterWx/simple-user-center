create
    definer = devuser@`%` procedure operateitem_batch_insert(IN in_operateItemList mediumtext)
BEGIN

	DECLARE i INT  DEFAULT 1;
    DECLARE COUNT INT(11);
    SET COUNT = ExtractValue(in_operateItemList, 'count(//GOI)');
    WHILE i <= COUNT DO
    INSERT INTO operate_item (group_id, status, result,comment,c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19) VALUES
    (XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/GID')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/ST')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/RT')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/CT')),
	XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C0')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C1')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C2')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C3')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C4')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C5')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C6')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C7')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C8')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C9')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C10')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C11')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C12')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C13')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C14')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C15')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C16')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C17')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C18')),
    XMLDECODE(ExtractValue(in_operateItemList, 'GOIS/GOI[$i]/C19'))
    );
    
	SET i = i+1;
    END WHILE;
    

END;

