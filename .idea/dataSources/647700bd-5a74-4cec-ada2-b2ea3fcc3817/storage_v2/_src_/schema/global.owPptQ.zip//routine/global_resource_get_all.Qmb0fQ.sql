create
    definer = devuser@`%` procedure global_resource_get_all(IN in_type int)
BEGIN
 	if in_type = 1 then
 		select id, res_id from res_course;
 	end if;
 	if in_type = 2 then
 		select id, res_id from res_courseware;
 	end if;
 	if in_type = 3 then
 		select id, res_id from res_book;
 	end if;
END;

