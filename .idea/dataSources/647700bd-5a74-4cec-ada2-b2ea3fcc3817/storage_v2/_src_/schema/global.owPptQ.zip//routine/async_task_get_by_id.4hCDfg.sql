create
    definer = devuser@`%` procedure async_task_get_by_id(IN in_id int)
BEGIN
	SELECT * FROM async_task WHERE id=in_id;
END;

