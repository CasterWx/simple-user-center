create
    definer = devuser@`%` procedure school_business_scope_delete(IN in_id int)
BEGIN
	
	DELETE FROM school_business_scope WHERE id=in_id;
END;

