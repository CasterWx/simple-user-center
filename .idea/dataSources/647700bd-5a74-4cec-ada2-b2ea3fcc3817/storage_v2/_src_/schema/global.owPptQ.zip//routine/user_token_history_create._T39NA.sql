create
    definer = devuser@`%` procedure user_token_history_create(IN in_user_id int, IN in_token varchar(1000),
                                                              IN in_type int, IN in_ip varchar(1000),
                                                              IN in_user_agent varchar(1000))
BEGIN
	
    INSERT INTO user_token_history (`user_id`, `token`, `type`, `ip`, `user_agent`)
    VALUES(in_user_id, in_token, in_type, in_ip, in_user_agent);
END;

