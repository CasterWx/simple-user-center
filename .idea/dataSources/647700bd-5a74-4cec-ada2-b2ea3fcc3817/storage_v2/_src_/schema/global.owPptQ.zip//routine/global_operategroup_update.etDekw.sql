create
    definer = devuser@`%` procedure global_operategroup_update(IN in_id int, IN in_name varchar(255), IN in_type int,
                                                               IN in_status int, IN in_result varchar(255),
                                                               IN in_reserved_value varchar(255), IN in_operator int)
BEGIN

	UPDATE operate_group SET name=in_name,type=in_type,status=in_status,result=in_result,operator=in_operator,reserved_value=in_reserved_value WHERE id=in_id;

END;

