create
    definer = devuser@`%` procedure school_setting_get_all()
BEGIN
	SELECT * FROM school_setting;
END;

