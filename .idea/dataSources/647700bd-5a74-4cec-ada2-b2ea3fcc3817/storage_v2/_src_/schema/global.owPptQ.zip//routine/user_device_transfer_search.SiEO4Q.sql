create
    definer = devuser@`%` procedure user_device_transfer_search(IN in_offset int, IN in_limit int, OUT out_total_count int)
BEGIN
	
	select sql_calc_found_rows * from user_device
	limit in_offset, in_limit;

	set out_total_count = found_rows();
	
END;

