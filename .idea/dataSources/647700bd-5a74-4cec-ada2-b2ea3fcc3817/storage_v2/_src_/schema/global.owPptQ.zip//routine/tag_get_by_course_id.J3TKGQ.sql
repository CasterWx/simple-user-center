create
    definer = devuser@`%` procedure tag_get_by_course_id(IN in_res_course_id varchar(100))
BEGIN

    SELECT DISTINCT t.* 
    FROM plus_quiz q 
      INNER JOIN quiz_tag qt ON q.id = qt.quiz_id
      INNER JOIN res_tag t ON t.id = qt.tag_id
    WHERE q.status = 100 AND q.res_course_id = in_res_course_id;

END;

