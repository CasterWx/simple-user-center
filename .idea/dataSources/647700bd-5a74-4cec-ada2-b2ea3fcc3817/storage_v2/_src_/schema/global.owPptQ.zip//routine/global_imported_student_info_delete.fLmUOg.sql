create
    definer = devuser@`%` procedure global_imported_student_info_delete(IN in_id int, IN in_school_id int)
BEGIN

	SET SQL_SAFE_UPDATES=0;
	
	DELETE us, gu FROM user_school us 
	INNER JOIN global_user gu ON us.user_id = gu.id
	INNER JOIN operate_item oi ON gu.user_name = oi.c4
	WHERE us.school_id = in_school_id AND oi.group_id = in_id;

END;

