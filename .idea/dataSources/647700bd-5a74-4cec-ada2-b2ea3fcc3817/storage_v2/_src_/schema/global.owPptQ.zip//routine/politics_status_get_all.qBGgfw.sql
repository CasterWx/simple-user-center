create
    definer = devuser@`%` procedure politics_status_get_all()
BEGIN

	SELECT * FROM politics_status;

END;

