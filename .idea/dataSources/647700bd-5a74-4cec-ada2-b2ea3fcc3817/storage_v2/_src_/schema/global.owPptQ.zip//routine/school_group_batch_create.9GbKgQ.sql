create
    definer = devuser@`%` procedure school_group_batch_create(IN in_group_id int, IN in_member_ids text)
BEGIN
	  DECLARE member_id_token VARCHAR(20);

	  SET SQL_SAFE_UPDATES=0;

    WHILE LENGTH(in_member_ids) >0 DO

        SET member_id_token = SUBSTRING_INDEX(in_member_ids, ',', 1);

        SET in_member_ids = SUBSTRING(in_member_ids, LENGTH(member_id_token) +2);

        INSERT INTO `school_group_create`(group_id, member_id)
        VALUES(in_group_id, CAST(member_id_token AS SIGNED));

    END WHILE;
END;

