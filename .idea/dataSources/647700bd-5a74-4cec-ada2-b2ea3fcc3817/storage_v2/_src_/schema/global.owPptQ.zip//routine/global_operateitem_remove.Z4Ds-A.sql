create
    definer = devuser@`%` procedure global_operateitem_remove(IN in_id int)
BEGIN

	DELETE FROM operate_item WHERE id=in_id;

END;

