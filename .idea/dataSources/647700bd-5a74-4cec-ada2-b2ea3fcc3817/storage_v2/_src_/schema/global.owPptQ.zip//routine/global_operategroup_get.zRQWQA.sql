create
    definer = devuser@`%` procedure global_operategroup_get(IN in_id int)
BEGIN

	SELECT * FROM operate_group WHERE id=in_id;

END;

