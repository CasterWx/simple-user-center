create
    definer = devuser@`%` procedure global_check_imported_teacher(IN in_group_id int, IN in_repeated int)
BEGIN
	
	DECLARE local_waiting INT DEFAULT 1;
    DECLARE local_valid INT DEFAULT 2;
    DECLARE local_invalid INT DEFAULT 3;
    DECLARE local_complete INT DEFAULT 4;
    DECLARE local_cancel INT DEFAULT 5;
    DECLARE local_checking INT DEFAULT 6;
    
    
    UPDATE operate_group SET status=local_checking WHERE id = in_group_id;
    
    
    IF in_repeated = 1 THEN
		UPDATE  operate_item SET status=local_waiting,comment='等待处理',c5=null where group_id = in_group_id;
    END IF;
    
    UPDATE operate_item SET c19=id where group_id=in_group_id;
    
    
    UPDATE  operate_item SET status=local_invalid,comment= '用户名不能为空' WHERE group_id = in_group_id AND (c1 is null or c1 ="");
	
    
    UPDATE  operate_item SET status=local_invalid,comment= '密码不能为空' WHERE status=local_waiting AND group_id = in_group_id AND (c2 is null or c2 ="");
	
    
    UPDATE  operate_item SET status=local_invalid,comment= '姓名不能为空' WHERE status=local_waiting AND group_id = in_group_id AND (c3 is null or c3 ="");
	
    
    UPDATE  operate_item oi1 , operate_item oi2 SET oi1.status=3,oi1.comment='该行教师用户名在前面的行中已出现'
    WHERE oi1.id>oi2.id AND oi1.group_id=in_group_id AND oi2.group_id=in_group_id AND oi1.status=local_waiting AND oi2.status=local_waiting
    AND oi1.c1=oi2.c1;
    
    
	UPDATE  operate_item oi INNER JOIN global_user gu ON oi.c1=gu.user_name AND oi.group_id=in_group_id AND oi.status=local_waiting
	INNER JOIN user_school us ON us.user_id=gu.id
    SET oi.c5 = gu.id;
    
    UPDATE operate_item SET status=local_invalid,comment= '用户名已存在' 
    WHERE (c5 !='' OR c5 IS NOT NULL)  AND group_id=in_group_id AND status=local_waiting;

    
    UPDATE operate_item SET status=local_valid,comment= '有效数据' 
    WHERE status=local_waiting AND group_id=in_group_id;
    
  	UPDATE operate_group SET status=
 	CASE WHEN EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=local_waiting)
	 THEN local_valid else local_invalid END
 	WHERE id=in_group_id;

END;

