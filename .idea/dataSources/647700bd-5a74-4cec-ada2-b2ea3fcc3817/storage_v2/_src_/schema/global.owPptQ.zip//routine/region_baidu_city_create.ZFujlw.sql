create
    definer = devuser@`%` procedure region_baidu_city_create(IN in_baidu_city_id int, IN in_region_id int, OUT out_id int)
BEGIN
    INSERT INTO `region_baidu_city`
    (`region_id`,  `baidu_city_id`)
    VALUES
    (in_region_id,  in_baidu_city_id);    
    SET out_id = LAST_INSERT_ID();
END;

