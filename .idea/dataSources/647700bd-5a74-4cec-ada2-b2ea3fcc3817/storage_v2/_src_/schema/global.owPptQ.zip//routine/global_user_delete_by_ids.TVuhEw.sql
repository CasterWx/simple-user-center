create
    definer = devuser@`%` procedure global_user_delete_by_ids(IN in_ids mediumtext)
BEGIN
	set @sql = concat("DELETE FROM global_user WHERE id in (", in_ids,")");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END;

