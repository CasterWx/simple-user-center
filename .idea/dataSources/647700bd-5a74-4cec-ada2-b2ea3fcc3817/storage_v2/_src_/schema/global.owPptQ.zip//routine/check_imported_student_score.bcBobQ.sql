create
    definer = devuser@`%` procedure check_imported_student_score(IN in_group_id int, IN in_center_id int)
BEGIN
	
	DECLARE waiting INT DEFAULT 1;
    DECLARE valid INT DEFAULT 2;
    DECLARE invalid INT DEFAULT 3;
    DECLARE complete INT DEFAULT 4;
    DECLARE cancel INT DEFAULT 5;
    DECLARE checking INT DEFAULT 6;
    
    SET SQL_SAFE_UPDATES = 0;
    
    
    UPDATE operate_group SET status=checking WHERE id = in_group_id;
    
    
    UPDATE  operate_item SET status=invalid,comment= '课程名称不能为空' WHERE (c5 IS NULL OR c5 ="") AND status=waiting AND group_id=in_group_id;
    UPDATE  operate_item SET status=invalid,comment= '学期不能为空' WHERE (c6 IS NULL OR c6 ="") AND status=waiting AND group_id=in_group_id;
    UPDATE  operate_item SET status=invalid,comment= '期末成绩不能同时为空' WHERE (c7 IS NULL OR c7 ="") AND status=waiting AND group_id=in_group_id;
    
    
    UPDATE  operate_item SET status=invalid,comment= '学期必须是正整数' WHERE c6 NOT REGEXP '^-?[0-9]+$' AND status=waiting AND group_id=in_group_id;
    UPDATE  operate_item SET status=invalid,comment= '期末成绩必须是正数' WHERE c7 IS NOT NULL AND c7 != "" AND c7 NOT REGEXP '^[0-9]+\\.?[0-9]*$' AND status=waiting AND group_id=in_group_id;


    UPDATE  operate_item oi1 , operate_item oi2 SET oi1.status=invalid,oi1.comment='此行数据与前面的数据重复' 
    WHERE oi1.id>oi2.id AND oi1.group_id=in_group_id AND oi2.group_id=in_group_id AND oi1.status=waiting AND oi2.status=waiting
    AND oi1.c2=oi2.c2 AND oi1.c5=oi2.c5 AND oi1.c6=oi2.c6;
    
    
	
    UPDATE operate_item  oi 
    INNER JOIN student s ON oi.status=waiting 
    AND CONVERT(oi.c9,UNSIGNED)=s.global_user_id AND group_id=in_group_id
    LEFT JOIN teachingplan tp ON s.major_id=tp.major_id AND s.semester_id=tp.semester_id
    SET oi.c10 = s.id,oi.c11= s.student_number,oi.c12=s.center_id,oi.c13=tp.id,oi.c14=tp.semester_id;
    
    
    UPDATE operate_item  SET status=invalid,comment= '本校没有该学生' 
    WHERE status=waiting AND group_id=in_group_id AND (c10 IS NULL or c10 = '');
    
	
    UPDATE operate_item  SET status=invalid,comment= '登录名与学号不是同一个学生' 
    WHERE status=waiting AND c4 IS NOT NULL AND c4 != '' AND c4 != c11  AND group_id=in_group_id;
    
    
    UPDATE operate_item  SET status=invalid,comment= '该学生没有教学计划信息' 
    WHERE status=waiting AND (c13 IS NULL or c13 =0)  AND group_id=in_group_id;
    
    
    IF in_center_id !=0 THEN
    UPDATE operate_item  oi SET oi.status=invalid,comment= '该学生不属于本学习中心' 
    WHERE oi.status=waiting  AND in_center_id != oi.c12  AND oi.group_id=in_group_id;
    END IF;
    
    
    
    UPDATE operate_item oi INNER JOIN course c ON oi.status=waiting AND oi.group_id=in_group_id
    AND oi.c5 = c.name SET oi.c15=c.id;
    
    
	UPDATE operate_item  oi SET oi.status=invalid,comment= '该课程不是当前操作课程' 
    WHERE oi.status=waiting AND group_id=in_group_id AND oi.c1 !=0 AND oi.c1 !=c15;
    
    
    UPDATE operate_item oi INNER JOIN teachingplan_course tc ON oi.status=waiting  AND oi.group_id=in_group_id
    AND oi.c13 IS NOT NULL AND oi.c13 !='' AND CONVERT(oi.c13,UNSIGNED) = tc.teachingplan_id AND oi.c15=tc.course_id 
    AND oi.c6=tc.term
    SET oi.c16=tc.id;
    
    UPDATE operate_item SET status=invalid,comment='课程和学期组合不符合教学计划' 
    WHERE status=waiting AND group_id = in_group_id AND (c16 IS NULL or c16 =0);
    
    
    UPDATE operate_item oi
    LEFT JOIN student_course sc ON CONVERT(oi.c16,UNSIGNED) = sc.teachingplan_course_id AND CONVERT(oi.c10,UNSIGNED) = sc.student_id
    SET oi.status=invalid, comment= '该生没有选修此课程' 
    WHERE status=waiting AND group_id = in_group_id AND sc.id IS NULL;
    
    UPDATE operate_item oi
    INNER JOIN student_course sc ON CONVERT(oi.c16,UNSIGNED) = sc.teachingplan_course_id AND CONVERT(oi.c10,UNSIGNED) = sc.student_id
	INNER JOIN student_exam_score ses ON CONVERT(oi.c16,UNSIGNED) = ses.teachingplan_course_id AND CONVERT(oi.c10,UNSIGNED) = ses.student_id
	SET oi.status=invalid, comment= '该生已有期末成绩，不能重复录入' 
    WHERE oi.status=waiting AND group_id=in_group_id AND sc.flag != 2;
    
    
    UPDATE operate_item SET status=valid,comment='有效数据' WHERE status=waiting AND group_id = in_group_id;
	UPDATE operate_group SET status=
	CASE WHEN EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=valid)
 	 THEN valid ELSE invalid END 
     WHERE id=in_group_id;
   
END;

