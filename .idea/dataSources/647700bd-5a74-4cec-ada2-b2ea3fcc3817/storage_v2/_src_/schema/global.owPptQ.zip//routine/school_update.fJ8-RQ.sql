create
    definer = devuser@`%` procedure school_update(IN in_id int, IN in_name varchar(300), IN in_phone varchar(45),
                                                  IN in_email varchar(100), IN in_alipay_email varchar(100),
                                                  IN in_address varchar(500), IN in_introduction text,
                                                  IN in_logo_url varchar(300), IN in_status int, IN in_is_group int(1),
                                                  IN in_updater_id int, IN in_introduction_detail mediumtext,
                                                  IN in_banner_image_ids varchar(500))
BEGIN

UPDATE school
SET `name` = in_name,
	phone = in_phone,
    email = in_email,
    alipay_email = in_alipay_email,
    address = in_address,
    introduction = in_introduction,
	  logo_url = in_logo_url,
    `status` = in_status,
    is_group = in_is_group,
    updater_id = in_updater_id,
    introduction_detail = in_introduction_detail,
    banner_image_ids = in_banner_image_ids,
    update_time = NOW()

WHERE id = in_id;

END;

