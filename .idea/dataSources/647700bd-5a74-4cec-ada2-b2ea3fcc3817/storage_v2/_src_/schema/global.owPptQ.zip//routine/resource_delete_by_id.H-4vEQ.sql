create
    definer = devuser@`%` procedure resource_delete_by_id(IN in_id int)
BEGIN

	DELETE FROM `resource` WHERE id = in_id;

END;

