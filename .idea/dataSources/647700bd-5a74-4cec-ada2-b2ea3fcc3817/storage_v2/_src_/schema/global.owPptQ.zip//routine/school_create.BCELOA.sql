create
    definer = devuser@`%` procedure school_create(IN in_name varchar(300), IN in_symbol varchar(45),
                                                  IN in_category_id int, IN in_phone varchar(45),
                                                  IN in_email varchar(100), IN in_alipay_email varchar(100),
                                                  IN in_address varchar(500), IN in_introduction text,
                                                  IN in_logo_url varchar(300), IN in_certi_info_url varchar(300),
                                                  IN in_appler_id int, IN in_introduction_detail text,
                                                  IN in_banner_image_ids varchar(500), IN in_status int,
                                                  IN in_is_group int(1), OUT out_id int)
BEGIN

    INSERT INTO school (name, symbol, category_id, phone, email, alipay_email, address, introduction, logo_url, certi_info_url, appler_id, introduction_detail, banner_image_ids,`status`, is_group)
    VALUES (in_name, in_symbol, in_category_id, in_phone, in_email, in_alipay_email, in_address, in_introduction, in_logo_url, in_certi_info_url, in_appler_id, in_introduction_detail, in_banner_image_ids,in_status,in_is_group);

    SET out_id = LAST_INSERT_ID();

END;

