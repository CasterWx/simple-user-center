create
    definer = devuser@`%` procedure major_free_video_update(IN in_id int, IN in_major_id int,
                                                            IN in_video_title varchar(200),
                                                            IN in_video_introduction varchar(500),
                                                            IN in_video_url varchar(500))
BEGIN
    UPDATE major_free_video
    SET major_id = in_major_id,video_title = in_video_title
    ,video_introduction = in_video_introduction
    ,video_url = in_video_url
    WHERE id = in_id;
    
END;

