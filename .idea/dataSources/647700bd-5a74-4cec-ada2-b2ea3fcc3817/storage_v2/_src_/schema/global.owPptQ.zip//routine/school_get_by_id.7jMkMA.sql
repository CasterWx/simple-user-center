create
    definer = devuser@`%` procedure school_get_by_id(IN in_id int)
BEGIN
    SELECT s.*, sc.type as schoolCategoryType 
    FROM school s 
        INNER JOIN school_category sc ON sc.id = s.category_id
    WHERE s.id = in_id;
END;

