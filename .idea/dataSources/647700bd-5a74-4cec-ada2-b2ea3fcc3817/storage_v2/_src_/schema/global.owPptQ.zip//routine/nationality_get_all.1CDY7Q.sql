create
    definer = devuser@`%` procedure nationality_get_all()
BEGIN

	SELECT * FROM nationality;

END;

