create
    definer = devuser@`%` procedure user_resource_get_by_id(IN in_id int)
BEGIN

	SELECT * FROM user_resource WHERE id = in_id;

END;

