create
    definer = devuser@`%` procedure user_school_batch_remove(IN in_user_ids mediumtext, IN in_school_id int, IN in_user_role int)
BEGIN	
	set @sql = concat("DELETE FROM user_school WHERE user_id in (", in_user_ids,") and school_id = ",in_school_id," and user_role = ",in_user_role);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END;

