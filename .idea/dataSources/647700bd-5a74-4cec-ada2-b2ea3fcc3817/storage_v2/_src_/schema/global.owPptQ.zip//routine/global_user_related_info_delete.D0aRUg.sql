create
    definer = devuser@`%` procedure global_user_related_info_delete(IN in_global_user_id int)
BEGIN
    DELETE FROM user_author WHERE user_id = in_global_user_id;
    DELETE FROM user_device WHERE user_id = in_global_user_id;
	DELETE FROM user_resource WHERE user_id = in_global_user_id;
    DELETE FROM user_school WHERE user_id = in_global_user_id;
    DELETE FROM user_token_history WHERE user_id = in_global_user_id;
END;

