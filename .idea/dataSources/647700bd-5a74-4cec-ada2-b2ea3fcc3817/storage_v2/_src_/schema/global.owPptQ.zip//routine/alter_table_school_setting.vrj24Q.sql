create
    definer = devuser@`%` procedure alter_table_school_setting()
BEGIN
	IF EXISTS( SELECT NULL FROM INFORMATION_SCHEMA.COLUMNS  WHERE TABLE_NAME = 'school_setting'
             AND table_schema = 'global'
             AND COLUMN_NAME = 'is_ebook_need_paid')   
	THEN
		
        SET SQL_SAFE_UPDATES = 0;
        
        CREATE TEMPORARY TABLE temp_table SELECT * FROM school_setting;

		
		ALTER TABLE school_setting
        DROP COLUMN is_ebook_need_paid,
        DROP COLUMN is_register_open,
        DROP COLUMN pay_type,
		ADD	 COLUMN setting_value INT NOT NULL DEFAULT 0 AFTER school_id,
		ADD	 COLUMN setting_type  INT NOT NULL DEFAULT 0 AFTER school_id;
       
        
        DELETE FROM school_setting;
		
        
        INSERT INTO school_setting(school_id,setting_value,setting_type)
        SELECT school_id,is_ebook_need_paid,1 FROM temp_table;
        
        INSERT INTO school_setting(school_id,setting_value,setting_type)
        SELECT school_id,is_register_open,2 FROM temp_table;
        
        INSERT INTO school_setting(school_id,setting_value,setting_type)
        SELECT school_id,pay_type,3 FROM temp_table;
        
        INSERT INTO school_setting(school_id,setting_value,setting_type)
        SELECT school_id,1,4 FROM temp_table;
        
        drop table temp_table;
        SET SQL_SAFE_UPDATES = 1;
    END IF;

END;

