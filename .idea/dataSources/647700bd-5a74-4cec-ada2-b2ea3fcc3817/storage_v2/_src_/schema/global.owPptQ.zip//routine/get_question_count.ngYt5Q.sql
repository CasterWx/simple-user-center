create
    definer = devuser@`%` procedure get_question_count(IN in_course_id int, OUT out_single_select_count int,
                                                       OUT out_multiple_select_count int, OUT out_essay_count int,
                                                       OUT out_composite_count int, OUT out_completion_count int)
BEGIN
    
	SELECT COUNT(0) INTO out_single_select_count FROM question WHERE course_id = in_course_id AND question_type = 1 AND (parent_id = 0 OR parent_id IS NULL);
	SELECT COUNT(0) INTO out_multiple_select_count FROM question WHERE course_id = in_course_id AND question_type = 2 AND (parent_id = 0 OR parent_id IS NULL);
	SELECT COUNT(0) INTO out_essay_count FROM question WHERE course_id = in_course_id AND question_type = 3 AND (parent_id = 0 or parent_id OR NULL);
	SELECT COUNT(0) INTO out_composite_count FROM question WHERE course_id = in_course_id AND question_type = 4 AND (parent_id = 0 OR parent_id IS NULL);
	SELECT COUNT(0) INTO out_completion_count FROM question WHERE course_id = in_course_id AND question_type = 5 AND (parent_id = 0 OR parent_id IS NULL);
    
END;

