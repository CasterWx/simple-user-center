create
    definer = devuser@`%` procedure operategroup_create(IN in_name varchar(255), IN in_type int, IN in_status int,
                                                        IN in_result varchar(255), IN in_operator int,
                                                        IN in_reserved_value varchar(255), OUT out_id int)
BEGIN

	INSERT INTO operate_group(name,type,status,result,operator,reserved_value)

	VALUES(in_name,in_type,in_status,in_result,in_operator,in_reserved_value);

	SET out_id = LAST_INSERT_ID();

END;

