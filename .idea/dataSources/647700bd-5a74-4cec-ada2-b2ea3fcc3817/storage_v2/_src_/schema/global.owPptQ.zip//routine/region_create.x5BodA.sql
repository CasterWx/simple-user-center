create
    definer = devuser@`%` procedure region_create(IN in_code varchar(10), IN in_is_city tinyint(1), IN in_level int,
                                                  IN in_name varchar(100), IN in_parent_id int, OUT out_id int)
BEGIN

    INSERT INTO `region`
    (`code`, `name`, `parent_id`, `level`, `short_name`, `is_city`) 
    VALUES
    (in_code,  in_name,  in_parent_id,  in_level, pinyin(in_name),in_is_city);   
    SET out_id = LAST_INSERT_ID();
    
END;

