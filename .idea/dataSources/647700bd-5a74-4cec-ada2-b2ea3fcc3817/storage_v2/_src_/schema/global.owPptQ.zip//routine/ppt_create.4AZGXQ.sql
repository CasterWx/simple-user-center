create
    definer = devuser@`%` procedure ppt_create(IN in_resource_id int, IN in_ppt_task_id int,
                                               IN in_transform_file_url varchar(255), OUT out_id int)
BEGIN

	INSERT INTO ppt(resource_id, ppt_task_id, transform_file_url)
	VALUES (in_resource_id, in_ppt_task_id, in_transform_file_url);

	SET out_id = last_insert_id();
END;

