create
    definer = devuser@`%` procedure user_resource_update_status(IN in_resource_ids varchar(500), IN in_resource_status int)
BEGIN
	DECLARE sql_str VARCHAR(5000) ;
	
	SET sql_str = CONCAT('UPDATE user_resource SET status =',in_resource_status, ' WHERE id in ( ',in_resource_ids,') OR parent_id IN ( ',in_resource_ids,'); ') ;

	SET @ms = sql_str ;
	PREPARE s1 FROM @ms ;
	EXECUTE s1 ;
	DEALLOCATE PREPARE s1 ;
	
END;

