create
    definer = devuser@`%` procedure forbid_student_batch(IN in_group_id int)
BEGIN       
	
     
	
    UPDATE operate_item oi INNER JOIN fee f ON oi.group_id=in_group_id AND oi.status=2 AND f.type=4 
    INNER JOIN  payment p ON p.fee_id=f.id AND p.student_id=oi.c1
    SET oi.status=4 , p.paid=0;
    
    
	IF NOT EXISTS (SELECT id FROM fee f WHERE f.type=4) THEN
	INSERT INTO fee(title,price,type,student_id) VALUES("书本费",0.01,4,0);
	END IF;
    
	
    UPDATE operate_group SET status=4 WHERE id= in_group_id;
    
END;

