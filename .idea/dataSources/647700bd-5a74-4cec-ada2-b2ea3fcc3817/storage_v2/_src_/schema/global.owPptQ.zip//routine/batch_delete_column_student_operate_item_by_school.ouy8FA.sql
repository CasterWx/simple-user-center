create
    definer = devuser@`%` procedure batch_delete_column_student_operate_item_by_school(IN in_operate_group_id int, IN in_column int, IN in_item_ids mediumtext)
BEGIN
	
    DECLARE id_token VARCHAR(10);
    
	DROP TEMPORARY TABLE IF EXISTS `item_ids`;
    CREATE TEMPORARY TABLE `item_ids`(
		id INT(11) PRIMARY KEY
    );
	
	WHILE LENGTH(in_item_ids) >0 DO
        SET id_token = SUBSTRING_INDEX(in_item_ids, '|', 1);
        SET in_item_ids = SUBSTRING(in_item_ids,LENGTH(id_token) +2);
        INSERT item_ids(id) VALUES (CAST(id_token AS SIGNED));

    END WHILE;
    
    
	SET SQL_SAFE_UPDATES = 0;

	CASE
    
     WHEN in_column = 14 THEN
		UPDATE operate_item SET c14 = NULL WHERE group_id = in_operate_group_id AND c0 in (select id from item_ids);
	WHEN in_column = 3 THEN
		UPDATE operate_item SET c3 = NULL WHERE group_id = in_operate_group_id AND c0 in (select id from item_ids);
	WHEN in_column = 9 THEN
		UPDATE operate_item SET c9 = NULL WHERE group_id = in_operate_group_id AND c0 in (select id from item_ids);
	WHEN in_column = 10 THEN
		UPDATE operate_item SET c10 = NULL WHERE group_id = in_operate_group_id AND c0 in (select id from item_ids);
    
    END CASE;
    
    DROP TEMPORARY TABLE IF EXISTS `item_ids`;
END;

