create
    definer = devuser@`%` procedure video_update(IN in_id int, IN in_resource_id int, IN in_persistent_id varchar(255),
                                                 IN in_source_url varchar(255), IN in_target_url varchar(255))
BEGIN

	UPDATE `video` SET 
		`resource_id` = in_resource_id,
		`persistent_id` = in_persistent_id,
		`source_url` = in_source_url,
		`target_url` = in_target_url
	WHERE id = in_id;

END;

