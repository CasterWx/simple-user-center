create
    definer = devuser@`%` procedure user_device_delete(IN in_user_id int, IN in_device_token varchar(100))
BEGIN
    DELETE FROM  user_device where user_id = in_user_id
    AND device_token = in_device_token;

END;

