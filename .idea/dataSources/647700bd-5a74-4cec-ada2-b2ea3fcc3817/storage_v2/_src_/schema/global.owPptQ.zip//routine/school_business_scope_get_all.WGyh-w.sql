create
    definer = devuser@`%` procedure school_business_scope_get_all()
BEGIN
	
	SELECT * FROM school_business_scope;
END;

