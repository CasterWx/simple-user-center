create
    definer = devuser@`%` procedure global_user_batch_insert(IN in_fields varchar(500), IN in_parameter mediumtext,
                                                             IN in_userName_list mediumtext, IN in_school_id int)
BEGIN
  DROP TEMPORARY TABLE IF EXISTS temp_ids;
	CREATE TEMPORARY TABLE temp_ids(
		user_id INT(11),
		school_id INT(11),
		user_role INT(11) DEFAULT 1
	);
	

	SET @sql = CONCAT('INSERT INTO global_user', in_fields, ' VALUES ', in_parameter, ';');
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @sql = CONCAT('INSERT INTO temp_ids(user_id, school_id) SELECT id as user_id,',in_school_id ,' FROM  global_user WHERE user_name in (', in_userName_list, ');');
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @sql = CONCAT('INSERT INTO user_school(user_id, school_id, user_role) SELECT  * from temp_ids;');
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @sql = CONCAT('SELECT * FROM global_user WHERE user_name in (', in_userName_list, ');');
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END;

