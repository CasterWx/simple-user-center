create
    definer = devuser@`%` procedure check_imported_student_number(IN in_group_id int)
BEGIN
	UPDATE operate_item oi1 , operate_item oi2 SET oi1.status = 3,oi1.result = '重复学生'
    WHERE oi1.id > oi2.id AND oi1.c0=oi2.c0 AND oi1.group_id=in_group_id AND oi2.group_id=in_group_id AND (oi1.status = 1 OR oi1.status = 2);
	
	UPDATE  operate_item oi INNER JOIN student s ON oi.c0=s.student_number AND oi.group_id=in_group_id AND oi.status= 1 SET status=2,c1=s.id,c2=s.global_user_id;
  
  	UPDATE operate_item SET status=3,result = '学生不存在' WHERE group_id=in_group_id AND status= 1;
  	
  	UPDATE operate_group SET status=
 	case when EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=2)
	 THEN 2 else 3 END
 	WHERE id=in_group_id;
   
END;

