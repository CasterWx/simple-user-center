create
    definer = devuser@`%` procedure global_user_create(IN in_user_name varchar(64), IN in_password varchar(64),
                                                       IN in_display_name varchar(64), IN in_gender varchar(20),
                                                       IN in_phone_num varchar(20), IN in_identity_card varchar(18),
                                                       IN in_address varchar(512), IN in_photo_image_url varchar(500),
                                                       IN in_email varchar(100), IN in_user_type int,
                                                       IN in_phone_valid bit, OUT out_id int)
BEGIN

	INSERT INTO global_user(user_name,password,display_name,gender,phone_num,identity_card,address,photo_image_url,email,user_type,phone_valid)

	VALUES(in_user_name,in_password,in_display_name,in_gender,in_phone_num,in_identity_card,in_address,in_photo_image_url,in_email,in_user_type, IF (in_phone_valid IS NULL, 0, in_phone_valid));

	SET out_id = LAST_INSERT_ID();

END;

