create
    definer = devuser@`%` procedure global_user_get_by_id(IN in_id int)
BEGIN
SELECT 
    * From global_user
    WHERE id = in_id;

END;

