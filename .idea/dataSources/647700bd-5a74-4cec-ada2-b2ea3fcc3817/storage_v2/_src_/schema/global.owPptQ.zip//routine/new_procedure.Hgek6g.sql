create
    definer = devuser@`%` procedure new_procedure(IN in_teachplan_id int, IN in_student_number varchar(50),
                                                  IN in_study_status int, IN in_center_id int,
                                                  IN in_teachplan_course_id int, IN in_offset int, IN in_count int,
                                                  OUT out_total_count int)
BEGIN

	SELECT SQL_CALC_FOUND_ROWS * FROM (
		SELECT s.*  FROM student AS s 
		INNER JOIN teachingplan AS tp ON s.major_id = tp.major_id AND s.semester_id = tp.semester_id 
		LEFT JOIN student_course AS sc ON s.id = sc.student_id AND sc.teachingplan_course_id = in_teachplan_course_id
		WHERE tp.id = in_teachplan_id 
        AND (in_student_number IS NULL OR s.student_number = in_student_number)
        AND (in_study_status IS NULL OR s.study_status_id = in_study_status)
		AND (in_center_id IS NULL OR s.center_id = in_center_id)
		
		UNION
		
		SELECT s.* FROM student AS s 
		INNER JOIN teachingplan AS tp ON s.major_id = tp.major_id AND s.semester_id = tp.semester_id 
		RIGHT JOIN student_course AS sc ON s.id = sc.student_id AND sc.teachingplan_course_id = in_teachplan_course_id
		WHERE tp.id = in_teachplan_id
         AND (in_student_number IS NULL OR s.student_number = in_student_number)
        AND (in_study_status IS NULL OR s.study_status_id = in_study_status)
		AND (in_center_id IS NULL OR s.center_id = in_center_id)
    )t
    
    LIMIT in_offset, in_count;
    
	set out_total_count = FOUND_ROWS();
END;

