create
    definer = devuser@`%` procedure global_user_delete(IN in_global_user_id int)
BEGIN
	DELETE FROM global_user WHERE id = in_global_user_id;
END;

