create
    definer = devuser@`%` procedure school_xueji_card_get_all()
BEGIN
	SELECT * FROM school_xueji_card;
END;

