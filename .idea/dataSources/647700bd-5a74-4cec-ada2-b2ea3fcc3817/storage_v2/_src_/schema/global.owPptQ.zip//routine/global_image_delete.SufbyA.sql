create
    definer = devuser@`%` procedure global_image_delete(IN in_id int)
BEGIN

	DELETE FROM global_image WHERE id = in_id;
END;

