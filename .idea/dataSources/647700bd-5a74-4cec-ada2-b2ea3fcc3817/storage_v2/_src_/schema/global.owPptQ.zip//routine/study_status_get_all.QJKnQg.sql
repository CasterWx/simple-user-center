create
    definer = devuser@`%` procedure study_status_get_all()
BEGIN
	SELECT * FROM study_status;
END;

