create
    definer = devuser@`%` procedure school_group_get_all()
BEGIN
	SELECT `school_group`.`id`,
    `school_group`.`group_id`,
    `school_group`.`member_id`,
    `school_group`.`created_time`,
    `school_group`.`updated_time`
	FROM `school_group`;

END;

