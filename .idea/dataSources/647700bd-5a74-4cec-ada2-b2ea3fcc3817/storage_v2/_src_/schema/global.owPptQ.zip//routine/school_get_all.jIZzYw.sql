create
    definer = devuser@`%` procedure school_get_all()
BEGIN
	SELECT
		s.*, sc.type as schoolCategoryType 
	FROM
		school s, school_category sc 
	WHERE sc.id = s.category_id;
END;

