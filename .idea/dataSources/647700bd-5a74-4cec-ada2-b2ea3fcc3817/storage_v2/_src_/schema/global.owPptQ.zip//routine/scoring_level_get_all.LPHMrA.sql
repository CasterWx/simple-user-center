create
    definer = devuser@`%` procedure scoring_level_get_all()
BEGIN

  SELECT * FROM scoring_level;

END;

