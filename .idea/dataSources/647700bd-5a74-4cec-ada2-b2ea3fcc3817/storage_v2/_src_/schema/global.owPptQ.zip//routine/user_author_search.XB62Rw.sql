create
    definer = devuser@`%` procedure user_author_search(IN in_user_id int, IN in_utype int, IN in_uid varchar(45))
BEGIN
	SELECT * FROM user_author
	WHERE (in_user_id IS NULL OR user_id = in_user_id)
    AND (in_utype IS NULL OR utype = in_utype)
    AND (in_uid IS NULL OR uid = in_uid);
END;

