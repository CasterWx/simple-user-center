create
    definer = devuser@`%` procedure user_school_get_by_user_info(IN in_user_id int, IN in_school_id int, IN in_user_role int)
BEGIN
    SELECT * FROM user_school us
        WHERE us.user_id=in_user_id
	        AND (in_school_id IS NULL OR us.school_id = in_school_id)
			AND (in_user_role IS NULL OR us.user_role = in_user_role);
END;

