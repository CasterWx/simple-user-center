create
    definer = devuser@`%` procedure school_setting_get_by_school(IN in_school_id int)
BEGIN

	SELECT * FROM school_setting WHERE school_id = in_school_id;
END;

