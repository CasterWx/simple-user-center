create
    definer = devuser@`%` procedure check_user_related_before_delete(IN in_group_id int)
BEGIN
	update operate_item oi 
	inner join (select us.user_id, count(us.user_id) as count from operate_item oi 
  	inner join user_school us on oi.group_id = in_group_id and oi.c2 = us.user_id
  	group by us.user_id having count < 2) tmp on oi.group_id = in_group_id and oi.c2 = tmp.user_id
  	set oi.status = 2;

END;

