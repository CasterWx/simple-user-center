create
    definer = devuser@`%` procedure global_user_get_by_page(IN in_offset int, IN in_count int, OUT out_total_count int)
BEGIN
	SELECT SQL_CALC_FOUND_ROWS DISTINCT * FROM global_user LIMIT in_offset, in_count;
    SET out_total_count = FOUND_ROWS();
END;

