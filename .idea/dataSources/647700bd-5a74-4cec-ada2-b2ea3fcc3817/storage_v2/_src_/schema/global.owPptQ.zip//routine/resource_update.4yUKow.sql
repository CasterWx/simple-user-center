create
    definer = devuser@`%` procedure resource_update(IN in_id int, IN in_url varchar(255), IN in_type int,
                                                    IN in_status int, IN in_size int)
BEGIN

	UPDATE `resource` SET 
		`type` = in_type,
		`url` = in_url,
		`size` = in_size,
		`status` = in_status
	WHERE id = in_id;

END;

