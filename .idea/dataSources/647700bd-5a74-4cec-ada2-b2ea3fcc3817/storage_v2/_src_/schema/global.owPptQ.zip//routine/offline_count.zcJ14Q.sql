create
    definer = devuser@`%` procedure offline_count(IN in_gender varchar(20), IN in_display_name varchar(60),
                                                  IN in_identity_card varchar(18), IN in_center_id int,
                                                  IN in_major_id int, IN in_student_number varchar(40),
                                                  IN in_enroll_semester_id int, IN in_study_status_id int,
                                                  IN in_candidate_number varchar(40), IN in_teachingplan_course_id int,
                                                  IN in_offset int, IN in_count int, OUT out_total_records int)
BEGIN

    SET SQL_SAFE_UPDATES=0;
    
    SELECT SQL_CALC_FOUND_ROWS c.* FROM  student_course AS sc INNER JOIN count_student_score AS c ON sc.teachingplan_course_id = c.teachingplan_course_id AND sc.student_id = c.student_id  
	WHERE (in_center_id IS NULL OR c.center_id = in_center_id)
	AND (in_teachingplan_course_id IS NULL OR c.teachingplan_course_id = in_teachingplan_course_id) 	
	AND (in_major_id IS NULL OR c.major_id = in_major_id) 	
	AND (in_student_number IS NULL OR c.student_number like concat('%',in_student_number,'%'))
	AND (in_enroll_semester_id IS NULL OR c.enroll_semester_id = in_enroll_semester_id)
	AND (in_study_status_id IS NULL OR c.study_status_id = in_study_status_id)
	AND (in_candidate_number IS NULL OR c.candidate_number like concat('%',in_candidate_number,'%'))
    AND (in_gender IS NULL OR c.gender like concat('%',in_gender,'%'))
    AND (in_display_name IS NULL OR c.display_name like concat('%',in_display_name,'%'))
    AND (in_identity_card IS NULL OR c.identity_card like concat('%',in_identity_card,'%'))
	LIMIT in_offset, in_count;

    SET out_total_records = FOUND_ROWS();
    
    SET SQL_SAFE_UPDATES=1;
    
END;

