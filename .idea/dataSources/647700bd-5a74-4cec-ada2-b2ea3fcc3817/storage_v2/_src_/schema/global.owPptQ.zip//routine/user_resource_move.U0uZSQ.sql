create
    definer = devuser@`%` procedure user_resource_move(IN in_ids mediumtext, IN in_parent_id int)
BEGIN

	DECLARE common_sql_str TEXT;
	
	SET common_sql_str = CONCAT('update user_resource set parent_id = ', in_parent_id, ' WHERE id in (', in_ids, ');');
	
	SET @sql_Str = common_sql_str;
	
	PREPARE s1 FROM @sql_Str;
	EXECUTE s1;
	DEALLOCATE PREPARE s1;
	

END;

