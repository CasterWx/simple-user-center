create
    definer = devuser@`%` procedure check_batch_import_peixun_student_global_info(IN in_operate_group_id int, IN in_school_id int)
BEGIN

	DECLARE VALID INT;
    DECLARE INVALID INT;
    DECLARE CHECKING INT;
    DECLARE WAITING INT;
    
    SET VALID = 2;
    SET INVALID = 3;
    SET CHECKING = 6;
    SET WAITING = 1;
    
    SET SQL_SAFE_UPDATES = 0; 
    
	UPDATE operate_item oi SET oi.c19 = NULL, oi.c18 = NULL, oi.status = WAITING, oi.`comment` = '等待校验' WHERE oi.group_id = in_operate_group_id;
    UPDATE operate_group og SET og.status = CHECKING WHERE og.id=in_operate_group_id;
 
	UPDATE operate_item oi 
      SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，用户名不能为空'), '用户名不能为空'), oi.status = INVALID
      WHERE (oi.c1 IS NULL OR oi.c1 = '') AND oi.group_id = in_operate_group_id;
	
	UPDATE operate_item oi 
      SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，密码不能为空'), '密码不能为空'), oi.status = INVALID
      WHERE (oi.c2 IS NULL OR oi.c2 = '') AND oi.group_id = in_operate_group_id;
	
	UPDATE operate_item oi 
	SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，姓名格式不正确，请输入10位以内中文或20位以内英文的姓名 '), '姓名格式不正确，请输入10位以内中文或20位以内英文的姓名'), oi.status = INVALID
    WHERE oi.c3 IS NOT NULL AND oi.c3 != '' AND ((LENGTH(oi.c3) != CHAR_LENGTH(oi.c3) * 3 OR CHAR_LENGTH(oi.c3) > 10) AND oi.c3 NOT REGEXP '^[A-Za-z]{1,20}$')  AND oi.group_id = in_operate_group_id;

    UPDATE operate_item oi 
      SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，姓名不能为空'), '姓名不能为空'), oi.status = INVALID
      WHERE (oi.c3 IS NULL OR oi.c3 = '') AND oi.group_id = in_operate_group_id;
		
	UPDATE operate_item oi 
		SET oi.`status` = INVALID, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','，用户名不能超过30个字符'),'用户名不能超过30个字符')
		WHERE oi.group_id = in_operate_group_id AND LENGTH(oi.c1) > 30;
		
	UPDATE operate_item oi 
	  SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，用户名格式不正确，不允许是手机号码'), '用户名格式不正确，不允许是手机号码'), oi.status = INVALID
	  WHERE oi.c1 IS NOT NULL AND oi.c1 != '' AND oi.c1 REGEXP '^[1][3456789][0-9]{9}$' AND oi.group_id = in_operate_group_id;
	UPDATE operate_item oi 
	  SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，用户名格式不正确，用户名只能为数字和字母或_-@组成'), '用户名格式不正确，用户名只能为数字和字母或_-@组成'), oi.status = INVALID
	  WHERE oi.c1 IS NOT NULL AND oi.c1 != '' AND oi.c1 NOT REGEXP '^[A-Za-z0-9\\_@-]+$' AND oi.group_id = in_operate_group_id;

	UPDATE operate_item oi 
	  SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，密码格式不正确，密码只能为6~20位数字和字母组成'), '密码格式不正确，密码只能为6~20位数字和字母组成'), oi.status = INVALID
	  WHERE oi.c2 IS NOT NULL AND oi.c2 != '' AND (LENGTH(oi.c2) < 6 OR LENGTH(oi.c2) > 20) AND oi.c2 NOT REGEXP '^[A-Za-z0-9]+$' AND oi.group_id = in_operate_group_id; 
	UPDATE operate_item oi 
	  SET oi.comment = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，身份证格式不正确'), '身份证格式不正确'), oi.status = INVALID
	  WHERE oi.c5 IS NOT NULL AND oi.c5 != '' AND oi.c5 NOT REGEXP '^[1-9]{1}[0-9]{16}([0-9]|[xX])$' AND oi.c5 NOT REGEXP '^[A-Za-z]{1,2}[0-9]{6}[(][0-9Aa][)]$'  AND oi.group_id = in_operate_group_id; 
    
    UPDATE operate_item oi 
	  SET oi.`comment` = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，用户名重复'), '用户名重复'), oi.status = INVALID
	  WHERE oi.group_id = in_operate_group_id 
	  AND (EXISTS (
		SELECT 1 from 
		  (SELECT c0,c1 FROM operate_item WHERE group_id = in_operate_group_id AND c1 != '' GROUP BY c1 HAVING count(c1)>1) AS oi2
		  WHERE oi2.c1 = oi.c1
		  )
	OR EXISTS (SELECT * FROM global_user gu WHERE gu.user_name = oi.c1));

	UPDATE operate_item oi 
	  SET oi.`comment` = IF(oi.status = INVALID, CONCAT(oi.`comment`, '，身份证号重复'), '身份证号重复'), oi.status = INVALID
	  WHERE oi.group_id = in_operate_group_id 
	  AND EXISTS (
		SELECT 1 from 
		(SELECT c0,c5 FROM operate_item WHERE group_id = in_operate_group_id AND c5 != '' GROUP BY c5 HAVING count(c5)>1) AS oi2
		WHERE oi2.c5 = oi.c5
	  );
    
    UPDATE operate_item SET c19 = id WHERE group_id = in_operate_group_id;
    
    UPDATE operate_item 
	SET `status` = VALID, `comment` = '有效数据'
	  WHERE `status` = WAITING AND group_id = in_operate_group_id;
    
	UPDATE operate_group og 
	  SET og.status= CASE 
	  WHEN EXISTS (SELECT oi.id FROM operate_item oi WHERE oi.group_id=in_operate_group_id AND oi.status = INVALID) THEN INVALID 
	  ELSE VALID END 
	  WHERE og.id=in_operate_group_id;
 
END;

