create
    definer = devuser@`%` procedure check_batch_import_student_global_info(IN in_operate_group_id int, IN in_school_id int, IN in_recheck int)
BEGIN
	
   	DECLARE VALID INT;
    DECLARE INVALID INT;
    DECLARE CHECKING INT;
    DECLARE WAITING INT;
    
    SET VALID = 2;
    SET INVALID = 3;
    SET CHECKING = 6;
    SET WAITING = 1;
   
    SET SQL_SAFE_UPDATES = 0;
   
    
    IF in_recheck = 1 THEN
		UPDATE operate_item oi SET oi.c19 = NULL, oi.c18 = NULL, oi.status = WAITING, oi.comment= '等待校验';
    END IF;
    
    UPDATE operate_group og SET og.status = CHECKING WHERE og.id=in_operate_group_id;
	
    
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '用户名不能为空' WHERE (oi.c4 IS NULL OR oi.c4 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '密码不能为空' WHERE (oi.c5 IS NULL OR oi.c5 = '') IS NULL AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '姓名不能为空' WHERE (oi.c6 IS NULL OR oi.c6 = '') IS NULL AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '性别不能为空' WHERE (oi.c7 IS NULL OR oi.c7 = '') AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '身份证格式不正确' 
    WHERE oi.c10 IS NOT NULL AND oi.c10 != '' AND oi.c10 NOT REGEXP '^[1-9]{1}[0-9]{16}([0-9]|[xX])$' AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
	UPDATE operate_item oi SET oi.status = INVALID, oi.comment = '手机号格式不正确' 
    WHERE oi.c13 IS NOT NULL AND oi.c13 != '' AND oi.c13 NOT REGEXP '^[1][3-9][0-9]{9}$' AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    
    
	UPDATE operate_item oi 
    SET oi.status = INVALID, oi.`comment` = '用户名与前面的数据重复'
    WHERE oi.group_id = in_operate_group_id 
    AND EXISTS (SELECT 1 from (SELECT c0,c4 FROM operate_item WHERE group_id = in_operate_group_id GROUP BY c4 HAVING count(c4)>1) AS oi2
    WHERE oi2.c4 = oi.c4 AND oi2.c0 != oi.c0);
    
	UPDATE operate_item oi 
    SET oi.status = INVALID, oi.`comment` = '身份证号与前面的数据重复'
    WHERE oi.group_id = in_operate_group_id 
    AND EXISTS (SELECT 1 from (SELECT c0,c10 FROM operate_item WHERE group_id = in_operate_group_id AND c10 != '' GROUP BY c10 HAVING count(c10)>1) AS oi2
    WHERE oi2.c10 = oi.c10 AND oi2.c0 != oi.c0);
    
	UPDATE operate_item oi 
    SET oi.status = INVALID, oi.`comment` = '手机号与前面的数据重复'
    WHERE oi.group_id = in_operate_group_id 
    AND EXISTS (SELECT 1 from (SELECT c0,c13 FROM operate_item WHERE group_id = in_operate_group_id AND c13 != '' GROUP BY c13 HAVING count(c13)>1) AS oi2
    WHERE oi2.c13 = oi.c13 AND oi2.c0 != oi.c0);
    
	
    
    UPDATE operate_item oi 
    INNER JOIN global_user gu ON oi.c4 = gu.user_name 
    SET oi.c18 = gu.id WHERE oi.c4 != '' AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    
    UPDATE operate_item oi  
    INNER JOIN user_school us ON us.user_id = oi.c18
    SET oi.status = INVALID, oi.`comment` = '用户名已存在'
    WHERE us.user_role IS NOT NULL AND us.school_id = in_school_id AND oi.c18 != '' AND oi.c18 IS NOT NULL AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
    UPDATE operate_item oi 
    INNER JOIN global_user gu
    SET oi.status = INVALID, oi.`comment` = '身份证号已存在' 
    WHERE oi.c10 IS NOT NULL AND oi.c10 != '' AND oi.c10 = gu.identity_card AND oi.status = WAITING AND oi.group_id = in_operate_group_id;
    
	UPDATE operate_item oi 
    INNER JOIN global_user gu
    SET oi.status = INVALID, oi.`comment` = '手机号已存在' 
    WHERE oi.c13 IS NOT NULL AND oi.c13 != '' AND oi.c13 = gu.phone_num AND oi.status = WAITING AND oi.group_id = in_operate_group_id;

	
    
    UPDATE operate_item SET c19 = id;
	UPDATE operate_group og SET og.status=
	CASE WHEN EXISTS (SELECT oi.id FROM operate_item oi WHERE oi.group_id=in_operate_group_id AND oi.status = INVALID)
	THEN INVALID ELSE VALID END 
	WHERE og.id=in_operate_group_id;

END;

