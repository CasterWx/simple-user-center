create
    definer = devuser@`%` procedure check_student_number(IN in_student_number varchar(50), OUT out_exist int(1))
BEGIN
	
  SELECT COUNT(1) INTO out_exist FROM student WHERE student_number = in_student_number;
  
END;

