create
    definer = devuser@`%` procedure video_search(IN in_persistent_id varchar(255))
BEGIN

	SELECT * FROM video WHERE (in_persistent_id IS NULL OR persistent_id = in_persistent_id);
	
END;

