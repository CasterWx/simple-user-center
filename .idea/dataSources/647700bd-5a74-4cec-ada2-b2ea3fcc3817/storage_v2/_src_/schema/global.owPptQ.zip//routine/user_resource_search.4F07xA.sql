create
    definer = devuser@`%` procedure user_resource_search(IN in_id int, IN in_user_id int, IN in_name varchar(255),
                                                         IN in_status int(2), IN in_parent_id int,
                                                         IN in_types varchar(64), IN in_contain_dir int(2),
                                                         IN in_only_directory bit, IN in_sort varchar(20),
                                                         IN in_order varchar(10), IN in_offset int, IN in_size int,
                                                         OUT out_total_count int)
BEGIN

	DECLARE sql_str VARCHAR(5000);
	DECLARE common_sql_str VARCHAR(5000);
	DECLARE count_sql_str VARCHAR(5000);

	SET common_sql_str = " FROM user_resource ur1 "; 
	SET common_sql_str = CONCAT(common_sql_str, " LEFT JOIN (SELECT * FROM user_resource ur2 WHERE ur2.user_id = ", in_user_id, ") ur2 ON ur1.parent_id = ur2.id ");
	SET common_sql_str = CONCAT(common_sql_str, " LEFT JOIN resource r ON r.id = ur1.resource_id ");
	SET common_sql_str = CONCAT(common_sql_str, " WHERE ur1.user_id = ", in_user_id);
	
	IF in_id IS NOT NULL THEN
		SET common_sql_str = CONCAT(common_sql_str, " AND ur1.id = ", in_id);
	END IF;
	IF in_status IS NOT NULL THEN 
		SET common_sql_str = CONCAT(common_sql_str, " AND ur1.status = ", in_status, " AND (ur2.id IS NULL OR ur2.status = ", in_status, ") ");
	END IF;
	SET common_sql_str = CONCAT(common_sql_str, " AND ( ? IS NULL OR ur1.name LIKE ?) ");
	IF in_parent_id IS NOT NULL THEN 
		SET common_sql_str = CONCAT(common_sql_str, " AND ur1.parent_id = ", in_parent_id);
	END IF;
	IF in_types IS NOT NULL THEN
        IF in_contain_dir = 1 THEN
			SET common_sql_str = CONCAT(common_sql_str, " AND (r.type in ( ", in_types, ") OR ur1.resource_id = 0 )");
		ELSE
			SET common_sql_str = CONCAT(common_sql_str, " AND r.type in ( ", in_types, ") ");
		END IF;
	END IF;
	IF in_contain_dir = 0 THEN
		SET common_sql_str = CONCAT(common_sql_str, " AND r.id IS NOT NULL ");
	END IF;
	IF in_only_directory = 1 THEN
		SET common_sql_str = CONCAT(common_sql_str, " AND ur1.resource_id = 0 ");
	END IF;
	
	SET @name_like = CONCAT("%", in_name, "%");
	SET @name = in_name;
	
	SET count_sql_str = CONCAT("SELECT count(*) INTO @count ", common_sql_str, ";");
	SET @sql_count = count_sql_str;
	PREPARE s1 FROM @sql_count;
	EXECUTE s1 USING @name, @name_like;
	DEALLOCATE PREPARE s1;
	SET out_total_count = @count;
	
	
	SET sql_str = "SELECT ur1.*, ur2.name parent_name, r.id r_id, r.type r_type, r.url r_url, r.size r_size, r.status r_status, r.created_time r_created_time, r.updated_time r_updated_time ";
	SET sql_str = CONCAT(sql_str, common_sql_str);
	
	IF in_sort IS NOT NULL and in_order IS NOT NULL THEN
		SET sql_str = CONCAT(sql_str, " ORDER BY (r.id IS NULL) DESC,ur1.", in_sort, " ", in_order);
	ELSE
		SET sql_str = CONCAT(sql_str, " ORDER BY (r.id IS NULL) DESC,ur1.created_time DESC ");
	END IF;
	
	SET sql_str = CONCAT(sql_str, " LIMIT ", in_offset, ", ", in_size, ";");
	
	SET @sql_search = sql_str;
	PREPARE s2 FROM @sql_search;
	EXECUTE s2 USING @name, @name_like;
	DEALLOCATE PREPARE s2;
	
END;

