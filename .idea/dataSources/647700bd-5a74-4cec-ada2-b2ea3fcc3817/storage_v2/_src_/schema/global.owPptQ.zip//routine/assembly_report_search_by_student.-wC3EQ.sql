create
    definer = devuser@`%` procedure assembly_report_search_by_student(IN in_student_id int, IN in_teachingplan_course_id int)
BEGIN

    SET SQL_SAFE_UPDATES=0;

    DROP TEMPORARY TABLE IF EXISTS temp_student_course_tbl_one;

    CREATE TEMPORARY TABLE temp_student_course_tbl_one AS  ( 

        SELECT 
        s.id AS student_id, 
        s.global_user_id, 
        s.student_number, 
        s.center_id, 
        s.major_id, 
        s.semester_id, 
        s.study_status_id, 
        tpc.course_id, 
		c.name AS course_name, 
        c.global_courseware_id, 
        tpc.id AS teachingplan_course_id, 
		tpc.optional, tpc.pass_score, 
        tpc.term AS suggest_term, 
        tpc.final_type_id,
        tpc.usual_score_rule_id, 
        tpc.final_score_rule_id,
        sc.flag AS learn_status, 
        CASE WHEN sc.semester_id >0 THEN 
        	(SELECT sequence - ss.sequence + 1 FROM semester WHERE id = sc.semester_id ) 
        ELSE 
        	tpc.term 
        END AS study_term, 
        sc.score AS final_score,
        sc.archived_score

        FROM student AS s   
        INNER JOIN semester AS ss ON s.semester_id = ss.id
        INNER JOIN teachingplan AS tp on tp.major_id = s.major_id and tp.semester_id = s.semester_id 
        INNER JOIN teachingplan_course AS tpc ON tp.id = tpc.teachingplan_id          
        LEFT JOIN student_course AS sc ON sc.teachingplan_course_id = tpc.id AND sc.student_id = s.id 
        INNER JOIN course AS c ON tpc.course_id = c.id
        WHERE (in_student_id IS NULL OR s.id=in_student_id) AND (in_teachingplan_course_id IS NULL OR tpc.id = in_teachingplan_course_id)      
    );


    SELECT * FROM temp_student_course_tbl_one;

    SELECT sct.* FROM student_course_track AS sct 
    INNER JOIN temp_student_course_tbl_one AS tst ON tst.student_id = sct.student_id and sct.teachingplan_course_id = tst.teachingplan_course_id;


    SELECT csc.* FROM course_study_record AS csc
    INNER JOIN temp_student_course_tbl_one AS tst ON tst.student_id = csc.student_id and csc.teachingplan_course_id = tst.teachingplan_course_id;


    SELECT se.* FROM student_exercise AS se 
    INNER JOIN temp_student_course_tbl_one AS tt ON se.student_id = tt.student_id  AND se.`status` > 0
    INNER JOIN exercise ON se.exercise_id=exercise.id and exercise.teachingplan_course_id=tt.teachingplan_course_id;


    SELECT DISTINCT e.* FROM exercise AS e
    INNER JOIN temp_student_course_tbl_one AS tt ON e.teachingplan_course_id = tt.teachingplan_course_id 
    ORDER BY  tt.course_id DESC;

    SELECT post.* FROM post 
    INNER JOIN temp_student_course_tbl_one AS tt ON post.author_id = tt.global_user_id AND post.teachingplan_course_id = tt.teachingplan_course_id;
    

    SELECT reply.* FROM reply 
    INNER JOIN temp_student_course_tbl_one AS tt ON  reply.author_id = tt.global_user_id and reply.teachingplan_course_id = tt.teachingplan_course_id;
    

    SELECT sca.* FROM student_course_activity_score AS sca
    INNER JOIN temp_student_course_tbl_one AS tt ON tt.teachingplan_course_id = sca.teachingplan_course_id and tt.student_id = sca.student_id;
    

    SELECT ses.* FROM student_exam_score AS ses 
    INNER JOIN temp_student_course_tbl_one AS tt ON tt.teachingplan_course_id = ses.teachingplan_course_id and tt.student_id = ses.student_id;


    SELECT sme.* FROM student_makeup_exam AS sme 
    INNER JOIN temp_student_course_tbl_one AS tt ON sme.student_id = tt.student_id  AND sme.`status` = 2 AND sme.teachingplan_course_id=tt.teachingplan_course_id;
    
	SELECT DISTINCT tco.*, sros.`name` AS otherscore_name, sros.max_score 
	FROM teachingplan_course_otherscore tco 
	INNER JOIN scoring_rule_other_score sros ON tco.otherscore_id = sros.id
    INNER JOIN temp_student_course_tbl_one t ON tco.teachingplan_course_id = t.teachingplan_course_id;
    
	SELECT DISTINCT sco.*
	FROM student_course_otherscore AS sco
	INNER JOIN temp_student_course_tbl_one AS tt ON sco.student_id = tt.student_id AND tt.teachingplan_course_id = sco.teachingplan_course_id;

	
    SELECT DISTINCT srus.* FROM scoring_rule_usual_score AS srus
    INNER JOIN temp_student_course_tbl_one AS tt ON tt.usual_score_rule_id = srus.id;


    SELECT DISTINCT srfs.* FROM scoring_rule_final_score AS srfs
    INNER JOIN temp_student_course_tbl_one AS tt ON tt.final_score_rule_id = srfs.id;


    DROP TEMPORARY TABLE IF EXISTS temp_student_course_tbl_one;  

END;

