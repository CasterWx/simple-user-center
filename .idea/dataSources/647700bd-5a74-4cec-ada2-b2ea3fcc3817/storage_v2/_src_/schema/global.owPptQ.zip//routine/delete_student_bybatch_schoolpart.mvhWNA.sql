create
    definer = devuser@`%` procedure delete_student_bybatch_schoolpart(IN in_group_id int)
BEGIN       
	
	DROP TEMPORARY TABLE IF EXISTS delete_student_id_tb;
    CREATE TEMPORARY TABLE delete_student_id_tb(
        student_id INT(11)
    );
	INSERT INTO delete_student_id_tb SELECT c1 FROM operate_item WHERE group_id=in_group_id AND status=2;
	
	
    DELETE t_history,s_thesis 
    FROM student_thesis s_thesis
    INNER JOIN thesis_history t_history ON t_history.student_thesis_id=s_thesis.id
    WHERE s_thesis.student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM student_exam WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
      
	
	DELETE FROM student_exam_score WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM student_exercise WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM student_course WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM student_course_track WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
    
    DELETE FROM student_course_activity_score WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
    
    DELETE FROM student_course_otherscore WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
    
    DELETE FROM course_study_record WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM student_answer WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM student_final_reservation WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	
    
	
	DELETE FROM student_xueji_change_record WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
	DELETE FROM count_student_score WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
    
    DELETE ftu
    FROM forum_thumbs_up ftu
    INNER JOIN student s ON ftu.user_id = s.global_user_id
    WHERE s.id IN (SELECT student_id FROM delete_student_id_tb);
    
    
    DELETE FROM student_makeup_exam WHERE student_id IN (SELECT student_id FROM delete_student_id_tb);
    
	
    SET FOREIGN_KEY_CHECKS=0;
    
    DELETE FROM student WHERE id IN (SELECT student_id FROM delete_student_id_tb);
    
    SET FOREIGN_KEY_CHECKS=1;
    
    
    UPDATE operate_item SET status=4 WHERE group_id=in_group_id AND status=2;
    UPDATE operate_group SET status= 4 WHERE id=in_group_id;
	
    DROP TEMPORARY TABLE delete_student_id_tb;
END;

