create
    definer = devuser@`%` procedure major_create(IN in_major_name varchar(64), IN in_level varchar(64),
                                                 IN in_level_sequence int, IN in_introduction mediumtext,
                                                 IN in_introduction_short varchar(500), IN in_cover_image_id int,
                                                 IN in_show_in_home_page bit, IN in_global_major_id int, OUT out_id int)
BEGIN



    INSERT INTO major(`name`,`level`, `level_sequence`, `introduction`, `introduction_short`, `cover_image_id`, `show_in_home_page`, `global_major_id`)

    VALUES(in_major_name,in_level, in_level_sequence, in_introduction, in_introduction_short, in_cover_image_id, in_show_in_home_page, in_global_major_id);

    

    SET out_id = LAST_INSERT_ID();

END;

