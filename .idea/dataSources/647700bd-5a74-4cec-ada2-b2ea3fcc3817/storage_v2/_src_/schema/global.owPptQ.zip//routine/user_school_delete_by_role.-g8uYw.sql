create
    definer = devuser@`%` procedure user_school_delete_by_role(IN in_global_user_id int, IN in_school_id int,
                                                               IN in_user_role_list mediumtext)
BEGIN	
	delete from user_school 
	where  (in_global_user_id is null or user_id = in_global_user_id)
	AND (in_school_id is null or school_id = in_school_id)
	AND (in_user_role_list is null or FIND_IN_SET(user_role, in_user_role_list));
END;

