create
    definer = devuser@`%` procedure user_school_update(IN in_id int, IN in_user_id int, IN in_school_id int, IN in_user_role int)
BEGIN
UPDATE user_school
SET user_id=in_user_id, school_id = in_school_id, user_role = in_user_role
WHERE id=in_id;
END;

