create
    definer = devuser@`%` procedure user_token_history_update(IN in_user_id int, IN in_status bit)
BEGIN
	
    UPDATE user_token_history SET `status` = in_status WHERE user_id = in_user_id;

END;

