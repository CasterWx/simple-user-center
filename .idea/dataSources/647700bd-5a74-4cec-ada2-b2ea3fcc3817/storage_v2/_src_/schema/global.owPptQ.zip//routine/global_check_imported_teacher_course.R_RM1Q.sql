create
    definer = devuser@`%` procedure global_check_imported_teacher_course(IN in_group_id int, IN in_school_id int, IN in_repeated int)
BEGIN
	
	DECLARE local_waiting INT DEFAULT 1;
    DECLARE local_valid INT DEFAULT 2;
    DECLARE local_invalid INT DEFAULT 3;
    DECLARE local_complete INT DEFAULT 4;
    DECLARE local_cancel INT DEFAULT 5;
    DECLARE local_checking INT DEFAULT 6;
    
    
    IF in_repeated = 1 THEN
		UPDATE  operate_item SET status=local_waiting,comment='等待处理',c3=null where group_id = in_group_id;
    END IF;
    
    UPDATE operate_item SET c19=id where group_id=in_group_id;
    
    
    UPDATE  operate_item SET status=local_invalid,comment= '用户名不能为空' WHERE group_id = in_group_id AND (c1 is null or c1 ="");
	
    
    
	UPDATE  operate_item oi INNER JOIN global_user gu ON oi.c1=gu.user_name AND oi.group_id=in_group_id AND oi.status=local_waiting
	INNER JOIN user_school us ON us.user_id=gu.id AND us.school_id = in_school_id  
    SET oi.c3 = gu.id;
    
    UPDATE operate_item SET status=local_invalid,comment= '用户名不存在' 
    WHERE (c3 ='' OR c3 IS  NULL)  AND group_id=in_group_id AND status=local_waiting;

END;

