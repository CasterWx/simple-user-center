create
    definer = devuser@`%` procedure check_imported_userName(IN in_group_id int, IN in_school_id int)
BEGIN
	UPDATE  operate_item oi INNER JOIN global_user gu ON oi.c3=gu.user_name AND oi.group_id=in_group_id 
	INNER JOIN user_school us ON us.user_id=gu.id AND us.school_id=in_school_id AND us.user_role=1
	AND oi.status= 1 SET status=2,c2=gu.id;
  
  	UPDATE operate_item SET status=3,result = '学生不存在' WHERE group_id=in_group_id AND status= 1;
  	
  	UPDATE operate_group SET status=
 	case when EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=2)
	 THEN 2 else 3 END
 	WHERE id=in_group_id;
   
END;

