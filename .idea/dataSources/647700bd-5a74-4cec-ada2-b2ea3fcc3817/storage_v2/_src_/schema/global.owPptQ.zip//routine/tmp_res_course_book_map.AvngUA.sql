create
    definer = devuser@`%` procedure tmp_res_course_book_map(OUT out_result_code int)
BEGIN
TRUNCATE TABLE course_ebook;

INSERT INTO course_ebook (`course_id`, `global_book_id`, `created_time`, `updated_time`) 
SELECT b.school_course_id,b.global_course_id,NOW(),NOW() from tmp_res_init b;
SELECT ROW_COUNT() INTO out_result_code;
TRUNCATE TABLE tmp_res_init;
END;

