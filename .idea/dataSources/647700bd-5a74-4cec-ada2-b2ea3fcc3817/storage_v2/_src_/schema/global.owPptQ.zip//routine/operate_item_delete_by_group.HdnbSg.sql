create
    definer = devuser@`%` procedure operate_item_delete_by_group(IN in_operate_group_id int, IN in_status int)
BEGIN
	DECLARE VALID INT;
    DECLARE CANCEL INT;
        
    SET VALID = 2;
    SET CANCEL = 5;


	SET SQL_SAFE_UPDATES = 0;
    
    DELETE FROM operate_item 
    WHERE group_id = in_operate_group_id
    AND (in_status IS NULL OR `status` = in_status);
    
    UPDATE operate_group
    SET `status` = CASE WHEN EXISTS ( SELECT 1 FROM operate_item WHERE group_id = in_operate_group_id) THEN VALID ELSE CANCEL END
    WHERE id = in_operate_group_id; 
    
END;

