create
    definer = devuser@`%` procedure global_user_get_by_school_symbol(IN in_school_symbol varchar(45))
BEGIN
    
	SELECT a.* FROM `global_user`a , `user_school` b,`school` c WHERE 
	      c.`symbol`=in_school_symbol AND c.`id` = b.`school_id` AND 
	      b.`user_role`=2 AND b.`user_id` = a.`id` LIMIT 1;
    END;

