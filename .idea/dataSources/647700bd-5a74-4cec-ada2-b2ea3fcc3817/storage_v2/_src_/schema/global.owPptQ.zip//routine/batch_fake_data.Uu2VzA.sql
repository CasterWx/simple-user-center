create
    definer = devuser@`%` procedure batch_fake_data(IN in_student_count int, IN in_total_day int)
BEGIN

	CREATE TEMPORARY TABLE IF NOT EXISTS tempStudent(
		SELECT id FROM student
		ORDER BY RAND()
		LIMIT 1
	);

	SET @count =0;
	WHILE (@count < in_total_day) DO
		-- INSERT INTO course_student_record (course_id, student_id, node_id, start_time, end_time)
		SELECT s.id, m_c.course_id, 0, DATE_ADD(NOW(), INTERVAL @count DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL @count DAY), INTERVAL 30 MINUTE)
		FROM student AS s 
			RIGHT JOIN tempStudent ON s.id = tempStudent.id
			INNER JOIN major_course AS m_c ON s.major_id = s.major_id;

		-- INSERT student_course_track (student_id, course_id, track_time)
		SELECT s.id, m_c.course_id, 0, DATE_ADD(NOW(), INTERVAL @count DAY)
		FROM student AS s 
			RIGHT JOIN tempStudent ON s.id = tempStudent.id
			INNER JOIN major_course AS m_c ON s.major_id = s.major_id;

		SET @count = @count +1;
	END WHILE;

	-- INSERT student_course_activity_score (student_id, course_id, score)
	SELECT s.id, m_c.course_id, (FLOOR(RAND() * (20 - 10+ 1)) + 10)
	FROM student AS s 
		RIGHT JOIN tempStudent ON s.id = tempStudent.id
		INNER JOIN major_course AS m_c ON s.major_id = s.major_id;

	SELECT student.id, student.name, student.password FROM student RIGHT JOIN tempStudent ON student.id = tempStudent.id;

	DROP TEMPORARY TABLE IF EXISTS tempStudent;

END;

