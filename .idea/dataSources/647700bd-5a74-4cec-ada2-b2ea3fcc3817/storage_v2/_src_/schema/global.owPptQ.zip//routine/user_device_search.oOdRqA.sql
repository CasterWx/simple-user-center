create
    definer = devuser@`%` procedure user_device_search(IN in_os int(1), IN in_mac varchar(45), IN in_idfa varchar(45),
                                                       IN in_imei varchar(45))
BEGIN

	SELECT * FROM user_device
	WHERE (in_mac IS NULL OR mac = in_mac)
	AND (in_idfa IS NULL OR idfa = in_idfa)
	AND (in_imei IS NULL OR imei = in_imei)
    AND (in_os IS NULL OR os = in_os)
	ORDER BY id DESC;
    
END;

