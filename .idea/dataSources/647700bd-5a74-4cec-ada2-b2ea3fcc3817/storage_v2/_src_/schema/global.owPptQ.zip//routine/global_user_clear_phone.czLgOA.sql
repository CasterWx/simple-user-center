create
    definer = devuser@`%` procedure global_user_clear_phone(IN in_phone varchar(20))
BEGIN

	UPDATE global_user SET phone_num = NULL WHERE phone_num = in_phone;
END;

