create
    definer = devuser@`%` procedure account_search(IN in_user_name_list mediumtext, IN in_id_card_list mediumtext,
                                                   IN in_phone_num_list mediumtext)
BEGIN
	SET @sql = "select g.*, u.id u_id, u.school_id u_school_id, u.user_id u_user_id, u.user_role u_user_role from global_user g left join user_school u on g.id = u.user_id where 1 = 1 ";
	IF in_user_name_list IS NOT NULL
		THEN SET @sql = CONCAT(@sql, " AND g.user_name in (", in_user_name_list, ")");
	END IF;
	IF in_id_card_list IS NOT NULL
		THEN SET @sql = CONCAT(@sql, " AND g.identity_card in (", in_id_card_list, ")");
	END IF;
	IF in_phone_num_list IS NOT NULL
		THEN SET @sql = CONCAT(@sql, " AND g.phone_num in (", in_phone_num_list, ")");
	END IF;
	PREPARE stmt FROM @sql;
    EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END;

