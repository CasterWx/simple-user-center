create
    definer = devuser@`%` procedure initGZSchoolDatasForTest(IN in_admin_user_name varchar(100),
                                                             IN in_admin_password varchar(100),
                                                             IN in_school_symbol_list text, IN in_school_name_list text,
                                                             IN in_school_schema_list text)
BEGIN

	DECLARE v_symbol VARCHAR(20);
	DECLARE v_school_name VARCHAR(20);
	DECLARE v_schema VARCHAR(20);
   

	-- global.global_user
	INSERT INTO `global`.`global_user` (`user_name`, `display_name`, `password`, `gender`, `user_type`, `phone_valid`) 
	VALUES (in_admin_user_name, '学校老师', in_admin_password, '男', '0', '1');


	WHILE LENGTH(in_school_symbol_list)>0 DO
		SET v_symbol = SUBSTRING_INDEX(in_school_symbol_list,',',1);
		SET in_school_symbol_list = SUBSTRING(in_school_symbol_list, LENGTH(v_symbol)+2);

		SET v_school_name = SUBSTRING_INDEX(in_school_name_list,',',1);
		SET in_school_name_list = SUBSTRING(in_school_name_list, LENGTH(v_school_name)+2);

		SET v_schema = SUBSTRING_INDEX(in_school_schema_list,',',1);
		SET in_school_schema_list = SUBSTRING(in_school_schema_list, LENGTH(v_schema)+2);
		

		-- global.school、npdb.school_db_setting、npdb.school_module
		INSERT INTO `global`.`school` (`name`, `symbol`, `category_id`, `status`) 
		SELECT v_school_name, v_symbol, id, '1' FROM `global`.`school_category` WHERE `type` = 6;


		INSERT INTO `npdb`.`school_db_setting` (`school_id`, `url`, `schema_name`, `driver_class_name`, `user_name`, `password`, `initial_size`, `max_active`, `max_idle`, `validation_query`, `status`) 
		SELECT (SELECT id FROM global.school WHERE `symbol` = v_symbol), sbs.`url`, v_schema,
			sbs.`driver_class_name`, sbs.`user_name`, sbs.`password`, sbs.`initial_size`, sbs.`max_active`, sbs.`max_idle`, sbs.`validation_query`, sbs.`status`
		FROM npdb.`school_db_setting` sbs limit 0, 1;


		INSERT INTO `npdb`.`school_module`(`school_id`, `role_id`, `module_id`,  `parent_module_id`, `order`, `show_in_homepage`, `show_in_nav`)
		SELECT 
			s.id,
			mp.role_id,
			mp.module_id,
			mp.parent_module_id,
			mp.`order`,
			mp.show_in_homepage,
			mp.show_in_nav
		FROM `npdb`.module_package AS mp
		INNER JOIN `global`.school_category AS sc ON mp.school_category_type = sc.`type`
		INNER JOIN `global`.school AS s ON s.category_id = sc.id
		WHERE s.`symbol` = v_symbol
		ORDER BY s.id, mp.role_id, mp.`module_id`;


		 -- global.user_school
        INSERT INTO `global`.`user_school` (`user_id`, `school_id`, `user_role`)
		VALUES (
			(SELECT id FROM `global`.`global_user` WHERE user_name = in_admin_user_name),
			(SELECT id FROM `global`.`school` WHERE `symbol` = v_symbol),
			2
		);


		-- school teacher, teacher_module
		set @sql = concat(
			"INSERT INTO `", v_schema, "`.`teacher` (`global_user_id`, `global_user_name`, `display_name`, `gender`) 
			SELECT id, user_name, display_name, gender FROM `global`.global_user WHERE user_name = '", in_admin_user_name, "'"
		);
	    PREPARE stmt FROM @sql;
	    EXECUTE stmt;
        
        set @sql = concat(
			"INSERT INTO `", v_schema, "`.`teacher_module` (`teacher_id`, `module_id`)
			SELECT (SELECT id FROM `", v_schema, "`.`teacher` WHERE global_user_name = '", in_admin_user_name, "'), sm.module_id
			FROM `npdb`.school_module sm 
			INNER JOIN `global`.school s ON sm.school_id = s.id
			WHERE s.`symbol` = '", v_symbol, "' AND sm.role_id = 2"
		);
		PREPARE stmt FROM @sql;
	    EXECUTE stmt;
        
	END WHILE;


END;

