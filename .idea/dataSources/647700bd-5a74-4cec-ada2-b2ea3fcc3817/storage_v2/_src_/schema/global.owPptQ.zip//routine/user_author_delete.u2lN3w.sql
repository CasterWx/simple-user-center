create
    definer = devuser@`%` procedure user_author_delete(IN in_user_id int, IN in_uid varchar(45))
BEGIN
	
    DELETE FROM user_author 
    WHERE (in_user_id is null or user_id = in_user_id )
    AND (in_uid is null or uid = in_uid);

END;

