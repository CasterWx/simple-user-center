create
    definer = devuser@`%` procedure global_user_get_by_phone(IN in_phone_num varchar(20))
BEGIN

	SELECT * FROM global_user WHERE phone_num = in_phone_num;
END;

