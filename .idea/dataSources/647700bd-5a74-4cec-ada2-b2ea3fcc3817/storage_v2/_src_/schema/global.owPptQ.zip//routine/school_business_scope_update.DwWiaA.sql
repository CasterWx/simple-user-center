create
    definer = devuser@`%` procedure school_business_scope_update(IN in_id int, IN in_school_id int, IN in_region_id int)
BEGIN
	UPDATE school_business_scope 
    SET school_id = in_school_id, region_id = in_region_id 
    WHERE id = in_id;
END;

