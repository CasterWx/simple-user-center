create
    definer = devuser@`%` procedure ppt_update(IN in_id int, IN in_resource_id int, IN in_ppt_task_id int,
                                               IN in_transform_file_url varchar(255))
BEGIN

	UPDATE ppt SET 
		resource_id = in_resource_id,
		ppt_task_id = in_ppt_task_id,
		transform_file_url = in_transform_file_url
	WHERE id = in_id;

END;

