create
    definer = devuser@`%` procedure major_attribute_delete(IN in_major_id int, IN in_attribute_id int)
BEGIN
    DELETE FROM `major_attribute`
    WHERE major_id = in_major_id
    AND attribute_id = in_attribute_id;
END;

