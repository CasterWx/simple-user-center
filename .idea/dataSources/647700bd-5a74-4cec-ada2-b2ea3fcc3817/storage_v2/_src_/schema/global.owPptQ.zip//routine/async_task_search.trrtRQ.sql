create
    definer = devuser@`%` procedure async_task_search(IN in_user_id int, IN in_school_id int, IN in_transfer int,
                                                      IN in_name varchar(255), IN in_statuses varchar(200),
                                                      IN in_type int, IN in_operate_type int, IN in_offset int,
                                                      IN in_count int, OUT out_total_count int)
BEGIN
	SELECT SQL_CALC_FOUND_ROWS t.*,att.operate_type FROM async_task t INNER JOIN async_task_type att ON att.id=t.type
  WHERE	
	(in_user_id IS NULL OR t.user_id = in_user_id)
	AND (in_school_id IS NULL OR t.school_id = in_school_id)
	AND (in_transfer IS NULL OR t.transfer = in_transfer)
	AND (in_name IS NULL OR t.`name` LIKE CONCAT('%',in_name,'%'))
	AND (in_statuses IS NULL OR FIND_IN_SET(t.`status`,in_statuses))
	AND (in_type IS NULL OR t.type = in_type) 
	AND (in_operate_type IS NULL OR att.operate_type = in_operate_type) 
	ORDER BY t.created_time DESC
	LIMIT in_offset, in_count;	
	SET out_total_count = FOUND_ROWS();
	
END;

