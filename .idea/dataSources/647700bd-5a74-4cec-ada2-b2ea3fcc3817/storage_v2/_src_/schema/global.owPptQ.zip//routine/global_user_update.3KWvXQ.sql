create
    definer = devuser@`%` procedure global_user_update(IN in_id int, IN in_user_name varchar(64),
                                                       IN in_password varchar(64), IN in_display_name varchar(64),
                                                       IN in_gender varchar(20), IN in_phone_num varchar(20),
                                                       IN in_identity_card varchar(18), IN in_address varchar(512),
                                                       IN in_photo_image_url varchar(500), IN in_email varchar(100),
                                                       IN in_user_type int, IN in_phone_valid bit)
BEGIN

	UPDATE global_user SET 
		password = in_password,
        user_name = in_user_name,
        display_name = in_display_name,
		phone_num=in_phone_num,
		gender= in_gender,
		identity_card = in_identity_card,
		address = in_address,
        photo_image_url = in_photo_image_url,
        email = in_email,
        user_type = in_user_type,
		phone_valid = in_phone_valid
	WHERE id=in_id;

END;

