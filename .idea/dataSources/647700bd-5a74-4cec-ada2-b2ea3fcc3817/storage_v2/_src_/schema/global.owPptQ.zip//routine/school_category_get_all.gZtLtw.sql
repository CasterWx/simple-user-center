create
    definer = devuser@`%` procedure school_category_get_all()
BEGIN

    SELECT * FROM school_category;
END;

