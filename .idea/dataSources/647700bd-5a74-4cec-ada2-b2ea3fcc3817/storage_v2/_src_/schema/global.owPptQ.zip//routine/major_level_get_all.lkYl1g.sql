create
    definer = devuser@`%` procedure major_level_get_all()
BEGIN
    SELECT * FROM major_level;
END;

