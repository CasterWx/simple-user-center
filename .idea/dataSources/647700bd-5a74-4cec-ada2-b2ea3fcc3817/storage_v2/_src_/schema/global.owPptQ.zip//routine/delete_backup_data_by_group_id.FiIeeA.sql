create
    definer = devuser@`%` procedure delete_backup_data_by_group_id(IN in_group_id int)
BEGIN
SET SQL_SAFE_UPDATES = 0;

DELETE FROM global_user_bak_for_delete WHERE group_id=in_group_id;

DELETE FROM user_school_bak_for_delete WHERE group_id=in_group_id;

END;

