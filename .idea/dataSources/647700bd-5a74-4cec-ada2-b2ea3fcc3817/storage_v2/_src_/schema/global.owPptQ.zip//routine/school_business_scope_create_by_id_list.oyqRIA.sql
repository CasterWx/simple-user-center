create
    definer = devuser@`%` procedure school_business_scope_create_by_id_list(IN in_id_list mediumtext, IN in_school_id int)
BEGIN

    DECLARE id_token VARCHAR(10);
    
	SET SQL_SAFE_UPDATES=0;
    
    WHILE LENGTH(in_id_list) >0 DO

        SET id_token = SUBSTRING_INDEX(in_id_list, '|', 1);

        SET in_id_list = SUBSTRING(in_id_list,LENGTH(id_token) +2);

        INSERT school_business_scope (school_id,region_id) VALUES (in_school_id,CAST(id_token AS SIGNED));

    END WHILE;

END;

