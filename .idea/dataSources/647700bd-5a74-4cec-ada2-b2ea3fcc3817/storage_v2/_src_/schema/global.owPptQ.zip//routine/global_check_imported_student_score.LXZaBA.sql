create
    definer = devuser@`%` procedure global_check_imported_student_score(IN in_group_id int, IN in_school_id int, IN in_repeated int)
BEGIN
	
	DECLARE waiting INT DEFAULT 1;
    DECLARE valid INT DEFAULT 2;
    DECLARE invalid INT DEFAULT 3;
    DECLARE complete INT DEFAULT 4;
    DECLARE cancel INT DEFAULT 5;
    DECLARE checking INT DEFAULT 6;
    
    SET SQL_SAFE_UPDATES = 0;
    
    
    UPDATE operate_group SET status=checking WHERE id = in_group_id;
    
    
    IF in_repeated = 1 THEN
		UPDATE  operate_item SET status=waiting,comment='等待处理',c9=null,c10=null,c19=null where group_id = in_group_id;
        
    END IF;
    
    
    UPDATE  operate_item SET status=invalid,comment= '登录名不能为空' WHERE group_id = in_group_id AND (c2 is null or c2 ="");
	
    
    UPDATE operate_item SET c19=id where group_id=in_group_id;
    
	UPDATE  operate_item oi INNER JOIN global_user gu ON oi.c2=gu.user_name AND oi.group_id=in_group_id 
	INNER JOIN user_school us ON us.user_id=gu.id AND us.school_id=in_school_id AND us.user_role=1
	AND oi.status=waiting SET oi.c9=gu.id,c10=gu.display_name;
    
    
    UPDATE operate_item SET status=invalid,comment= '无此用户' 
    WHERE (c9 ='' or c9 is null)  AND group_id=in_group_id AND status=waiting;
    
    
	UPDATE operate_item SET status=invalid,comment= '登录名与学生姓名不是同一个学生' 
    WHERE status=waiting AND c3 IS NOT NULL AND c3 != '' AND c3 != c10  AND group_id=in_group_id;
  
    
  	UPDATE operate_group SET status=
 	CASE WHEN EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=waiting)
	 THEN valid else invalid END
 	WHERE id=in_group_id;

END;

