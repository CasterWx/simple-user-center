create
    definer = devuser@`%` procedure global_user_get_by_name(IN in_user_name varchar(255))
BEGIN
	SELECT * FROM global_user WHERE user_name = in_user_name;
END;

