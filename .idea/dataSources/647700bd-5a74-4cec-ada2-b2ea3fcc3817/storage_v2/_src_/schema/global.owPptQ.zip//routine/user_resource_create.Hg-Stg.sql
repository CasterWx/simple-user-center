create
    definer = devuser@`%` procedure user_resource_create(IN in_name varchar(255), IN in_user_id int,
                                                         IN in_resource_id int, IN in_status int(2),
                                                         IN in_parent_id int, OUT out_id int)
BEGIN

	INSERT INTO user_resource(name, user_id, resource_id, status, parent_id)
	VALUES (in_name, in_user_id, in_resource_id, in_status, in_parent_id);

	SET out_id = last_insert_id();
END;

