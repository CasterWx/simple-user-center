create
    definer = devuser@`%` procedure operateitem_search(IN in_group_id int, IN in_status int,
                                                       IN in_concrete_status varchar(255), IN in_offset int,
                                                       IN in_size int, OUT out_total_count int)
BEGIN

	SELECT SQL_CALC_FOUND_ROWS * FROM operate_item 
    WHERE group_id=in_group_id  
    AND (in_concrete_status IS NULL OR comment like CONCAT("%", in_concrete_status, "%"))
    AND (in_status = 0 OR status = in_status)
    LIMIT in_offset,in_size;
	SET out_total_count=FOUND_ROWS();	
	

END;

