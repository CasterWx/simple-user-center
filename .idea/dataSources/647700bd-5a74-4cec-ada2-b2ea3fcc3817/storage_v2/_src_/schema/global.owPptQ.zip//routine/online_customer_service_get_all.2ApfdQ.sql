create
    definer = devuser@`%` procedure online_customer_service_get_all()
BEGIN

    SELECT * FROM online_customer_service;
END;

