create
    definer = devuser@`%` procedure global_image_create(IN in_name varchar(300), IN in_url varchar(500),
                                                        IN in_image_type int, OUT out_id int)
BEGIN
	
    INSERT INTO global_image (name, url, image_type)
    VALUES(in_name, in_url, in_image_type);
    
    SET out_id = LAST_INSERT_ID();
END;

