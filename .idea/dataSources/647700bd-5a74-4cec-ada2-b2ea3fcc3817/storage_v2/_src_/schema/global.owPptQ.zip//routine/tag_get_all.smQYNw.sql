create
    definer = devuser@`%` procedure tag_get_all()
BEGIN

	SELECT * FROM tag;
END;

