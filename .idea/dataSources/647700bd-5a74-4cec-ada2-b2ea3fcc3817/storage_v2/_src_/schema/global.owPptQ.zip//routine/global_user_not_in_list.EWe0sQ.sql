create
    definer = devuser@`%` procedure global_user_not_in_list(IN in_school_id int, IN in_id_list mediumtext,
                                                            IN in_display_name varchar(64), IN in_role_id int,
                                                            IN in_offset int, IN in_count int, OUT out_total_count int)
BEGIN
    DECLARE user_id_token INT(11);
    
	DROP TEMPORARY TABLE IF EXISTS `gloabl_user_id_temporary`;
	CREATE TEMPORARY TABLE `gloabl_user_id_temporary`(
		user_id INT(11) 
	);

	WHILE LENGTH(in_id_list)>0 DO
		SET user_id_token = SUBSTRING_INDEX(in_id_list,'|',1);
		SET in_id_list = SUBSTRING(in_id_list,LENGTH(user_id_token)+2);
		INSERT INTO `gloabl_user_id_temporary` (user_id) VALUES(user_id_token);
	END WHILE;
        
	SELECT SQL_CALC_FOUND_ROWS DISTINCT gu.* FROM global_user gu 
    INNER JOIN user_school us ON gu.id = us.user_id and us.school_id =in_school_id
    LEFT JOIN gloabl_user_id_temporary t ON gu.id  = t.user_id
	WHERE (in_display_name IS NULL OR gu.display_name LIKE CONCAT('%',in_display_name,'%'))
	AND (in_role_id IS NULL OR us.user_role = in_role_id)
	AND t.user_id IS NULL
	LIMIT in_offset, in_count;
	
    SET out_total_count = FOUND_ROWS();
    
	DROP TEMPORARY TABLE IF EXISTS `gloabl_user_id_temporary`;
	

END;

