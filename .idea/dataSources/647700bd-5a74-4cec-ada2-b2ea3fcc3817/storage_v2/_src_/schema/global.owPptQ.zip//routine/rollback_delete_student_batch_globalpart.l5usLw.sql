create
    definer = devuser@`%` procedure rollback_delete_student_batch_globalpart(IN in_group_id int)
BEGIN

	 INSERT INTO user_school(id, user_id, school_id, user_role)
	 SELECT user_school_id, user_id, school_id, user_role FROM user_school_bak_for_delete WHERE group_id = in_group_id;
    
     INSERT INTO global_user (id, user_name, display_name,created_time,`password`,gender,phone_num,address,identity_card,photo_image_id,email,user_type)
     SELECT global_user_id, user_name, display_name,created_time,`password`,gender,phone_num,address,identity_card,photo_image_id,email,user_type
     FROM global_user_bak_for_delete WHERE group_id = in_group_id;
     
     SET sql_safe_updates = 0;
     UPDATE operate_item SET status=2 WHERE group_id=in_group_id AND status=4;
	 UPDATE operate_group SET status= 2 WHERE id=in_group_id;
	 
     DELETE FROM user_school_bak_for_delete WHERE group_id = in_group_id;
     DELETE FROM global_user_bak_for_delete WHERE group_id = in_group_id;
    
END;

