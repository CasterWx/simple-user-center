create
    definer = devuser@`%` procedure major_trainclass_get_by_major_id(IN in_major_id int)
BEGIN
	SELECT id,major_id,res_trainclass_id FROM major_trainclass WHERE major_id = in_major_id; 
END;

