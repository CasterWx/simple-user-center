create
    definer = devuser@`%` procedure imported_teacher_type_get_by_group_id(IN in_group_id int, OUT out_type int)
BEGIN
	-- type
	DECLARE local_only_teacher INT DEFAULT 1;
    DECLARE local_only_staff INT DEFAULT 2;
    DECLARE local_both INT DEFAULT 3;
    
    -- status
    DECLARE local_valid INT DEFAULT 2;
    
    DECLARE local_teachercount INT DEFAULT 0;
    DECLARE local_staffcount INT DEFAULT 0;
    
    
    SELECT count(id) INTO local_teachercount FROM  operate_item oi WHERE oi.group_id = in_group_id AND oi.status = local_valid AND (oi.c4 ='' OR oi.c4 IS NULL);

	SELECT count(id) INTO local_staffcount FROM  operate_item oi WHERE oi.group_id = in_group_id AND oi.status = local_valid AND oi.c4 IS NOT NULL AND oi.c4 != '';

	SELECT CASE 
	WHEN local_teachercount > 0 AND local_staffcount > 0 THEN local_both
	WHEN local_teachercount > 0 AND local_staffcount = 0 THEN local_only_teacher
	WHEN local_teachercount = 0 AND local_staffcount > 0 THEN local_only_staff
	END
	INTO out_type;
   
   
END;

