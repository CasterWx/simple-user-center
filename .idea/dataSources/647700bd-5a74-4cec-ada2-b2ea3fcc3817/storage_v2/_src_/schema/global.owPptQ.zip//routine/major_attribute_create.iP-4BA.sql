create
    definer = devuser@`%` procedure major_attribute_create(IN in_major_id int, IN in_attribute_id int, OUT out_id int)
BEGIN
    INSERT INTO `major_attribute`
    (`major_id`,
    `attribute_id`
    )
    VALUES
    (in_major_id,
    in_attribute_id
    );

    SET out_id = LAST_INSERT_ID();
END;

