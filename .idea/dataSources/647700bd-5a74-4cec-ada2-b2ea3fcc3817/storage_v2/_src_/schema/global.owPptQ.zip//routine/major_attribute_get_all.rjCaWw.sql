create
    definer = devuser@`%` procedure major_attribute_get_all()
BEGIN
    SELECT * FROM major_attribute;
END;

