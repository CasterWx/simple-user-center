create
    definer = devuser@`%` procedure sync_qingshu_course_res_task_batch_insert(IN in_task_list longtext)
BEGIN
   DECLARE
      i INT DEFAULT 1;

DECLARE
   count INT (11);

DROP TEMPORARY TABLE
IF EXISTS synQingshuCourseResTempTbl;

CREATE TEMPORARY TABLE synQingshuCourseResTempTbl (
   `school_id` INT (11),
   `school_course_id` INT (11),
   `res_id` VARCHAR (255),
   `res_type` INT (11),
   `status` INT (11)
);


SET SQL_SAFE_UPDATES = 0;


SET count = ExtractValue (in_task_list, 'count(//Task)');


WHILE i <= count DO
   INSERT INTO synQingshuCourseResTempTbl (`school_id`, `school_course_id`, `res_id`, `res_type`, `status`)
VALUES
   (
      CAST(XMLDECODE(ExtractValue(in_task_list, '/Tasks/Task[$i]/SchoolId')) AS SIGNED),
      CAST(XMLDECODE(ExtractValue(in_task_list, '/Tasks/Task[$i]/SchoolCourseId')) AS SIGNED),
      XMLDECODE (ExtractValue(in_task_list, '/Tasks/Task[$i]/ResId')),
      CAST(XMLDECODE(ExtractValue(in_task_list, '/Tasks/Task[$i]/ResType')) AS SIGNED),
      CAST(XMLDECODE(ExtractValue(in_task_list, '/Tasks/Task[$i]/status')) AS SIGNED)
   );


SET i = i + 1;


END
WHILE;

INSERT INTO sync_qingshu_course_res_task (`school_id`, `school_course_id`, `res_id`, `res_type`, `status`) SELECT
   `school_id`,
   `school_course_id`,
   `res_id`,
   `res_type`,
   `status`
FROM
   synQingshuCourseResTempTbl;

DROP TEMPORARY TABLE
IF EXISTS synQingshuCourseResTempTbl;


END;

