create
    definer = devuser@`%` procedure batch_import_peixun_student_global_info(IN in_operate_group_id int, IN in_school_id int)
BEGIN
	DECLARE VALID INT;
    DECLARE DONE INT;
    
    SET VALID = 2;
    SET DONE = 4;

	SET SQL_SAFE_UPDATES = 0;
			
    INSERT INTO global_user(user_name, password, display_name, gender, identity_card, address) 
    SELECT oi.c1, oi.c2, oi.c3, oi.c4, oi.c5, oi.c9 FROM operate_item oi
    WHERE oi.group_id = in_operate_group_id AND oi.status = VALID;  
    
    INSERT INTO user_school(user_id, school_id, user_role) 
    SELECT gu.id, in_school_id, 1 FROM global_user gu 
    INNER JOIN operate_item oi ON oi.c1 = gu.user_name
    WHERE oi.group_id = in_operate_group_id AND oi.status = VALID;
    
	UPDATE operate_item SET status = DONE WHERE status = VALID AND group_id = in_operate_group_id;
	
    UPDATE operate_item oi INNER JOIN global_user gu ON oi.c1 = gu.user_name
	SET oi.c18 = gu.id WHERE oi.group_id = in_operate_group_id AND status = DONE;
    
	UPDATE operate_group og SET og.status =
	CASE WHEN EXISTS (SELECT oi.id FROM operate_item oi WHERE oi.group_id = in_operate_group_id AND oi.status=VALID)
		THEN VALID ELSE DONE END 
	WHERE og.id=in_operate_group_id;
	
    UPDATE operate_item SET status = VALID WHERE status = DONE AND group_id = in_operate_group_id;

END;

