create
    definer = devuser@`%` procedure tmp_res_course_map(OUT out_result_code int)
BEGIN
	UPDATE course a INNER JOIN tmp_res_init b ON 
	a.id=b.school_course_id
	SET a.global_id=b.global_course_id,
	a.global_courseware_id=b.global_courseware_id;

TRUNCATE TABLE tmp_res_init;
SELECT ROW_COUNT() INTO out_result_code;

END;

