create
    definer = devuser@`%` procedure baidu_city_dic_create(IN in_baidu_city_id int, IN in_city_name varchar(100), OUT out_id int)
BEGIN

    INSERT INTO `baidu_city_dic`
    (`baidu_city_id`,  `city_name`)
    VALUES
    (in_baidu_city_id,  in_city_name);    
    SET out_id = LAST_INSERT_ID();
    
END;

