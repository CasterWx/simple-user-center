create
    definer = devuser@`%` procedure async_task_update_task(IN in_id int, IN in_status int)
BEGIN
	UPDATE async_task SET status = in_status WHERE id = in_id;
END;

