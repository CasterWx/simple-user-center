create
    definer = devuser@`%` procedure resource_create(IN in_url varchar(255), IN in_type int, IN in_status int,
                                                    IN in_size int, OUT out_id int)
BEGIN

	INSERT INTO `resource`(url, `type`, `status`, `size`)
	VALUES (in_url, in_type, in_status, in_size);

	SET out_id = last_insert_id();
END;

