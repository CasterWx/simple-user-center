create
    definer = devuser@`%` procedure operate_item_delete_by_ids(IN in_id_list mediumtext)
BEGIN
	set @sql = concat("DELETE FROM operate_item WHERE id in (", in_id_list,")");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END;

