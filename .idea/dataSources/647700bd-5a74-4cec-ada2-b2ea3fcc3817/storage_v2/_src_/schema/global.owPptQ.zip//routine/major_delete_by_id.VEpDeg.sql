create
    definer = devuser@`%` procedure major_delete_by_id(IN in_id int, OUT is_allow_delete bit)
BEGIN   
    
    DECLARE major_student_count INT(11);
    SELECT COUNT(*) INTO major_student_count FROM student WHERE major_id = in_id;
    
    IF(major_student_count > 0) THEN 
		SET is_allow_delete = 0;
	ELSE
		SET is_allow_delete = 1;

		SET SQL_SAFE_UPDATES = 0;

		DELETE FROM major_free_video WHERE major_id = in_id;
		DELETE FROM news WHERE major_id = in_id;
		DELETE FROM payment WHERE fee_id in (SELECT id FROM fee WHERE major_id = in_id);
		DELETE FROM fee WHERE major_id = in_id;
		DELETE FROM student_xueji_change_record WHERE to_major_id = in_id;

		SET FOREIGN_KEY_CHECKS = 0; 

		DELETE m.*,tp.*,tpc.*,em.*,ec.*,fsc.*,fera.*
		FROM major m
		LEFT JOIN teachingplan tp ON tp.major_id = m.id
		LEFT JOIN teachingplan_course tpc ON tpc.teachingplan_id = tp.id
		LEFT JOIN exam em ON em.teachingplan_course_id = tpc.id
		LEFT JOIN exercise ec ON ec.teachingplan_course_id = tpc.id
		LEFT JOIN final_slot_course fsc ON fsc.teachingplan_course_id = tpc.id
		LEFT JOIN final_exam_room_arrangement fera ON fera.final_slot_course_id = fsc.id
		WHERE m.id = in_id;

		SET FOREIGN_KEY_CHECKS = 1; 
        
	END IF;

END;

