create
    definer = devuser@`%` procedure im_auth_user_delete_by_user_id(IN in_user_id int)
BEGIN
	SET SQL_SAFE_UPDATES = 0;
    
	DELETE FROM im_auth_user WHERE global_user_id = in_user_id;
    
END;

