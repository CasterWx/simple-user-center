create
    definer = devuser@`%` procedure school_get_peixun_openning_new()
BEGIN
SELECT a.*  FROM school a , school_category b WHERE a.category_id = b.id AND a.status=-3 ;
END;

