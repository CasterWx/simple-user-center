create
    definer = devuser@`%` procedure school_get_simple_info(IN in_id int, IN in_symbol varchar(50))
BEGIN
	SELECT
		id,
		symbol
	FROM
		school
	WHERE
		(in_id IS NULL OR id = in_id)
	AND (
		in_symbol IS NULL
		OR symbol = in_symbol
	);
END;

