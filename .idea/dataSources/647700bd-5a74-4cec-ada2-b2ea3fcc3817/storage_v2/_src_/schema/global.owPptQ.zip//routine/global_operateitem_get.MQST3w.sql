create
    definer = devuser@`%` procedure global_operateitem_get(IN in_id int)
BEGIN

	SELECT * FROM operate_item WHERE id=in_id;

END;

