create
    definer = devuser@`%` procedure user_device_delete_by_user_ids(IN in_user_ids mediumtext)
BEGIN
	set @sql = concat("DELETE FROM user_device WHERE user_id in (", in_user_ids,")");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END;

