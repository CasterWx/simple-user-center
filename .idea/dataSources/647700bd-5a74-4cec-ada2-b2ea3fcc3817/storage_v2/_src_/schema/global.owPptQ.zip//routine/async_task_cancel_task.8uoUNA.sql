create
    definer = devuser@`%` procedure async_task_cancel_task(IN in_id int)
BEGIN
	update async_task set status=5, message='任务取消' where id = in_id and status in (0,4);
END;

