create
    definer = devuser@`%` procedure wxpay_get_all()
BEGIN

	SELECT * FROM wxpay;

END;

