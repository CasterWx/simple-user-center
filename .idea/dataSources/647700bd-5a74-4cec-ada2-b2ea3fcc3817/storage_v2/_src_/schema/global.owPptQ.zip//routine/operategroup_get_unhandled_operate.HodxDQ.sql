create
    definer = devuser@`%` procedure operategroup_get_unhandled_operate(IN in_operator int, IN in_type int)
BEGIN
	
	DECLARE waiting INT DEFAULT 1;
    DECLARE valid INT DEFAULT 2;
    DECLARE invalid INT DEFAULT 3;
    DECLARE complete INT DEFAULT 4;
    DECLARE cancel INT DEFAULT 5;
    DECLARE checking INT DEFAULT 6;
    
	SELECT * FROM operate_group WHERE operator= in_operator AND type=in_type AND status != complete AND status != cancel ORDER BY id DESC LIMIT 1;

END;

