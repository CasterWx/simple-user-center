create
    definer = devuser@`%` procedure update_username_bybatch(IN in_group_id int, IN in_type int, IN in_prefix varchar(50))
BEGIN
	
    -- 1 generate user name
    IF in_type=1 THEN
    	UPDATE operate_item SET status=3 ,comment='学号为空' WHERE group_id=in_group_id AND (c0 IS NULL OR c0 = '');
    	UPDATE operate_item SET c3=cONcat(in_prefix,c0) WHERE group_id=in_group_id AND status=1;
    ELSE
    	UPDATE operate_item oi INNER JOIN global_user gu ON oi.c2=gu.id  AND oi.group_id=in_group_id AND (gu.identity_card IS NULL OR gu.identity_card = '') 
    	SET oi.status=3,oi.comment='身份证号为空';
    	UPDATE operate_item oi INNER JOIN global_user gu ON oi.c2=gu.id AND oi.group_id=in_group_id AND oi.status=1 SET oi.c3=cONcat(in_prefix,gu.identity_card);
    END IF;
	
    -- 2  check user name repeat
  	UPDATE operate_item SET comment='用户名重复',status=3 
  	WHERE group_id=in_group_id AND status=1 AND EXISTS( SELECT id FROM global_user WHERE user_name=c3 and id != c2) ;
 	
 	
 	-- 3 UPDATE user name
  	UPDATE global_user gu INNER JOIN  operate_item oi   ON oi.c2=gu.id AND oi.group_id=in_group_id AND oi.status=1 SET user_name=c3 , oi.status=4;

END;

