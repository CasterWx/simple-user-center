create
    definer = devuser@`%` procedure check_imported_teacher(IN in_group_id int)
BEGIN
	-- status
	DECLARE local_waiting INT DEFAULT 1;
    DECLARE local_valid INT DEFAULT 2;
    DECLARE local_invalid INT DEFAULT 3;
    DECLARE local_complete INT DEFAULT 4;
    DECLARE local_cancel INT DEFAULT 5;
    DECLARE local_checking INT DEFAULT 6;
    
    -- 无其他检查项 item的状态更新global
  	UPDATE operate_group SET status=
 	CASE WHEN EXISTS (SELECT id FROM operate_item WHERE group_id=in_group_id AND status=local_valid)
	 THEN local_valid else local_invalid END
 	WHERE id=in_group_id;

END;

