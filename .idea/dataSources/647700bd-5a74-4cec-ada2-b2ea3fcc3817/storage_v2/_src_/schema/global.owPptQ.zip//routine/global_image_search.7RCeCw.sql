create
    definer = devuser@`%` procedure global_image_search(IN in_image_type int, IN in_name varchar(300),
                                                        IN in_url varchar(500), IN in_offset int, IN in_size int)
BEGIN
    SELECT * FROM global_image
    WHERE (in_image_type IS NULL OR image_type = in_image_type)
    AND (in_name IS NULL OR name like concat('%',in_name,'%'))
    AND (in_url IS NULL OR url = in_url)
    LIMIT in_offset, in_size;
    
END;

