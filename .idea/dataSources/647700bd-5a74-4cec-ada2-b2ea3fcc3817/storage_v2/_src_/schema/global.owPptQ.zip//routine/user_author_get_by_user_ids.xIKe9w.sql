create
    definer = devuser@`%` procedure user_author_get_by_user_ids(IN in_user_ids mediumtext)
BEGIN
	set @sql = concat("SELECT * FROM user_author WHERE user_id in (", in_user_ids,")");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
END;

