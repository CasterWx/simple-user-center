create
    definer = devuser@`%` procedure school_register_create(IN in_school_name varchar(300), IN in_school_type int,
                                                           IN in_name varchar(64), IN in_phone varchar(45),
                                                           IN in_email varchar(100), IN in_status int, OUT out_id int)
BEGIN

	INSERT INTO school_register(school_name,school_type,name,phone,email,status)

	VALUES(in_school_name,in_school_type,in_name,in_phone,in_email,in_status);

	SET out_id = LAST_INSERT_ID();

END;

