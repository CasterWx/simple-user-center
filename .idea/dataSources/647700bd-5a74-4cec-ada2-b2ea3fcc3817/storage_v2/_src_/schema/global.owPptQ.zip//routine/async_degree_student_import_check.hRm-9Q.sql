create
    definer = devuser@`%` procedure async_degree_student_import_check(IN in_group_id int, IN in_school_id int)
BEGIN
	UPDATE operate_group og SET og.status = 10, og.result = null WHERE og.id = in_group_id;

	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名不能为空'),'用户名不能为空') WHERE (oi.c1 IS NULL OR oi.c1 = '') AND oi.group_id = in_group_id;
	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','密码不能为空'),'密码不能为空') WHERE (oi.c2 IS NULL OR oi.c2 = '') AND oi.group_id = in_group_id ;
	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','姓名不能为空'),'姓名不能为空') WHERE (oi.c4 IS NULL OR oi.c4 = '') AND oi.group_id = in_group_id ;
	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','性别只能为男或女'),'性别只能为男或女') 
	WHERE oi.c5 IS NOT NULL AND oi.c5 != '' AND oi.c5 != '男' AND oi.c5 != '女' AND oi.group_id = in_group_id;

	UPDATE operate_item oi 
	LEFT JOIN nationality ss on oi.c6 = ss.name
	SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','请输入正确的民族'),'请输入正确的民族')
	WHERE oi.c6 IS NOT NULL AND oi.c6 != '' AND ss.id is NULL AND oi.group_id = in_group_id;

	UPDATE operate_item oi 
	LEFT JOIN politics_status ss on oi.c7 = ss.name
	SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','请输入正确的政治面貌'),'请输入正确的政治面貌')
	WHERE oi.c7 IS NOT NULL AND oi.c7 != '' AND ss.id is NULL AND oi.group_id = in_group_id;

	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','身份证格式不正确'),'身份证格式不正确') 
	WHERE oi.c9 IS NOT NULL AND oi.c9 != '' AND check_identity_card(oi.c9) = 0 AND oi.group_id = in_group_id;

	UPDATE operate_item oi     
	SET oi.c5 = IF(MOD(substr(oi.c9,17,1),2)=1,'男','女')
	WHERE oi.status = 10 AND (oi.c5 IS NULL OR oi.c5='') AND oi.c9 IS NOT NULL AND oi.c9 != '' AND oi.group_id = in_group_id;

	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','手机号格式不正确'),'手机号格式不正确') 
	WHERE oi.c10 IS NOT NULL AND oi.c10 != '' AND oi.c10 NOT REGEXP '^[1][3-9][0-9]{9}$' AND oi.group_id = in_group_id;

	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名不允许是手机号'),'用户名不允许是手机号') 
	WHERE oi.c1 IS NOT NULL AND oi.c1 != '' AND oi.c1 REGEXP '^[1][3-9][0-9]{9}$'  AND oi.group_id = in_group_id;

	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名只能为数字和字母或_-@组成'),'用户名只能为数字和字母或_-@组成') 
	WHERE oi.c1 IS NOT NULL AND oi.c1 != '' AND oi.c1 NOT REGEXP '^[A-Za-z0-9\\_@-]+$'  AND oi.group_id = in_group_id;

	UPDATE operate_item oi SET oi.status = 3, oi.comment = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','密码只能为数字和字母组成'),'密码只能为数字和字母组成') 
	WHERE oi.c2 IS NOT NULL AND oi.c2 != '' AND oi.c2 NOT REGEXP '^[A-Za-z0-9]+$'  AND oi.group_id = in_group_id;


	UPDATE operate_item oi 
	LEFT JOIN (SELECT oi.c1,COUNT(oi.c1) c FROM operate_item oi WHERE oi.group_id = in_group_id GROUP BY oi.c1) oi1 ON oi.c1 = oi1.c1 AND oi.group_id = in_group_id
	SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','导入数据中存在用户名相同的数据'),'导入数据中存在用户名相同的数据')
	WHERE oi1.c > 1 ;

	UPDATE operate_item oi 
	LEFT JOIN (SELECT oi.c9,COUNT(oi.c9) c FROM operate_item oi WHERE oi.group_id = in_group_id GROUP BY oi.c9) oi1 ON oi.c9 = oi1.c9 AND oi.group_id = in_group_id
	SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','导入数据中存在身份证号码相同的数据'),'导入数据中存在身份证号码相同的数据')
	WHERE oi1.c > 1 AND oi.c9 != '';

	UPDATE operate_item oi 
	LEFT JOIN (SELECT oi.c10,COUNT(oi.c10) c FROM operate_item oi WHERE oi.group_id = in_group_id GROUP BY oi.c10) oi1 ON oi.c10 = oi1.c10 AND oi.group_id = in_group_id
	SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','导入数据中存在手机号码相同的数据'),'导入数据中存在手机号码相同的数据')
	WHERE oi1.c > 1 AND oi.c10 != '';

	UPDATE operate_item oi 
	SET oi.`status` = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名大于30个字符'),'用户名大于30个字符')
	WHERE oi.group_id = in_group_id AND LENGTH(oi.c1) > 30;

	UPDATE operate_item oi
	INNER JOIN global_user gu on oi.group_id = in_group_id and oi.c1 = gu.user_name
	SET oi.c22 = gu.id, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名已被注册'),'用户名已被注册'), oi.`status` = 7
	WHERE NOT EXISTS(SELECT 1 from user_school us where us.school_id = in_school_id AND us.user_id = gu.id) AND oi.status != 3 AND oi.status != 11;

	UPDATE operate_item oi  
	INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.c1 = gu.user_name AND oi.`status` != 7 AND oi.`status` != 11
	SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','用户名已被注册'),'用户名已被注册'); 

	UPDATE operate_item oi  
	INNER JOIN global_user gu ON oi.group_id = in_group_id AND  oi.c9 != '' AND oi.c9 = gu.identity_card AND oi.`status` != 7 AND oi.`status` != 11
	SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','身份证已被使用'),'身份证已被使用'); 

	UPDATE operate_item oi  
	INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.c10 != '' AND oi.c10 = gu.phone_num AND oi.`status` != 7 AND oi.`status` != 11
	SET oi.status = 3, oi.`comment` = IF(oi.comment IS NOT NULL,CONCAT(oi.comment,' ','手机号已被使用'),'手机号已被使用');

	UPDATE operate_item oi
	INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.`status` = 7 AND oi.c22 = gu.id
	SET oi.`status` = 3, oi.`comment` = CONCAT(oi.`comment`,' ','当前数据与数据库的内容不符')
	WHERE oi.c2 != gu.`password` OR oi.c4 != gu.display_name OR (gu.gender IS NOT NULL AND gu.gender != '' AND gu.gender != oi.c5)
	OR (gu.identity_card IS NOT NULL AND gu.identity_card != '' AND oi.c9 != gu.identity_card)
	OR (gu.phone_num IS NOT NULL AND gu.phone_num != '' AND oi.c10 != gu.phone_num)
	OR (gu.address IS NOT NULL AND gu.address != '' AND oi.c11 != gu.address);

	UPDATE operate_item oi
	INNER JOIN global_user gu ON oi.group_id = in_group_id AND oi.`status` = 11 AND oi.c1 = gu.user_name AND oi.c22 != gu.id
	SET oi.`status` = 3, oi.`comment` = CONCAT(oi.`comment`,' ','用户名已被注册');

	UPDATE operate_item SET comment='有效数据' WHERE status = 2 AND group_id = in_group_id;

	UPDATE operate_group og SET og.status = 2 WHERE NOT EXISTS (select 1 from operate_item where (status = 3 or `status` = 7 or `status` = 11) and group_id = in_group_id) AND og.id = in_group_id;

	UPDATE operate_group og SET og.`status` = 7 WHERE NOT EXISTS(SELECT 1 FROM operate_item WHERE `status` = 3 and group_id = in_group_id) AND og.`status` != 2 AND og.id=in_group_id;

	UPDATE operate_group og INNER JOIN operate_item oi ON oi.group_id = og.id SET og.result = '助考学生' WHERE oi.`status` = 11 AND og.`status` = 7 AND og.id = in_group_id;

	UPDATE operate_group og INNER JOIN operate_item oi ON oi.group_id = og.id SET og.status = 3 WHERE oi.`status` = 3 AND og.id = in_group_id;

	UPDATE operate_item oi 
	LEFT JOIN nationality ss on oi.c6 = ss.name
	SET oi.c23 = ss.id
	WHERE oi.c6 IS NOT NULL AND oi.c6 != '' AND ss.id IS NOT NULL AND oi.group_id = in_group_id;

	UPDATE operate_item oi 
	LEFT JOIN politics_status ss on oi.c7 = ss.name
	SET oi.c24 = ss.id
	WHERE oi.c7 IS NOT NULL AND oi.c7 != '' AND ss.id IS NOT NULL AND oi.group_id = in_group_id;

END;

